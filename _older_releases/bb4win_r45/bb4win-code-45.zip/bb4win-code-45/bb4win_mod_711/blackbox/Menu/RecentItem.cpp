/*
 ============================================================================

  This file is part of the bbLean source code
  Copyright � 2001-2003 The Blackbox for Windows Development Team
  Copyright � 2004 grischka

  http://bb4win.sourceforge.net/bblean
  http://sourceforge.net/projects/bb4win

 ============================================================================

  bbLean and bb4win are free software, released under the GNU General
  Public License (GPL version 2 or later), with an extension that allows
  linking of proprietary modules under a controlled interface. This means
  that plugins etc. are allowed to be released under any license the author
  wishes. For details see:

  http://www.fsf.org/licenses/gpl.html
  http://www.fsf.org/licenses/gpl-faq.html#LinkingOverControlledInterface

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
  or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
  for more details.

 ============================================================================
*/

#include "RecentItem.h"
//===========================================================================
int CreateRecentItemMenu(char *pszFileName, char *pszCommand, char *pszTitle, int nLimitValue, bool bSort){
	static ItemList *RecentItemList;
	char buf[MAX_PATH];
	ItemList *iln = (ItemList*)m_alloc(sizeof(ItemList));

	// Newer Item
	_sprintf(buf, "\t[exec] (%s) {%s} <*>", pszTitle, pszCommand);
	_strcpy(iln->szItem, buf);
	iln->nFrequency = 1;

	if (FILE *fp = fopen(pszFileName, "r")){ // read Recent-menu
		while(fgets(buf, MAX_PATH, fp)){
			if (strstr(buf, "[end]"))
				break;
			else if (strstr(buf, "[exec]") == NULL)
				continue;
			else {
				if (buf[strlen(buf)-1] == '\n') buf[strlen(buf)-1] = '\0';
				char *p0 = strchr(buf, '{'); // command
				char *p1 = strchr(buf, '}'); // end of command
				if (p0 && p1){
					UINT nFrequency = 0;
					if (char *p = strrchr(buf, '#')){
						nFrequency = atoi(p+1);
						while(*(p--) == ' '); // delete space of eol
						*p = '\0';
					}
					if (0 != strnicmp(pszCommand, p0+1 , p1 - p0 - 1)){ // ignore duplicated item
						ItemList *il = (ItemList*)m_alloc(sizeof(ItemList));
						_strcpy(il->szItem, buf);
						il->nFrequency = imin(nFrequency, UINT_MAX);
						append_node(&RecentItemList, il);
					}
					else{ // if duplicate, increment freq
						iln->nFrequency += imin(nFrequency, (UINT_MAX - 1));
					}
				}
			}
		}

		fclose(fp);
	}

	if (bSort && listlen(RecentItemList))
		RecentItemList = sortlist(RecentItemList);

	if (FILE *fp = fopen(pszFileName, "w")){ // write Recent-menu
		fprintf(fp, "[begin] (Recent Items)\n");

		// most recent item
		fprintf(fp, "%s #%u\n", iln->szItem, iln->nFrequency);

		if (bSort && listlen(RecentItemList))
			fprintf(fp, "\t[separator]\n");

		int i = 0;
		ItemList *p;
		dolist (p, RecentItemList){
			if (++i >= nLimitValue) break;
			fprintf(fp, "%s #%u\n", p->szItem, p->nFrequency);
		}

		fprintf(fp, "[end]\n");

		fclose(fp);
	}

	m_free(iln);
	freeall(&RecentItemList);
	return 0;
}
//===========================================================================
ItemList *sortlist(ItemList *il){
	ItemList dmy;
	ItemList *p0,*p1;
	ItemList *p;

	dmy.nFrequency = UINT_MAX;
	dmy.next = il;
	p = il->next;
	il->next = NULL;

	p1 = p;
	while(p1 != NULL){
		p0 = &dmy;
		while(p0->next != NULL){
			if(p1->nFrequency > p0->next->nFrequency){
				p = p1->next;
				p1->next = p0->next;
				p0->next = p1;
				break;
			}
			p0 = p0->next;
		}
		if(p0->next == NULL){
			p = p1->next;
			p0->next = p1;
			p1->next = NULL;
		}
		p1 = p;
	}
	return dmy.next;
}
//===========================================================================
