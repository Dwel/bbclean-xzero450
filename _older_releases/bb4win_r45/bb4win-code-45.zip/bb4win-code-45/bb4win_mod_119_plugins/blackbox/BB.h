/*
 ============================================================================

  This file is part of the bb4win_mod source code
  Copyright � 2001-2009 The Blackbox for Windows Development Team
  Copyright � 2004-2009 grischka

  http://bb4win.sourceforge.net
  http://sourceforge.net/projects/bb4win

 ============================================================================

  bb4win_mod and bb4win are free software, released under the GNU General
  Public License (GPL version 2 or later), with an extension that allows
  linking of proprietary modules under a controlled interface. This means
  that plugins etc. are allowed to be released under any license the author
  wishes. For details see:

  http://www.fsf.org/licenses/gpl.html
  http://www.fsf.org/licenses/gpl-faq.html#LinkingOverControlledInterface

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
  or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
  for more details.

 ============================================================================
*/

/* BB.h - global defines aside of what is needed for the sdk-api */

#ifndef _BB_H
#define _BB_H

// ==============================================================
/* optional defines */

/* experimental nationalized language support */
#define BBOPT_SUPPORT_NLS

/* misc. developement options */
//#define BBOPT_DEVEL

/* memory allocation tracking */
//#define BBOPT_MEMCHECK

/* core dump to file */
//#define BBOPT_STACKDUMP

//#define NDEBUG

/* includes Minimise To Tray + Processes|Kill Menu */
//#define NT_ONLY

// ==============================================================
/* compiler specifics */

#define WINVER 0x0500
#ifndef _GNUC_
#define _WIN32_WINNT 0x0500
#endif
#define _WIN32_IE 0x0500
#define NO_INTSHCUT_GUIDS
#define NO_SHDOCVW_GUIDS

#ifdef __BORLANDC__
  #ifdef CRTSTRING
    #include "crt-string.h"
    #define TRY if (1)
    #define EXCEPT if(0)
  #else
    #define TRY __try
    #define EXCEPT __except(1)
  #endif
#endif

#ifndef TRY
  #define TRY if (1)
  #define EXCEPT(n) if (0)
#endif

#ifdef _MSC_VER
  #ifdef BBOPT_STACKDUMP
    #define TRY if (1)
    #define EXCEPT if(0)
  #else
    #define TRY _try
    #define EXCEPT(n) _except(n)
  #endif
  #define stricmp _stricmp
  #define strnicmp _strnicmp
  #define memicmp _memicmp
  #define strlwr _strlwr
  #define strupr _strupr
#else
  #undef BBOPT_STACKDUMP
#endif

// ==============================================================

// ==============================================================
/* Always includes */

#define __BBCORE__ // enable exports in BBApi.h
#include "BBApi.h"
#include "win0x500.h"
#include "m_alloc.h"
#include "Tinylist.h"
#include <assert.h>

// ==============================================================
/* definitions */

#define APPBUILD 1,19,0,7
#define APPDATE " - build 2009-06-01 " //__TIME__ " CET"
//#define APPDATE " - built on " __DATE__ " @ " __TIME__ " CET"
#define APPCOMPANY "The bb4win DevTeam"
#define APPCOPY "Copyright 2001-2009 " APPCOMPANY "|grischka"
#ifdef NT_ONLY
#define APPNAME "bb4win_mod NT "
#else
#define APPNAME "bb4win_mod "
#endif
#define APPNUMBER "1.19"
#define APPVERSION "bbLean|" APPNAME APPNUMBER

/* Blackbox icon and menu drag-cursor */

#define IDI_BB4WINMOD 101
#define IDC_MOVEMENU 102
#define IDI_BLACKBOX 103
#define IDC_MOVEMENUL 104
#define IDC_EDITBOX 105

/* Convenience defs */
#define IS_SPC(c) ((unsigned char)(c) <= 32)
#define IS_SLASH(c) ((c) == '\\' || (c) == '/')

// ==============================================================
/* global variables */

extern OSVERSIONINFO osInfo;
extern bool         usingNT, usingWin2kXP, usingXP, usingVista;

extern HINSTANCE    hMainInstance;
extern HWND         BBhwnd;
extern int          VScreenX, VScreenY;
extern int          VScreenWidth, VScreenHeight;
extern int          ScreenWidth, ScreenHeight;
extern bool         underExplorer;
extern bool         multimon;
extern bool         dont_hide_explorer;
extern bool         dont_hide_tray;

extern const char   bb_exename[];

extern const char   ShellTrayClass[];
extern bool         bbactive;

extern BOOL (WINAPI* pSwitchToThisWindow)(HWND, int);
extern BOOL (WINAPI* pTrackMouseEvent)(LPTRACKMOUSEEVENT lpEventTrack);

// ==============================================================
/* Blackbox window timers */
#define BB_WRITERC_TIMER        1
#define BB_CHECKWINDOWS_TIMER   2 /* refresh the VWM window list */
#define BB_RUNSTARTUP_TIMER     3
#define BB_ENDSTARTUP_TIMER     4

/* SetDesktopMargin internal flags */
#define BB_DM_REFRESH -1
#define BB_DM_RESET -2

// ==============================================================
/* core-wide parameters */
const char szBlackboxName   [] = "Blackbox";
const char szBlackboxClass  [] = "BlackboxClass";
const char szBlackboxType  [] = "bb4win_mod";

// ==============================================================
/* utils.cpp */

int BBMessageBox(int flg, const char *fmt, ...);
BOOL BBRegisterClass (const char *classname, WNDPROC wndproc, int flags);
#define BBCS_VISIBLE 1
#define BBCS_EXTRA 2
#define BBCS_DROPSHADOW 4

char *strcpy_max(char *dest, const char *src, int maxlen);
char* stristr(const char *a, const char *b);
int get_string_index (const char *key, const char * const * string_array);
int get_substring_index (const char *key, const char * const * string_list);
int substr_icmp(const char *a, const char *b);
int get_false_true(const char *arg);
void set_bool(void *v, const char *arg);
const char *false_true_string(int f);
const char *string_empty_or_null(const char *s);
char *extract_string(char *dest, const char *src, int length);

int imax(int a, int b);
int imin(int a, int b);
int iminmax(int i, int minval, int maxval);
int is_alpha(int c);
int is_digit(int c);
int is_alnum(int c);
unsigned int eightScale_up(unsigned int i);

char *replace_argument1(char *out, const char *format, const char *arg);

/* color utilities */
COLORREF rgb (unsigned r,unsigned g,unsigned b);
COLORREF switch_rgb (COLORREF c);
COLORREF mixcolors(COLORREF c1, COLORREF c2, int mixfac);
COLORREF split(COLORREF c, int To);
unsigned greyvalue(COLORREF c);
void draw_line_h(HDC hDC, int x1, int x2, int y, int w, COLORREF C);
int FuzzyMatch(COLORREF focus, COLORREF unfocus);

/* shadow colors */
void BBDrawText(HDC hDC, const char *lpString, int nCount, RECT *lpRect, unsigned uFormat, StyleItem * si);
COLORREF Settings_CreateShadowColor(COLORREF textColor);
COLORREF Settings_MapShadowColor(StyleItem* si, StyleItem* ri);

/* filenames */
const char *file_extension(const char *path);
const char *file_basename(const char *path);
char *file_directory(char *buffer, const char *path);
char* unquote(char *src);
char *add_slash(char *d, const char *s);
const char *get_relative_path(const char *p);
char *replace_slashes(char *buffer, const char *path);
int is_relative_path(const char *path);
char *make_bb_path(HINSTANCE h, char *dest, const char *src);
int locate_file(HINSTANCE hInstance, char *path, const char *fname, const char *ext);
char *get_path(char *pszPath, int nMaxLen, const char *file);

/* folder changed notification register */
UINT add_change_notify_entry(HWND hwnd, const struct _ITEMIDLIST *pidl);
void remove_change_notify_entry(UINT id_notify);

/* filetime */
int get_filetime(const char *fn, FILETIME *ft);
int check_filetime(const char *fn, FILETIME *ft0);

/* drawing */
void arrow_bullet (HDC buf, int x, int y, int d);
void BitBltRect(HDC hdc_to, HDC hdc_from, RECT *r);
int get_fontheight(HFONT hFont);

/* other */
int GetAppByWindow(HWND Window, LPSTR processName);
int EditBox(const char *caption, const char *message, const char *initvalue, char *buffer);
HWND GetRootWindow(HWND hwnd);
void SetOnTop (HWND hwnd);
int GetOSVersion(void);

/* Logging */
void _log_printf(int flag, const char *fmt, ...);
#define LOG_PLUGINS 1
#define LOG_STARTUP 2
#define LOG_TRAY 4
#define LOG_SHUTDOWN 8
#define log_printf(args) _log_printf args

// ==============================================================
/* stackdump.cpp - stack trace */
DWORD except_filter( EXCEPTION_POINTERS *ep );

// ==============================================================
/* pidl.cpp - shellfolders */
bool sh_getfolderpath(LPSTR szPath, UINT csidl);
char* replace_shellfolders(char *buffer, const char *path, bool search_path);

// ==============================================================
/* drag and drop - dragsource.cpp / droptarget.cpp */
void init_drop(HWND hwnd);
void exit_drop(HWND hwnd);
void drag_pidl(const struct _ITEMIDLIST *pidl);
class CDropTarget *init_drop_targ(HWND hwnd, const struct _ITEMIDLIST *pidl);
void exit_drop_targ(class CDropTarget  *);
bool in_drop(class CDropTarget *dt);

// ==============================================================
/* shell context menus */
Menu *GetContextMenu(const struct _ITEMIDLIST *pidl);

// ==============================================================
/* workspaces and tasks */
bool focus_top_window(void);
void ForceForegroundWindow(HWND theWin);
struct hwnd_list { struct hwnd_list *next; HWND hwnd; };

// ==============================================================
/* BBApi.cpp - some (non api) utils */

unsigned long getfileversion(const char *path, char *buffer);

BOOL BBExecute_command(const char *command, const char *arguments, bool no_errors);
BOOL BBExecute_string(const char *s, int flags);
bool ShellCommand(const char *cmd, const char *work_dir, bool wait);

/* tokenizer */
int nexttoken(const char **p_out, const char **p_in, const char *delims);
LPSTR NextToken(LPSTR buf, LPCSTR *string, const char *delims = NULL);

/* rc-reader */
void reset_reader(void);
void write_rcfiles(void);
FILE *create_rcfile(const char *path);
char *read_file_into_buffer(const char *path, int max_len);
char scan_line(char **pp, char **ss, int *ll);
int match(const char *str, const char *pat);
bool read_next_line(FILE *fp, LPSTR szBuffer, DWORD dwLength);
bool is_stylefile(const char *path);
int syntaxVersion(LPCSTR path);
// syntax versions - bb4win_mod
#define BBSYNTAX_070 0
#define BBSYNTAX_065 1
#define BBSYNTAX_OB 2

/* color parsing */
COLORREF ReadColorFromString(const char* string);

/* window */
void ClearSticky();
void dbg_window(HWND window, const char *fmt, ...);

/* generic hash function */
unsigned calc_hash(char *p, const char *s, int *pLen);

// ==============================================================
/* Blackbox.cpp */

void post_command(const char *cmd);
int exec_pidl(const _ITEMIDLIST *pidl, LPCSTR verb, LPCSTR arguments);
int get_workspace_number(const char *s);
void set_opaquemove(int opaque);
void set_focus_model(const char *fm_string);

/* Menu */
bool IsMenu(HWND hwnd);

// ==============================================================

/* winutils */

const char *replace_environment_strings_alloc(char **out, const char *src);
char* win_error(char *msg, int msgsize);
int is_frozen(HWND hwnd);
HWND window_under_mouse(void);
int _load_imp(void *pp, const char *dll, const char *proc);
int load_imp(void *pp, const char *dll, const char *proc);
#define have_imp(pp) ((DWORD_PTR)pp > 1)

char* get_exe_path(HINSTANCE h, char* pszPath, int nMaxLen);
char *set_my_path(HINSTANCE h, char *dest, const char *fname);
const char *get_relative_path(HINSTANCE h, const char *path);
int is_absolute_path(const char *path);
char *quote_path(char *path);

int BBWait(int delay, unsigned nObj, HANDLE *pObj);
void BBSleep(unsigned millisec);
int run_process(const char *cmd, const char *dir, int flags);
#define RUN_SHOWERRORS  0
#define RUN_NOERRORS    1
#define RUN_WAIT        2
#define RUN_HIDDEN      4
#define RUN_NOARGS      8
#define RUN_NOSUBST    16
#define RUN_ISPIDL     32
#define RUN_WINDIR     64

void unregister_fonts(void);
void register_fonts(void);

// ==============================================================
/* Experimental Nationalized Language support */

#ifdef BBOPT_SUPPORT_NLS
const char *nls1(const char *p);
const char *nls2a(const char *i, const char *p);
const char *nls2b(const char *p);
void free_nls(void);
#define NLS0(S) S
#define NLS1(S) nls1(S)
#define NLS2(I,S) nls2b(I S)
#else
#define free_nls()
#define NLS0(S) S
#define NLS1(S) (S)
#define NLS2(I,S) (S)
#endif

// ==============================================================
#endif
