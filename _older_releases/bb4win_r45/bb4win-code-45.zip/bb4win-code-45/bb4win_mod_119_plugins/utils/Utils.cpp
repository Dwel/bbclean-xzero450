/*
 ============================================================================

  This file is part of the bb4win_mod source code
  Copyright � 2001-2009 The Blackbox for Windows Development Team

  http://bb4win.sourceforge.net
  http://sourceforge.net/projects/bb4win

 ============================================================================

  bb4win_mod and bb4win are free software, released under the GNU General
  Public License (GPL version 2 or later), with an extension that allows
  linking of proprietary modules under a controlled interface. This means
  that plugins etc. are allowed to be released under any license the author
  wishes. For details see:

  http://www.fsf.org/licenses/gpl.html
  http://www.fsf.org/licenses/gpl-faq.html#LinkingOverControlledInterface

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
  or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
  for more details.

 ============================================================================
*/

#include "Utils.h"

//*****************************************************************************
// utilities

//===========================================================================
// Function: select_folder
// Purpose: Locates a target folder|file
// In: BBhwnd, start location|szAppName, buffer for target folder, files?
// Out: bool
//===========================================================================

int CALLBACK BrowseCallbackProc(HWND hwnd, UINT uMsg, LPARAM lParam, LPARAM lpData)
{
	switch (uMsg)
	{
		case BFFM_INITIALIZED:
		{
			if (is_absolute_path((const char *)lpData))
				SendMessage(hwnd, BFFM_SETSELECTION, true, (LPARAM)lpData);
			else
				SetWindowText(hwnd, (char *)lpData);
			break;
		}
	}
	return 0;
}

bool select_folder(HWND hwnd, const char *title, char *path, bool files)
{
	BROWSEINFO bi;
	LPITEMIDLIST p;
	LPMALLOC pMalloc = NULL;
	SHGetMalloc(&pMalloc);

	bi.hwndOwner    = hwnd;
	bi.pidlRoot     = NULL;
	bi.lpszTitle    = "Select Folder...";
	bi.ulFlags      =  files ? BIF_USENEWUI | BIF_BROWSEINCLUDEFILES : BIF_USENEWUI;
	bi.lpfn         = BrowseCallbackProc;
	bi.lParam       = (LPARAM)title;
	p = SHBrowseForFolder(&bi);
	path[0] = 0;
	if (p)
	{
		SHGetPathFromIDList(p, path);
		pMalloc->Free(p);
	}
	pMalloc->Release();
	return NULL != p;
}

//===========================================================================
