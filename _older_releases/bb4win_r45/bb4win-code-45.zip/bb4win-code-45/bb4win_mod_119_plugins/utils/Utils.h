/*
 ============================================================================

  This file is part of the Blackbox for Windows source code
  Copyright � 2001-2009 The Blackbox for Windows Development Team

  http://bb4win.sourceforge.net
  http://sourceforge.net/projects/bb4win

 ============================================================================

  Blackbox for Windows is free software, released under the GNU General
  Public License (GPL version 2 or later), with an extension that allows
  linking of proprietary modules under a controlled interface. This means
  that plugins etc. are allowed to be released under any license the author
  wishes. For details see:

  http://www.fsf.org/licenses/gpl.html
  http://www.fsf.org/licenses/gpl-faq.html#LinkingOverControlledInterface

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
  or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
  for more details.

 ============================================================================
*/

#ifndef _UTILS_H
#define _UTILS_H

#ifdef BBLIB_COMPILING
# ifndef WINVER
#  define WINVER 0x0500
#  define _WIN32_WINNT 0x0500
#  define _WIN32_IE 0x0501
# endif
# define WIN32_LEAN_AND_MEAN
# include <windows.h>
# include <stdlib.h>
# include <stdio.h>
# ifndef BBLIB_STATIC
#  define DLL_EXPORT __declspec(dllexport)
# endif
#endif

#ifndef DLL_EXPORT
# define DLL_EXPORT
#endif

/*------------------------------------------ */
/* compiler specifics */
/*------------------------------------------ */

#ifdef __GNUC__
  #ifndef _WIN32_IE
  #define _WIN32_IE 0x0500
  #endif
  #ifndef __BBCORE__
    #define GetBlackboxPath _GetBlackboxPath
  #endif
#endif

#ifdef __BORLANDC__
  #define DLL_EXPORT /* .def file required to work around underscores */
  #define _RWSTD_NO_EXCEPTIONS 1
#endif

#ifdef _MSC_VER
	#pragma warning(disable : 4996)
	#pragma comment(lib, "user32.lib")
	#pragma comment(lib, "gdi32.lib")
	#pragma comment(lib, "shell32.lib")
#endif

#if _MSC_VER > 1000
#pragma once
#endif

/*------------------------------------------ */
/* plain C support */

#ifndef __cplusplus
  //typedef char bool;
  #define false 0
  #define true 1
  #define ISNULL
  #define class struct
#else
  #define ISNULL =NULL
#endif

//#include <shellapi.h>
#include "../lib/bblib.h"
#include <windows.h>
#include <shlobj.h>

#ifdef MAX_LINE_LENGTH
    #undef MAX_LINE_LENGTH
#endif
#define MAX_LINE_LENGTH                 1024

/*------------------------------------------ */
/* Convenience defs */
#define IS_SPC(c) ((unsigned char)(c) <= 32)
#define IS_SLASH(c) ((c) == '\\' || (c) == '/')

/*=========================================================================== */
/* Exported functions */

#ifdef __cplusplus
extern "C" {
#endif

	/* other */
	DLL_EXPORT bool select_folder(HWND hwnd, const char *title, char *path, bool files);

#ifdef __cplusplus
}
#endif

// ==============================================================
#endif
