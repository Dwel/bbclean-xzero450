/*
 ============================================================================

  This file is part of bbIconBox+ source code.
  bbIconBox+ is a plugin for Blackbox for Windows

  Copyright � 2004 grischka
  Copyright � 2009 The Blackbox for Windows Development Team
  http://bb4win.sf.net/bblean
  http://bb4win.sourceforge.net

 ============================================================================

  bbIconBox is free software, released under the GNU General Public License
  (GPL version 2 or later).

  http://www.fsf.org/licenses/gpl.html

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

 ============================================================================
*/

//#define INCLUDE_MODE_DESK

//#define _WIN32_WINNT 0x0500
//#define _WIN32_IE 0x0500
#include "BBApi.h"
#include "Utils.h"
#include "bblib.h"
#include <ole2.h>
#include "bbPlugin.h"
#include "drawico.h"
#include "bbIconBox+.h"
#include "../../blackbox/Menu/DragSource.cpp"

//===========================================================================

const char szVersion []      = "bbIconBox+ 4.0";
const char szAppName [] 	 = "bbIconBox";
const char szInfoVersion []  = "4.0";
const char szInfoAuthor []   = "grischka|TheDevTeam";
const char szInfoRelDate []  = "2009-06-01";
const char szInfoLink []     = "http://bb4win.sourceforge.net/";
const char szInfoEmail []    = "irc://irc.freenode.net/bb4win";
const char szInfoUpdateURL[] = "http://www.lostinthebox.com/viewforum.php?f=50&t=2990";
const char szCopyright []    = "2005-2009 grischka";

LPCSTR pluginInfo(int field)
{
	switch (field)
	{
		default:
		case 0: return szVersion;
		case 1: return szAppName;
		case 2: return szInfoVersion;
		case 3: return szInfoAuthor;
		case 4: return szInfoRelDate;
		case 5: return szInfoLink;
		case 6: return szInfoEmail;
		case 8: return szInfoUpdateURL;
	}
}

//===========================================================================
// Global variables

HWND BBhwnd;    // Blackbox window handle
static char *BBVersion;
struct icon_box *g_PI;
int currentDesk;
int box_count;
char create_path[MAX_PATH];
BOOL (WINAPI*pAllowSetForegroundWindow)(DWORD);
tasklist* (*tlGetTaskListPtr)(void)= NULL;
struct tasklist *tl;
#define ASFW_ANY ((DWORD)-1) // all processes

HINSTANCE g_hInstance;
HWND g_hSlit;
char g_rcpath[MAX_PATH];

struct icon_box *new_folder (const char *name, const char *path);
#define NOT_XOBLITE strlen(BBVersion) != 7 || strlen(BBVersion) == 5
#define BB4WIN strlen(BBVersion) == 5
#define BBLEANMOD strlen(BBVersion) == 9
#define BB4WIN_MOD strlen(BBVersion) == 10

//===========================================================================
// The icon_box class

LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

struct icon_box : public plugin_info
{
	~icon_box();

	LRESULT wnd_proc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam, LRESULT *ret);
	void GetIconRect(int i, LPRECT rect);
	void GetStyleSettings();
	bool GetRCSettings(void);
	void Paint(HDC hdc);
	void write_rc(void *v);

	int CheckMouse(POINT mousepos);
	void handle_mouse_move(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

	void show_menu(bool f);
	void show_broams_menu(bool f);

	void CalcMetrics(int*, int*);
	void UpdateMetrics();
	void process_broam(const char *temp, int f);
	void invalidate(void);
	void register_msg(bool);

	void paint_icon(HDC hdc, int index, bool active, bool sunken);
	void paint_text(HDC hdc, RECT *r, StyleItem *pSI, StyleItem *pTC, bool centerd, const char *text);

	//====================
	int GetFolderSize();
	Item *GetFolderIcon(int n);
	void ClearFolder();

	int MouseEvent(HWND hwnd, unsigned int message, WPARAM wParam, LPARAM lParam);
	virtual int MouseAction(HWND hwnd, unsigned int message, WPARAM wParam, POINT *p, int index) { return 0; }
	virtual void LoadFolder() {}

	void paint_background(HDC hdc);

	//====================

	COLORREF styleBorderColor;
	int styleBevelWidth;
	int styleBorderWidth;

	//====================

	int rows;
	int columns;

	bool DrawBorder;
	bool drawTitle;
	bool tooltips;
	int stylePtr;

	int titleHeight;
	int titleMargin;
	int titleBorder;

	int iconWidth;
	int iconHeight;
	int iconPadding;
	int outerMargin;

	int activeIcon;
	int capturedIcon;
	bool mouse_over;

	HBITMAP my_bmp;
	Folder my_Folder;
	bool is_single_task;

	char m_szInstName [40];
	char m_name [40];
	char m_title [80];
	int index;

	// for drag
	int mousedown_x;
	int mousedown_y;
};

//===========================================================================
// destructor

icon_box::~icon_box()
{
	//dbg_printf("deleting icon_box");
	ClearFolder();

	if (my_Folder.drop_target)
	{
		exit_drop_targ(my_Folder.drop_target);
	}

	if (hwnd)
	{
		ClearToolTips(hwnd);
		BBP_Exit_Plugin(this);
	}

	if (my_bmp) DeleteObject(my_bmp);

#ifdef INCLUDE_MODE_DESK
	if (MODE_DESK == my_Folder.mode)
	{
		free_winlist();
	}
#endif

	struct icon_box **p = &g_PI; int n = 0;
	while (*p)
	{
		if (this == *p)
			*p = (struct icon_box*)(*p)->next;
		else
		{
			(*p)->index = n++;
			p = (struct icon_box**)&(*p)->next;
		}
	}

	--box_count;
}

//===========================================================================
// shell support forks

LPCSTR bbVersion()
{
	static BOOL(WINAPI*pMakeMenuSEP)(Menu *PluginMenu);	
	LPCSTR bbv = GetBBVersion();
	if (0 == _memicmp(bbv, "bbLean (boxCore", 14)) return "boxCore";
	if (0 == _memicmp(bbv, "bbLean 1.16 (bbClean", 20)) return "bbCleanNEB";
	if (0 == _memicmp(bbv, "bbLean|bb4win_mod", 17)) return "bb4win_mod";
	if (0 == (_memicmp(bbv, "bb", 2) + strlen(bbv) - 3)) return "xoblite";
	if (0 == _memicmp(bbv, "0", 1)) return "bb4win";
	*(FARPROC*)&pMakeMenuSEP = GetProcAddress((HINSTANCE)GetModuleHandle(NULL),"MakeMenuSEP");
	if (pMakeMenuSEP) return "bbLeanMod";
	if (0 == strlen(bbv) - 11) return bbv;
	return bbv;
}

int message_box(int flg, const char *fmt, ...)
{
    int (*pBBMessageBox)(int flg, LPCSTR fmt);
    *(FARPROC*)&pBBMessageBox = GetProcAddress(GetModuleHandle(NULL), "BBMessageBox");
    if (0 != pBBMessageBox)
        return pBBMessageBox(flg, fmt);
	char buff[16];
	sprintf(buff, "%s %s", bbVersion(), GetBBVersion());
	return MessageBox(NULL, fmt, buff, flg|MB_TOPMOST|MB_SETFOREGROUND);
}

//===========================================================================
// Function: BBDrawText
// Purpose: draws text with(out) shadows
// In:
// Out:
//===========================================================================
#define _CopyOffsetRect(lprcDst, lprcSrc, dx, dy) (*lprcDst).left = (*lprcSrc).left + (dx), (*lprcDst).right = (*lprcSrc).right + (dx), (*lprcDst).top = (*lprcSrc).top + (dy), (*lprcDst).bottom = (*lprcSrc).bottom + (dy)

void BBDrawText(HDC hDC, const char *lpString, int nCount, RECT *lpRect, unsigned uFormat, StyleItem * pSI)
{
#ifdef NOT_XOBLITE  
	if (pSI->ShadowXY)
	{
		RECT Rs;
		COLORREF cr0;
		bool outlineText = ReadBool(bbrcPath(), "session.outlineText:", false);
		if (outlineText || pSI->FontShadow)
		{
			cr0 = SetTextColor(hDC, pSI->OutlineColor);
			for (int i = 0; i < (2 + pSI->ShadowX); i++){
				for (int j = 0; j < (2 + pSI->ShadowY); j++){
					_CopyOffsetRect(&Rs, lpRect, i, j);
					DrawText(hDC, lpString, nCount, &Rs, uFormat);
				}
			}
			if (pSI->ShadowColor != pSI->TextColor)
			{
				cr0 = SetTextColor(hDC, pSI->ShadowColor);
				for (int i = 0; i < 3; i++){
					for (int j = 0; j < 3; j++){
						_CopyOffsetRect(&Rs, lpRect, i-pSI->ShadowX, j-pSI->ShadowY);
						DrawText(hDC, lpString, nCount, &Rs, uFormat);
					}
				}
			}
		}
		else
		{
			cr0 = SetTextColor(hDC, pSI->ShadowColor);
			_CopyOffsetRect(&Rs, lpRect, pSI->ShadowX, pSI->ShadowY);
			DrawText(hDC, lpString, nCount, &Rs, uFormat);
		}
		SetTextColor(hDC, cr0);
	}
#endif
	DrawText(hDC, lpString, nCount, lpRect, uFormat);
}

//===========================================================================

void write_boxes(void)
{
	char rckey[80];
	sprintf(rckey, "%s.id.count:", szAppName);
	WriteInt(g_rcpath, rckey, box_count);

	struct icon_box *p = g_PI; int n = 0;
	while (p)
	{
		sprintf(rckey, "%s.id.%d:", szAppName, ++n);
		WriteString(g_rcpath, rckey, p->m_name);
		p = (struct icon_box *)p->next;
	}
}

//===========================================================================

tasklist* bbIconBox_GetTaskListPtr(void)
{
	if (NULL == tlGetTaskListPtr) 
	{
		message_box(MB_OK, "bbIconBox_GetTaskListPtr NO");
		return NULL;
	}
	
	return tlGetTaskListPtr();
}

//===========================================================================
// Get the item count

int icon_box::GetFolderSize()
{
	int n = 0;
	Item *p = my_Folder.items;
	while (p) n++, p = p -> next;
	return n;

}

//===========================================================================
// Get one item per index

Item *icon_box::GetFolderIcon(int n)
{
	int i = 0;
	Item *p = my_Folder.items;
	while (i < n && p) i++, p = p -> next;
	return p;
}

//===========================================================================
// Clean up items

void icon_box::ClearFolder()
{
	::ClearFolder(&this->my_Folder);
}

//===========================================================================

BOOL tray_enum_func(systemTray *icon, LPARAM lParam)
{
	Item * item = new Item;
	*(Item ***)lParam = &(**(Item ***)lParam=item)->next;
	item->next = NULL;
	item->pidl = NULL;
	item->hIcon = icon->hIcon;
	strcpy_max(item->szTip, icon->szTip, sizeof item->szTip);
	item->is_folder = false;
		icon = NULL;
	return TRUE;
}

struct task_enum { Item **pItems; int desk; int icon_size; };

BOOL task_enum_func(tasklist *icon, LPARAM lParam)
{
	task_enum *te = (task_enum*)lParam;
	if (te->desk == 0 || icon->wkspc + 1 == te->desk)
	{
		Item * item = new Item;
		te->pItems = &(*te->pItems=item)->next;
		item->next = NULL;
		*(HWND*)&item->pidl = icon->hwnd;
		strcpy_max(item->szTip, icon->caption, sizeof item->szTip);
		item->is_folder = false;
		item->active = icon->active || icon->flashing;

		item->hIcon = icon->icon;
		if (te->icon_size > 24 && g_PI->is_visible)
		{
			HICON hIco = NULL;
			HWND hwnd = icon->hwnd;
			SendMessageTimeout(hwnd, WM_GETICON, ICON_BIG, 0, SMTO_ABORTIFHUNG|SMTO_BLOCK, 300, (DWORD*)&hIco);
			if (NULL==hIco) hIco = (HICON)GetClassLong(hwnd, GCL_HICON);
			if (hIco) item->hIcon = hIco;
			hwnd = NULL;
		}

		if (NULL == item->hIcon)
			item->hIcon = LoadIcon(NULL, IDI_APPLICATION);

		icon = NULL;
	}
	return TRUE;
}

BOOL desk_enum_func(DesktopInfo *icon, LPARAM lParam)
{
	Item * item = new Item;
	*(Item ***)lParam = &(**(Item ***)lParam=item)->next;
	item->next = NULL;
	*(int*)&item->pidl = icon->number;
	item->hIcon = NULL;
	item->is_folder = false;
	item->active = icon->isCurrent;
	strcpy_max(item->szTip, icon->name, sizeof item->szTip);
	return TRUE;
}

//===========================================================================

struct tray_box : icon_box
{
	tray_box()
	{
		BBP_clear(this);
		my_Folder.mode = MODE_TRAY;
	}
	void LoadFolder(void)
	{
		ClearFolder();
		Item **pItems = &my_Folder.items;
		EnumTray(tray_enum_func, (LPARAM)&pItems);
	}

	int MouseAction(HWND hwnd, unsigned int message, WPARAM wParam, POINT *p, int index)
	{
		systemTray *icon = GetTrayIcon(index-1);
		if (icon)
		{
			HWND iconWnd = icon->hWnd;
			if (IsWindow(iconWnd))
			{
				if (WM_MOUSEMOVE != message && pAllowSetForegroundWindow)
					pAllowSetForegroundWindow(ASFW_ANY);

				// Reroute the mouse message to the tray icon's host window...
				SendNotifyMessage(iconWnd, icon->uCallbackMessage, icon->uID, message);
			}
			else
			{
				PostMessage(BBhwnd, BB_CLEANTRAY, 0, 0);
			}
		}
		return 0;
	}
};

// ----------------------------------------------
struct task_box : icon_box
{
	task_box(int n)
	{
		BBP_clear(this);
		my_Folder.mode = MODE_TASK;
		my_Folder.desk = n;
		is_single_task = n > 0;
	}
	void LoadFolder(void)
	{
		ClearFolder();
		task_enum te = { &my_Folder.items, my_Folder.desk, iconWidth };
		EnumTasks(task_enum_func, (LPARAM)&te);
		if (NULL == my_Folder.drop_target) my_Folder.drop_target = init_drop_targ(hwnd);
	}

void show_broams_menu(bool pop)
{
	n_menu *broamsMenu;

	broamsMenu = n_makemenu("bbIconBox Broams");

	n_menuitem_cmd(broamsMenu, "Rollup", "@BBCore.Shade");
	n_menuitem_cmd(broamsMenu, "Lower", "@BBCore.Lower");
	n_menuitem_cmd(broamsMenu, "Minimise", "@BBCore.Minimize");
	n_menuitem_cmd(broamsMenu, "Close", "@BBCore.Close");

	n_menuitem_nop(broamsMenu, NULL);

	n_menuitem_cmd(broamsMenu, "Max Height", "@BBCore.MaximizeVertical");
	n_menuitem_cmd(broamsMenu, "Max Width", "@BBCore.MaximizeHorizontal");
	n_menuitem_cmd(broamsMenu, "Full Maximise", "@BBCore.Maximize");
	if (BBLEANMOD) // bbLeanMod
		n_menuitem_nop(broamsMenu, NULL);
	if (BBLEANMOD || (BB4WIN_MOD && g_PI->usingWin2kPlus))
		n_menuitem_cmd(broamsMenu, "Minimise To Tray",	"@BBCore.MinimizeToTray");

	if (BB4WIN_MOD)
		n_menuitem_nop(broamsMenu, NULL);

	n_menuitem_cmd(broamsMenu, "Make Sticky", "@BBCore.StickWindow");
	if (BB4WIN_MOD)
		n_menuitem_cmd(broamsMenu, "Always On Top", "@BBCore.AlwaysOnTop");

	n_menuitem_nop(broamsMenu, NULL);

	n_menuitem_cmd(broamsMenu, "Next Window Left", "@BBCore.NextWindow");
	n_menuitem_cmd(broamsMenu, "Next Window Right", "@BBCore.PrevWindow");

	n_menuitem_nop(broamsMenu, NULL);

	n_menuitem_cmd(broamsMenu, "Move Window Left", "@BBCore.MoveWindowLeft");
	n_menuitem_cmd(broamsMenu, "Left Workspace", "@BBCore.LeftWorkspace");
	n_menuitem_cmd(broamsMenu, "Move Window Right", "@BBCore.MoveWindowRight");
	n_menuitem_cmd(broamsMenu, "Right Workspace", "@BBCore.RightWorkspace");

	/*n_menuitem_nop(broamsMenu, NULL);*/


	n_menuitem_nop(broamsMenu, NULL);

	n_menuitem_cmd(broamsMenu, "Minimize All", "@BBCore.MinimizeAll");
	n_menuitem_cmd(broamsMenu, "Restore All", "@BBCore.RestoreAll");
	n_menuitem_cmd(broamsMenu, "Cascade", "@BBCore.Cascade");
	n_menuitem_cmd(broamsMenu, "Tile Horizontal", "@BBCore.TileHorizontal");
	n_menuitem_cmd(broamsMenu, "Tile Vertical", "@BBCore.TileVertical");

	n_menuitem_nop(broamsMenu, NULL);

	n_menuitem_cmd(broamsMenu, "Edit Settings", "EditRc");
	n_menuitem_cmd(broamsMenu, "Documentation", "@bbIconBox.LoadDocs");
	n_menuitem_cmd(broamsMenu, "About", "About");
	n_showmenu(broamsMenu, this->broam_key, pop);
}

	int MouseAction(HWND hwnd, unsigned int message, WPARAM wParam, POINT *p, int index)
	{
		Item *item;
		if (0 == index)
		{
			RECT r = { 0, 0, width, height };
			if (PtInRect(&r, *p) && my_Folder.desk)
			{
				if (message == WM_LBUTTONUP)
					PostMessage(BBhwnd, BB_WORKSPACE, BBWS_SWITCHTODESK, my_Folder.desk-1);
			}
		}
		else
		if (NULL != (item = GetFolderIcon(index-1)))
		{
			HWND taskwnd = (HWND)item->pidl;
			bool shift_pressed = wParam & MK_SHIFT;
			bool sysmenu = false;
			switch (message)
			{
#if 0
				case WM_LBUTTONDOWN: min_max:
					if (sysmenu && item->active && !IsIconic(taskwnd)) goto minimize;
					if (shift_pressed) PostMessage(BBhwnd, BB_BRINGTOFRONT, BBBTF_CURRENT, (LPARAM)taskwnd);
					if (wParam & MK_CONTROL) show_broams_menu(true);
					else PostMessage(BBhwnd, BB_BRINGTOFRONT, 0,  (LPARAM)taskwnd);
					break;

				case WM_RBUTTONUP:
					//if (sysmenu) ShowSysmenu(taskwnd, hwnd);
					break;

				case WM_RBUTTONDOWN:
				case WM_RBUTTONDBLCLK:
					if (sysmenu) break;
					if (shift_pressed) PostMessage(BBhwnd, BB_WINDOWCLOSE, 0, (LPARAM)taskwnd);
					else minimize: PostMessage(BBhwnd, BB_WINDOWMINIMIZE, 0, (LPARAM)taskwnd);
					break;

				case WM_LBUTTONDBLCLK:
					if (sysmenu) goto min_max;
				case WM_MBUTTONDBLCLK:
				case WM_MBUTTONDOWN:
					if (shift_pressed) PostMessage(BBhwnd, BB_WORKSPACE, 6, (LPARAM)taskwnd);
					else PostMessage(BBhwnd, BB_WORKSPACE, 7, (LPARAM)taskwnd);
					break;
#else
				//====================
				static char dblclk;

				// Restore and focus window
				case WM_LBUTTONUP:
					if (sysmenu && item->active && !IsIconic(taskwnd)) goto minimize;
					if (dblclk) goto move_wnd;
					if (shift_pressed) PostMessage(BBhwnd, BB_BRINGTOFRONT, BBBTF_CURRENT, (LPARAM)taskwnd);
					if (wParam & MK_RBUTTON) show_broams_menu(true);
					else PostMessage(BBhwnd, BB_BRINGTOFRONT, 0,  (LPARAM)taskwnd);
					item->active = true;
					break;

				//====================
				// Minimize (iconify) window

				case WM_RBUTTONUP:
					if (sysmenu) ;//ShowSysmenu(taskwnd, hBBSystembarWnd);
					else
					if (shift_pressed) PostMessage(BBhwnd, BB_WINDOWCLOSE, 0, (LPARAM)taskwnd);
					else minimize: PostMessage(BBhwnd, BB_WINDOWMINIMIZE, 0, (LPARAM)taskwnd);
					break;

				//====================

				case WM_LBUTTONDBLCLK:
				case WM_RBUTTONDBLCLK:
					dblclk = 1;
					break;

				case WM_RBUTTONDOWN:
				case WM_LBUTTONDOWN:
					dblclk = 0;
					  break;

				// Move window to the next/previous workspace
				case WM_MBUTTONUP: move_wnd:
					if (shift_pressed) PostMessage(BBhwnd, BB_WORKSPACE, BBWS_MOVEWINDOWLEFT, (LPARAM)taskwnd);
					else PostMessage(BBhwnd, BB_WORKSPACE, BBWS_MOVEWINDOWRIGHT, (LPARAM)taskwnd);
					PostMessage(BBhwnd, BB_BRINGTOFRONT, BBBTF_CURRENT, (LPARAM)taskwnd);
					break;
#endif
			}
		}
		return 0;
	}
};

// ----------------------------------------------
#ifdef INCLUDE_MODE_DESK
struct desk_box : icon_box
{
	desk_box()
	{
		BBP_clear(this);
		my_Folder.mode = MODE_DESK;
	}

	void LoadFolder(void)
	{
		ClearFolder();
		Item **pItems = &my_Folder.items;
		EnumDesks(desk_enum_func, (LPARAM)&pItems);
	}

	int MouseAction(HWND hwnd, unsigned int message, WPARAM wParam, POINT *p, int index)
	{
		Item *item = GetFolderIcon(index-1);
		if (item && message == WM_LBUTTONUP)
		{
			RECT iconRect; GetIconRect(index-1, &iconRect);
			int n; for (n = 0; n< winCount; n++)
			{
				winStruct *w = get_winstruct(n);
				if (w->info.desk == (int)item->pidl)
				{
					RECT r; get_virtual_rect(&iconRect, w, &r);
					if (PtInRect(&r, *p))
					{
						PostMessage(BBhwnd, BB_BRINGTOFRONT, 0, (LPARAM)w->window);
						break;
					}
				}
			}
			if (n == winCount)
				PostMessage(BBhwnd, BB_WORKSPACE, BBWS_SWITCHTODESK, (int)item->pidl);
		}
		return 0;
	}
};
#endif

// ----------------------------------------------
struct folder_box : icon_box
{
	folder_box()
	{
		BBP_clear(this);
		my_Folder.mode = MODE_FOLDER;
	}

	void LoadFolder(void)
	{
		ClearFolder();
		::LoadFolder(&this->my_Folder, this->iconWidth, !this->auto_hidden, this->hwnd);
		if (NULL == my_Folder.drop_target)
			my_Folder.drop_target = init_drop_targ(hwnd);
	}

	int MouseAction(HWND hwnd, unsigned int message, WPARAM wParam, POINT *p, int index)
	{
		// start weeding out spurious messages
		MSG msg;
		while (::PeekMessage (&msg, hwnd, WM_MOUSEMOVE, WM_MOUSEMOVE, PM_REMOVE));

		Item *item = GetFolderIcon(index-1);
		if (item)
		{
			if (message == WM_LBUTTONUP)
			{
				exec_pidl(item->pidl, NULL);
			}
			/*else*/if (message == WM_RBUTTONUP)
			{
				SendMessage(BBhwnd, BB_MENU, BB_MENU_CONTEXT, (LPARAM)item->pidl);
			}
			/*else*/if (message == WM_MOUSEMOVE)
			{
				if ((wParam & MK_LBUTTON) | (wParam & MK_RBUTTON))
				{
					// make sure mouse actually moved ... don't ask
					// v0.3.2 add "move threshold"
					int movethreshold = iconWidth / 5;
					if (abs((*p).x - mousedown_x) > movethreshold ||
							abs((*p).y - mousedown_y) > movethreshold)
						drag_pidl(item->pidl);
				}
			}
		}
		return 0;
	}

};

//===========================================================================
// Get info about the item under mouse while in a drag & drop operation

const struct _ITEMIDLIST *indrag_get_pidl(HWND hwnd, POINT *pt)
{
	icon_box *DI = (icon_box *)GetWindowLong(hwnd, 0);
	POINT p = *pt;
	ScreenToClient(hwnd, &p);

	int index = DI->CheckMouse(p);
	Item *icon = index ? DI->GetFolderIcon(index-1) : NULL;

	if (MODE_TASK == DI->my_Folder.mode)
	{
		HWND task = NULL;
		if (icon) task = (HWND)icon->pidl;
		if (DI->my_Folder.task_over != task)
		{
			DI->my_Folder.task_over = task;
			if (task) SetTimer(hwnd, TASK_RISE_TIMER, 330, 0);
		}
		return NULL;
	}

	SendMessage(hwnd, WM_MOUSEMOVE, 0, MAKELPARAM(p.x, p.y));

	if (index)
	{
		if (icon) return icon->pidl;
	}
	else
	//if (p.y < DI->titleHeight)
	{
		if (DI->my_Folder.pidl_list)
			return DI->my_Folder.pidl_list->v;
	}
	return NULL;
}

void handle_task_timer(HWND task_over)
{
	if (NULL == task_over) return;
	DWORD ThreadID1 = GetWindowThreadProcessId(GetForegroundWindow(), NULL);
	DWORD ThreadID2 = GetCurrentThreadId();
	if (ThreadID1 != ThreadID2)
	{
		AttachThreadInput(ThreadID1, ThreadID2, TRUE);
		SetForegroundWindow(BBhwnd);
		AttachThreadInput(ThreadID1, ThreadID2, FALSE);
	}
	PostMessage(BBhwnd, BB_BRINGTOFRONT, 0, (LPARAM)task_over);
}

//===========================================================================
// New bitmap required...

void icon_box::invalidate()
{
	if (my_bmp) DeleteObject(my_bmp), my_bmp = NULL;
	InvalidateRect(this->hwnd, NULL, FALSE);
}

//===========================================================================
// Function: CalcMetrics
// Purpose:  Define the icon rect
// In: int position, LPRECT rect
// Out: void
//===========================================================================

void icon_box::CalcMetrics(int *w, int *h)
{
	iconHeight = iconWidth;
#ifdef INCLUDE_MODE_DESK
	if (MODE_DESK == my_Folder.mode)
	{
		if (iconWidth >= 24)
			iconHeight = iconWidth * 3 / 4;
	}
#endif

	int Foldersize = GetFolderSize();
	int spacing = 2 * outerMargin - iconPadding;
	int icon_dist_x = iconWidth + iconPadding;
	int icon_dist_y = iconHeight + iconPadding;
	int xn, yn;

	if (0 == Foldersize) Foldersize = 1;

	if (this->orient_vertical)
	{
		xn = columns;
		yn = (Foldersize + columns - 1)/columns;
	}
	else
	{
		yn = rows;
		xn = (Foldersize + rows - 1)/rows;
	}

	*w = xn * icon_dist_x + spacing;
	*h = yn * icon_dist_y + spacing + titleHeight;

}

//===========================================================================
// Function: UpdateMetrics
// Purpose:  Define the icon rect
// In: int position, LPRECT rect
// Out: void
//===========================================================================

void icon_box::UpdateMetrics()
{
	int w, h;
	CalcMetrics(&w, &h);
	invalidate();
	BBP_set_size(this, w, h);
}

//===========================================================================
// Function: GetIconRect
// Purpose:  Define the icon rect
// In: int position, LPRECT rect
// Out: void
//===========================================================================

void icon_box::GetIconRect(int i, LPRECT rect)
{
	int is_x = iconWidth;
	int is_y = iconHeight;
	int icon_dist_x = is_x + iconPadding;
	int icon_dist_y = is_y + iconPadding;

	int row, col;

	if (false == orient_vertical)
		col = i / rows, row = i % rows;
	else
		row = i / columns, col = i % columns;

	rect->left   = outerMargin + col * icon_dist_x;
	rect->top    = outerMargin + row * icon_dist_y + titleHeight;
	rect->right  = rect->left + is_x;
	rect->bottom = rect->top  + is_y;
}

//===========================================================================
// Function: CheckMouse
// Description: Checks if the cursor is over an icon or not
//===========================================================================

int icon_box::CheckMouse(POINT mousepos)
{
	RECT r;
	int Foldersize = GetFolderSize();
	for (int i = 0; i < Foldersize; i++)
	{
		GetIconRect(i, &r);
		if (PtInRect(&r, mousepos))
			return i+1;
	}
	return 0;
}

//===========================================================================
// Function: Paint
// Purpose: ...
// In: HDC hdc
// Out: void
//===========================================================================

void icon_box::paint_text(HDC hdc, RECT *r, StyleItem *pSI, StyleItem *pTC, bool centerd, const char *text)
{
	 SetTextColor(hdc, pTC->TextColor);
	 SetBkMode(hdc, TRANSPARENT);
	 HFONT hf = CreateStyleFont(pSI);
	 HGDIOBJ oldfont = SelectObject(hdc, hf);
	 int just = DT_CENTER;

	 if (false == centerd)
	 {
		 RECT s = {0,0,0,0};
		 BBDrawText(hdc, text, -1, &s, DT_LEFT|DT_EXPANDTABS|DT_CALCRECT, pSI);
		 if (s.right < r->right - r->left)
			 just = pSI->Justify;
		 else
			 just = DT_LEFT;
	 }

	 BBDrawText(hdc, text, -1, r, just | DT_VCENTER | DT_SINGLELINE | DT_EXPANDTABS, pSI);
	 DeleteObject (SelectObject(hdc, oldfont));
}

//===========================================================================
void icon_box::paint_icon(HDC hdc, int index, bool active, bool sunken)
{
	Item *icon = GetFolderIcon(index);
	if (NULL == icon) return;

	RECT iconRect; GetIconRect(index, &iconRect);
	
	int i = SN_TOOLBARWINDOWLABEL;

	switch (this->stylePtr)
	{
	case SN_TOOLBARBUTTONP:
		i = SN_TOOLBARBUTTON;
		break;
	case SN_TOOLBARWINDOWLABEL:
		i = SN_TOOLBAR;
		break;
	case SN_MENUFRAME:
		i = SN_MENUHILITE;
		break;
	case SN_MENUHILITE:
		i = SN_MENUFRAME;
	}

	if (sunken)
	{
		StyleItem *A, *N;
		/*if (titleHeight)
		{
		N = (StyleItem*)GetSettingPtr(SN_MENUFRAME);
		A = (StyleItem*)GetSettingPtr(SN_MENUHILITE);
		}
		else*/
		{
			N = (StyleItem*)GetSettingPtr(this->stylePtr);
			A = (StyleItem*)GetSettingPtr(i);
		}

		if (A->parentRelative)
			A = (StyleItem*)GetSettingPtr(SN_TOOLBAR);

		StyleItem SI, *H;
		SI = *A, H = &SI;

		int d = 2;
		RECT r;
		r.left      = iconRect.left   - d;
		r.right     = iconRect.right  + d;
		r.top       = iconRect.top    - d;
		r.bottom    = iconRect.bottom + d;

		/*if (false == H->parentRelative)
		{*/
			/*H->bevelposition = BEVEL1;
			H->bevelstyle = BEVEL_SUNKEN;*/
			MakeStyleGradient(hdc, &r, H, false);
		/*}
		else
		{
			CreateBorder(hdc, &r, styleBorderColor, d);
		}*/
	}

	if (icon->hIcon)
	{
		DrawIconSatnHue(hdc, iconRect.left, iconRect.top, icon->hIcon, iconWidth, iconWidth, 0, NULL, DI_NORMAL, false == active, this->saturation, this->hue);
	}
#ifdef INCLUDE_MODE_DESK
	else
	if (MODE_DESK == my_Folder.mode)
	{
		StyleItem *T, *U;
		if (icon->active) T = A, U = N; else T = N, U = A;
		if (iconWidth >= 16)
		{
			int n; for (n = winCount; n--;)
			{
				winStruct *w = get_winstruct(n);;
				if (w->info.desk == (int)icon->pidl)
				{
					RECT r; get_virtual_rect(&iconRect, w, &r);
					if (w->iconic)
						CreateBorder(hdc, &r, styleBorderColor, 1);
					else
						MakeStyleGradient(hdc, &r, U, true);
				}
			}
		}
		char text[20]; sprintf(text, "%d", (int)icon->pidl + 1);
		paint_text(hdc, &iconRect, N, T, true, text);
	}
#endif
}


//===========================================================================

void icon_box::Paint(HDC hdc)
{
	int i, s = GetFolderSize();
	bool p = (NOT_XOBLITE);

#ifdef INCLUDE_MODE_DESK
	if (MODE_DESK == my_Folder.mode)
	{
		build_winlist();
		setup_ratio(iconWidth, iconHeight);
	}
#endif

	for (i = 0; i < s; i++)
	{
		paint_icon(hdc, i, false, false);
		if (tooltips)
		{
			RECT iconRect; GetIconRect(i, &iconRect);
			iconRect.right  += iconPadding;
			iconRect.bottom += iconPadding;
			SetToolTip(this->hwnd, &iconRect, GetFolderIcon(i)->szTip);

			if (MODE_TRAY == my_Folder.mode && p)
			{
				systemTray *icon = GetTrayIcon(i);
				if (icon
				 && 0 == icon->szTip[sizeof icon->szTip - 1]
				 && icon->pBalloon
				 && icon->pBalloon->uInfoTimeout
				 )
				{
					start_balloon(this, icon, iconRect);
					icon->pBalloon->uInfoTimeout = 0;
				}
			}
		}
	}
}

//===========================================================================
// Function: MouseEvent
// Purpose: ...
// In: HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam
// Out: bool
//===========================================================================

int icon_box::MouseEvent(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	POINT pt;
	pt.x = (short)LOWORD(lParam);
	pt.y = (short)HIWORD(lParam);
	int index = CheckMouse(pt);
	if (0 == index)
	{
		if (is_single_task)
		{
			this->MouseAction(hwnd, message, wParam, &pt, index);
		}
	}
	else
	if (0 == capturedIcon || index == capturedIcon)
	{
		this->MouseAction(hwnd, message, wParam, &pt, index);
	}
	return index;
}

//===========================================================================
// Unspecific utility

void track_mouse_event(HWND hwnd)
{
#if 0
	TRACKMOUSEEVENT tme;
	tme.cbSize  = sizeof(tme);
	tme.dwFlags = TME_LEAVE;
	tme.hwndTrack = hwnd;
	tme.dwHoverTime = HOVER_DEFAULT;
	_TrackMouseEvent(&tme); // commctrl api
#else
	SetTimer(hwnd, MENU_TRACKMOUSE_TIMER, 80, NULL);
#endif
}

//===========================================================================
// Function: GetStyleSettings
//===========================================================================

void icon_box::GetStyleSettings()
{
	// Get the path to the current style file...
	bool newMetrics = false;
	if (NOT_XOBLITE)
		newMetrics = 0 == (int)GetSettingPtr(SN_NEWMETRICS);
	else 
	{
		char style[MAX_PATH]; char temp[64]; 
		strcpy(style, stylePath());
		strcpy(temp, ReadString(style, "menu.frame.appearance:", "no"));
		if (strlen(temp) != 2) newMetrics = true;
	}
	
	StyleItem *T = (StyleItem*)GetSettingPtr(this->stylePtr);

	styleBorderWidth = DrawBorder ? newMetrics ? T->borderWidth : *(int*)GetSettingPtr(SN_BORDERWIDTH) : 0;
	styleBevelWidth   = newMetrics ? T->marginWidth : *(int*)GetSettingPtr(SN_BEVELWIDTH);

	iconPadding = 3;
	outerMargin = styleBorderWidth + styleBevelWidth + 2;
	titleHeight = titleBorder = titleMargin = 0;

	if (drawTitle || autoHide)
	{
		int i;

		switch (this->stylePtr)
		{
		case SN_MENUTITLE:
		case SN_MENUFRAME:
			i = this->stylePtr;
		case SN_MENUHILITE:
			i = SN_MENUTITLE;
		default:
			i = SN_TOOLBAR;
		}

		T = (StyleItem*)GetSettingPtr(i);

		HFONT hFont = CreateStyleFont(T);
		int tfh = get_fontheight(hFont);
		DeleteObject(hFont);

		if (newMetrics)
			titleHeight = tfh + 2 * T->marginWidth;
		else
			titleHeight = T->FontHeight + 2 * styleBevelWidth;

		titleMargin = (titleHeight - tfh + 1) / 2;
		titleHeight += styleBorderWidth;
		titleBorder = styleBorderWidth;
	}
}

//===========================================================================
// Function: GetRCSettings
//===========================================================================

const char *style_strings[] = {
	"not used"			,
	"Toolbar"          ,

	"Toolbar Button"    ,
	"Toolbar Button Pressed"	,
	"Toolbar Label"   ,

	"Toolbar Window Label"    ,
	"Toolbar Clock"		,
	"Menu Title"     ,

	"Menu Frame"        ,
	"Menu Hilite"      ,
	NULL
};

bool icon_box::GetRCSettings(void)
{
	const char *style_string = BBP_read_string(this, NULL, "style", "Toolbar");
	stylePtr        = get_string_index(style_string, style_strings);
	rows            = BBP_read_int(this, "rows", 4);
	columns         = BBP_read_int(this, "columns", 4);
	iconWidth       = BBP_read_int(this, "icon.size", 16);
	DrawBorder      = BBP_read_bool(this, "drawBorder", true);
	tooltips        = BBP_read_bool(this, "toolTips", true);
	drawTitle       = BBP_read_bool(this, "drawTitle", false);
	if (is_single_task) DrawBorder = true;
	BBP_read_string(this, m_title, "title", NULL);
	if (NULL == BBP_read_string(this, NULL, "path", NULL))
		write_rc(NULL);
	BBP_read_window_modes(this, szAppName);
	return true;
}

//===========================================================================
#define M_BOL 1
#define M_INT 2
#define M_STR 3


void icon_box::write_rc(void *v)
{
	struct rc { const char *key; int m; void *v; void *d; };
	struct rc m_rc [] = {
	{ "path",             M_STR, my_Folder.path    , (void*)0     },
	{ "title",            M_STR, m_title           , (void*)0     },
	{ "rows",             M_INT, &rows             , (void*)4     },
	{ "columns",          M_INT, &columns          , (void*)4     },
	{ "icon.size",        M_INT, &iconWidth        , (void*)16    },
	{ "drawTitle",        M_BOL, &drawTitle        , (void*)false },
	{ "drawBorder",       M_BOL, &DrawBorder       , (void*)true  },
	{ "toolTips",         M_BOL, &tooltips         , (void*)true  },
	{ NULL, 0, 0 }
	};

	struct rc *p = m_rc;
	do
	{
		if (NULL == v || p->v == v) switch (p->m)
		{
			case M_BOL: BBP_write_bool(this, p->key, *(bool*)p->v); break;
			case M_INT: BBP_write_int(this, p->key, *(int*)p->v); break;
			case M_STR: BBP_write_string(this, p->key, (char*)p->v); break;
		}
	} while ((++p)->key);

}

bool get_string(icon_box *di, const char *temp, const char *key, char *ip)
{
	int n = strlen(key);
	if (memicmp(temp, key, n) || ' ' != temp[n]) return false;
	strcpy(ip, temp + n + 1);
	if (di) di->write_rc(ip);
	return true;
}

bool get_int(icon_box *di, const char *temp, const char *key, int *ip)
{
	int n = strlen(key);
	if (memicmp(temp, key, n) || ' ' != temp[n]) return false;
	*ip = atoi(temp + n + 1);
	if (di) di->write_rc(ip);
	return true;
}

bool get_bool(icon_box *di, const char *temp, const char *key, bool *ip)
{
	if (stricmp(temp, key)) return false;
	*ip = false == *ip;
	if (di) di->write_rc(ip);
	return true;
}

//===========================================================================

void icon_box::process_broam(const char *temp, int f)
{
	if (f)
	{
		if (f & 2) UpdateMetrics();
		show_menu(false);
		return;
	}

	if (get_bool(this, temp, "ToggleBorder", &DrawBorder))
	{
		// Toggle border around window...
		GetStyleSettings();
		UpdateMetrics();
		show_menu(false);
		return;
	}

	if (get_bool(this, temp, "tooltips", &tooltips))
	{
		UpdateMetrics();
		show_menu(false);
		return;
	}

	if (get_bool(this, temp, "drawTitle", &drawTitle))
	{
		GetStyleSettings();
		UpdateMetrics();
		show_menu(false);
		return;
	}

	if (get_int(this, temp, "Rows", &rows))
	{
		UpdateMetrics();
		return;
	}

	if (get_int(this, temp, "Columns", &columns))
	{
		UpdateMetrics();
		return;
	}

	if (get_int(this, temp, "iconSize", &iconWidth))
	{
		LoadFolder();
		UpdateMetrics();
		return;
	}

	if (get_string(this, temp, "Title", m_title))
	{
		show_menu(false);
		UpdateMetrics();
		return;
	}

	if (!memicmp(temp, "style.", 6))
	{
		temp += 6;
		BBP_write_string(this, "style", temp);
		UpdateMetrics();
		this->GetRCSettings();
		return;
	}

	if (!stricmp(temp, "About"))
	{
	char buffer[256];
	sprintf(buffer, "%s - %s\n\n � %s\n\n %s\t%s", szVersion, szInfoRelDate, szCopyright, szInfoLink, szInfoEmail);
		message_box(MB_OK, buffer);
		return;
	}
}

//===========================================================================

void common_broam(const char *temp)
{
	char buffer[MAX_PATH];
	if (get_string(NULL, temp, "path", create_path))
	{
		return;
	}

	if (get_string(NULL, temp, "remove", buffer))
	{
		if (NULL == g_PI || NULL == g_PI->next) return;
		plugin_info *p;
		dolist (p, g_PI)
			if (0 == stricmp(((icon_box*)p)->m_name, buffer))
				break;

		if (p) PostMessage(p->hwnd, BBIB_DELETE, 0, 0);
		return;
	}

	if (get_string(NULL, temp, "create", buffer))
	{
		char name[MAX_PATH];
		char path[MAX_PATH];
		 if (0 == stricmp (buffer, "*browse*"))
		{
			if (false == select_folder(g_PI->hwnd, szAppName, path, false))
				return;
		}
		else 
		if (0 == strcmp(buffer, "PATH"))
			strcpy(path, create_path);
		else
			strcpy(path, buffer);

		if (0 == strcmp(path, "TRAY")
			|| 0 == memcmp(path, "TASK", 4)
			|| 0 == strcmp(path, "DESK")
			)
		{
			strlwr(strcpy(name, path));
		}
		else
		{
			struct pidl_node *pidl_list = get_folder_pidl_list(path);
			if (NULL == pidl_list)
			{
				MessageBox(NULL, "Invalid Path", szAppName, MB_OK|MB_TOPMOST|MB_SETFOREGROUND);
				return;
			}
			sh_getdisplayname(pidl_list->v, name);
			delete_pidl_list (&pidl_list);
		}

		int n = strlen(name);
		int x = 1;
		for (;;)
		{
			plugin_info *p;
			dolist (p, g_PI)
				if (0 == stricmp(((icon_box*)p)->m_name, name)) break;
			if (NULL == p) break;
			sprintf(name + n, "/%d", ++x);
		}
		new_folder(name, path);
		write_boxes();
		return;
	}

	return;
}

const char *name_strings[] = {
	"My Computer"          ,

	"Personal"  ,
	"Recycle Bin"    ,
	"Start Menu"   ,

	"Templates"    ,
	"App Data"		,
	"Startup"   ,

	"IE Temp Files"     ,
	"Printers"        ,
	"Recent"      ,

	"Send To"           ,
	"Fonts"          ,
	"Cookies"         ,

	"Control Panel"     ,
	"Wallpaper"     ,
	"Profile"        ,

	"Program Files"      ,
	"SysDir"           ,
	"WinDir"          ,

	"Themes"     ,
	"Music"         ,
	"Pictures"           ,

	//"Resources"          ,
	"Video"           ,
	NULL
};

const char *path_strings[] = {
	"DRIVES"          ,

	"PERSONAL|COMMON_DOCUMENTS"  ,
	"BITBUCKET"    ,
	"PROGRAMS|COMMON_PROGRAMS|STARTMENU|COMMON_STARTMENU"   ,

	"TEMPLATES|COMMON_TEMPLATES"    ,
	"APPDATA|COMMON_APPDATA|LOCAL_APPDATA"		 ,
	"STARTUP|COMMON_STARTUP|ALTSTARTUP|COMMON_ALTSTARTUP"   ,

	"INTERNET_CACHE"     ,
	"PRINTERS|PRINTHOOD"        ,
	"RECENT"      ,

	"SENDTO"           ,
	"FONTS"          ,
	"COOKIES"         ,

	"CONTROLS|ADMINTOOLS|COMMON_ADMINTOOLS"     ,
	"WINDOWS\\Web\\Wallpaper"          ,
	"PROFILE"        ,

	"PROGRAM_FILES|PROGRAM_FILES_COMMON"      ,
	"SYSTEM"           ,
	"WINDOWS"          ,

	"WINDOWS\\Resources\\Themes"          ,
	"MUSIC|COMMON_MUSIC"         ,
	"MYPICTURES|COMMON_PICTURES"           ,

	//"RESOURCES|RESOURCES_LOCALIZED"          , // returns DESKTOP
	"VIDEO|COMMON_VIDEO"           ,
	NULL
};

//===========================================================================
// Function: show_menu
// Purpose: ...
// In: void
// Out: void
//===========================================================================

void icon_box::show_menu(bool popup)
{
	n_menu *main, *sub, *sub2;
	int s = GetOSVersion();
	bool NineX = s < 50;
	bool TwoK = s < 51;
	bool VistaPlus = s > 59;
	bool Bit64 = s % 10 > 4;

	main = n_makemenu(m_name);
	BBP_n_orientmenu(this, main);
	if (orient_vertical) n_menuitem_int(main, "Columns", "Columns", columns, 1, 120);
	else n_menuitem_int(main, "Rows", "Rows", rows, 1, 120);

	sub = n_submenu(main, "Format");
	n_menuitem_bol(sub, "Draw Title", "drawTitle", drawTitle);
	if (drawTitle) n_menuitem_str(sub, "Title Text", "Title", m_title);
	if (false == is_single_task) n_menuitem_bol(sub, "Border", "ToggleBorder", DrawBorder);
	n_menuitem_bol(sub, "Tooltips", "Tooltips", tooltips);
	n_menuitem_nop(sub, NULL);
	BBP_n_insertmenu(this, sub);
	n_menuitem_int(sub, "Icon Size", "iconSize", iconWidth, 12, 64);

	sub = n_submenu(main, "Style");
	for (int n = 1; n < SN_MENUBULLET; ++n)
	{
		if (SN_TOOLBARLABEL == n)
			n = n + 1;
		if (SN_MENUTITLE == n)
			n_menuitem_nop(sub, NULL);
		char b2[80];
		sprintf(b2, "style.%s", style_strings[n]);
		n_menuitem_bol(sub, style_strings[n], b2, stylePtr == n);
	}

	n_menuitem_nop(main, NULL);
	sub = n_submenu(main, "New");
	if (NOT_XOBLITE)
	{
		sub2 = n_submenu(sub, "Task");
		n_menuitem_cmd(sub2, "All", "@bbIconBox.common.create TASK");
		DesktopInfo D; GetDesktopInfo(&D);
		for (int n = 0; n < D.ScreensX; ++n)
		{
			char b1[80]; sprintf(b1, "%d", 1+n);
			char b2[80]; sprintf(b2, "@bbIconBox.common.create TASK%d", 1+n);
			n_menuitem_cmd(sub2, b1, b2);
		}
	}

	n_menuitem_cmd(sub, "Tray", "@bbIconBox.common.create TRAY");
	if (NOT_XOBLITE)
	{
		n_menuitem_cmd(sub, "Browse...", "@bbIconBox.common.create *browse*");
		n_menuitem_nop(sub, NULL);
	}
	n_menuitem_cmd(sub, "Desktop", "@bbIconBox.common.create DESKTOP");
	n_menuitem_cmd(sub, "Quick Launch", "@bbIconBox.common.create APPDATA\\Microsoft\\Internet Explorer\\Quick Launch");

	n_menuitem_cmd(sub, VistaPlus ? "Links" : "IE Links", VistaPlus ? "@bbIconBox.common.create FAVORITES\\LINKS|COMMON_OEM_LINKS|PROFILE\\LINKS" : "@bbIconBox.common.create FAVORITES\\LINKS|COMMON_OEM_LINKS");
	n_menuitem_nop(sub, NULL);	
	n_menuitem_cmd(sub, "Favorites", "@bbIconBox.common.create FAVORITES|COMMON_FAVORITES");
	n_menuitem_cmd(sub, "Net Connections", "@bbIconBox.common.create NETWORK|NETHOOD|CONNECTIONS");
	sub2 = n_submenu(sub, "Other Paths");
	int n = 0, o = NineX ? 14 : TwoK ? 19 : (BB4WIN_MOD && VistaPlus) ? 23 : 20;
	for (; n < o; n++)
	{
		if (n % 3 == 0)
			n_menuitem_nop(sub2, NULL);

		char b0[80];
		sprintf(b0, "@bbIconBox.common.create %s", path_strings[n]);
		n_menuitem_cmd(sub2, name_strings[n], b0);
	}
	if (Bit64)
	{
		if (!BB4WIN_MOD) 
			n_menuitem_nop(sub2, NULL);	
		n_menuitem_cmd(sub2, "Program Files X86", "@bbIconBox.common.create PROGRAM_FILESX86|PROGRAM_FILES_COMMONX86");
		n_menuitem_cmd(sub2, "SysDir X86", "@bbIconBox.common.create SYSTEMX86");
	}

	sub = n_submenu(main, "Remove");
	plugin_info *p; dolist (p, g_PI)
	{
		const char *name = ((icon_box*)p)->m_name;
		if (*name)
		{
			char b2[80]; sprintf(b2, "@bbIconBox.common.Remove %s", name);
			n_menuitem_cmd(sub, name, b2);
		}
	}

	if (false == this->inSlit) 
	{
		n_menuitem_nop(main, NULL);
		BBP_n_windowmenu(this, main);
		BBP_n_placementmenu(this, main);
	}

	n_menuitem_nop(main, NULL);
	n_menuitem_cmd(main, "Edit Settings",  "EditRC");
	n_menuitem_cmd(main, "Documentation",  "loadDocs");
	n_menuitem_cmd(main, "About", "About");
	n_showmenu(main, this->broam_key, popup);
}

//===========================================================================
void icon_box::handle_mouse_move(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	if (false == this->mouse_over)
	{
		this->mouse_over = true;
		track_mouse_event(hwnd);
	}
	int i;
	if (MK_CONTROL & wParam)
		i = 0;
	else
		i = this->MouseEvent(hwnd, message, wParam, lParam);

	if (this->capturedIcon && i != this->capturedIcon)
		i = 0;

	if (i != this->activeIcon)
	{
		this->activeIcon = i;
		InvalidateRect(hwnd, NULL, FALSE);
	}
}

//===========================================================================

void icon_box::register_msg(bool set)
{
	static UINT msg_tray[] = { BB_TRAYUPDATE, 0 };
	static UINT msg_task[] = { BB_DESKTOPINFO, BB_TASKSUPDATE, 0 };

	UINT bb = set ? BB_REGISTERMESSAGE : BB_UNREGISTERMESSAGE;

	if (MODE_TASK == my_Folder.mode)
		SendMessage(BBhwnd, bb, (WPARAM)hwnd, (LPARAM)&msg_task);
	if (MODE_TRAY == my_Folder.mode)
		SendMessage(BBhwnd, bb, (WPARAM)hwnd, (LPARAM)&msg_tray);
#ifdef INCLUDE_MODE_DESK
	if (MODE_DESK == my_Folder.mode)
		SendMessage(BBhwnd, bb, (WPARAM)hwnd, (LPARAM)&msg_task);
#endif
}

//===========================================================================
void icon_box::paint_background(HDC buf)
{
	RECT r = {0, 0, this->width, this->height };

	int j = SN_TOOLBARWINDOWLABEL;
	int i = SN_TOOLBAR;

	switch (this->stylePtr)
	{
	case SN_TOOLBARBUTTONP:
		i = SN_TOOLBARBUTTON;
		j = SN_TOOLBARBUTTONP;
		break;
	case SN_TOOLBARWINDOWLABEL:
		i = SN_TOOLBAR;
		break;
	case SN_MENUFRAME:
		i = SN_MENUTITLE;
		j = this->stylePtr;
		break;
	case SN_MENUHILITE:
		i = SN_MENUTITLE;
		j = SN_MENUFRAME;
	}

	StyleItem *MT = (StyleItem*)GetSettingPtr(i);
	StyleItem *T = (StyleItem*)GetSettingPtr(j);

	StyleItem *S = (StyleItem*)GetSettingPtr(SN_TOOLBARLABEL);
	S->ColorTo = S->Color = 0;
	S->type = B_SOLID;
	S->bevelstyle = BEVEL_FLAT;
	S->bevelposition = BEVEL1;
	S->borderColor = MT->Color;
	S->borderWidth = 1;

	bool DrawBorder =
		this->is_single_task
		? this->my_Folder.desk == currentDesk + 1
		: this->DrawBorder
		;

	r.top = this->titleHeight;
	if (r.top && MT->parentRelative) r.top = 0;

	if (T->parentRelative)
		T = (StyleItem*)GetSettingPtr(SN_TOOLBAR);
	
	if (this->transparent)
		MakeStyleGradient(buf, &r, S, this->autoHide);
	else
		MakeStyleGradient(buf, &r, T, DrawBorder);

	int frameWidth = styleBorderWidth + styleBevelWidth;

	r.left  += frameWidth;
	r.top   += frameWidth;
	r.right   -= frameWidth;
	r.bottom  -= frameWidth;

	T = (StyleItem*)GetSettingPtr(this->stylePtr);
	if (T->parentRelative)
		T = (StyleItem*)GetSettingPtr(SN_TOOLBAR);

	if (this->transparent)
		MakeStyleGradient(buf, &r, S, this->autoHide);
	else
		MakeStyleGradient(buf, &r, T, DrawBorder);

	if (this->titleHeight)
	{

		int border = this->titleBorder;
		int margin = this->iconPadding + border;
		r.top = 0;
		r.bottom = this->titleHeight;
		r.top = r.left = 0;
		r.right  = this->width;
		r.bottom = this->titleHeight;

		if (MT->parentRelative && border)
			CreateBorder(buf, &r, MT->borderColor, this->titleBorder);

		r.bottom += border;

		if (false == MT->parentRelative)
			MakeStyleGradient(buf, &r, MT, DrawBorder);

		r.left += margin;
		r.right -= margin;

		if (m_title[0]) this->paint_text(buf, &r, MT, MT, false, m_title);
	}

	if (this->is_visible)
		this->Paint(buf);
	ClearToolTips(hwnd);
}
//===========================================================================

LRESULT icon_box::wnd_proc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam, LRESULT *ret)
{
	bool autoHiding = this->autoHide;
	bool hideChanged;
	if (ret)
	{
		if (WM_NCHITTEST == message && (HTTRANSPARENT == *ret))
		{
			POINT pt = { (short)LOWORD(lParam), (short)HIWORD(lParam) };
			ScreenToClient(hwnd, &pt);
			if (this->CheckMouse(pt))
			{
				return HTCLIENT;
			}
			if (this->activeIcon)
			{
				this->activeIcon = 0;
				InvalidateRect(hwnd, NULL, FALSE);
			}
		}
		return *ret;
	}

	switch (message)
	{       
		//====================
		case WM_CREATE:
			this->register_msg(true);
#ifdef BBOPT_MEMCHECK
			SetTimer(hwnd, CHECK_MEM_TIMER, 10000, NULL);
#endif
			break;

		case WM_DESTROY:
			this->register_msg(false);
			break;

		//====================
		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hwnd, &ps);
			HDC buf = CreateCompatibleDC(NULL);
			HGDIOBJ other;

			if (NULL == this->my_bmp)
			{
				this->my_bmp = CreateCompatibleBitmap(hdc, this->width, this->height);
				other = SelectObject(buf, this->my_bmp);
				paint_background(buf);
			}
			else
			{
				other = SelectObject(buf, this->my_bmp);
			}

			HDC buf2 = CreateCompatibleDC(NULL);
			HGDIOBJ otherbmp = SelectObject(buf2, CreateCompatibleBitmap(hdc, this->width, this->height ));

			BitBltRect(buf2, buf, &ps.rcPaint);

			int a = this->activeIcon;
			if (a) this->paint_icon(buf2, a-1, true, this->capturedIcon == a);

			if (this->my_Folder.mode == MODE_TASK || this->my_Folder.mode == MODE_DESK)
			{
				Item *icon = this->my_Folder.items; a = 0;
				while (icon)
				{
					if (icon->active)
					{
						this->paint_icon(buf2, a, true, true);
					}
					a++, icon = icon->next;
				}
			}

			BitBltRect(hdc, buf2, &ps.rcPaint);

			DeleteObject(SelectObject(buf2, otherbmp));
			DeleteDC(buf2);

			SelectObject(buf, other);
			DeleteDC(buf);

			EndPaint(hwnd, &ps);
		}
		break;

		//====================

		case BB_TASKSUPDATE:
			if (BB4WIN)
				set_task_flags((HWND)wParam, lParam);
		/*
			if (TASKITEM_REFRESH == lParam)
			{
				this->UpdateMetrics();
				break;
			}
		*/
			goto update;

		case BB_DESKTOPINFO:
			currentDesk = ((DesktopInfo*)lParam)->number;
			goto update;

		case BB_TRAYUPDATE:
		update:
			this->LoadFolder();
			this->UpdateMetrics();
			break;

		//====================

		// If Blackbox sends a reconfigure message, load the new style settings and update window...
		case BB_RECONFIGURE:
			this->GetRCSettings();

		case BB_REDRAWGUI:
			this->GetStyleSettings();
			this->CalcMetrics(&this->width, &this->height);
			this->invalidate();
			BBP_reconfigure(this);
			break;

		//====================

		case WM_RBUTTONUP:
			if ((MK_CONTROL & wParam))// || 0 == this->MouseEvent(hwnd, message, wParam, lParam))
			{
				this->show_menu(true);
				goto release;
			}

		case WM_LBUTTONUP:
		case WM_MBUTTONUP:
			this->MouseEvent(hwnd, message, wParam, lParam);
		release:
			ReleaseCapture();

		case WM_CAPTURECHANGED:
			this->capturedIcon = 0;
			InvalidateRect(hwnd, NULL, FALSE);
			break;

		//====================

		case WM_MOUSEMOVE:
			this->handle_mouse_move(hwnd, message, wParam, lParam);
			break;

		//====================
		case WM_RBUTTONDOWN:
		case WM_RBUTTONDBLCLK:
			if (MK_CONTROL & wParam)
				break;

		case WM_LBUTTONDOWN:
		case WM_LBUTTONDBLCLK:
		case WM_MBUTTONDOWN:
		case WM_MBUTTONDBLCLK:
			mousedown_x = (short)LOWORD(lParam);
			mousedown_y = (short)HIWORD(lParam);
			this->capturedIcon =
			this->activeIcon =
			this->MouseEvent(hwnd, message, wParam, lParam);
			InvalidateRect(hwnd, NULL, FALSE);

			if (0 == this->activeIcon
				 && message == WM_LBUTTONDOWN
				 && false == this->inSlit
				 && this->my_Folder.mode != MODE_TASK
				)
			{
				SetActiveWindow(hwnd);
				UpdateWindow(hwnd);
				PostMessage(hwnd, WM_SYSCOMMAND, 0xf012, 0);
				break;
			}

			if (this->my_Folder.mode == MODE_TRAY)
				this->capturedIcon = 0;
			else
				SetCapture(hwnd);

			break;


		//====================
		case WM_MOUSELEAVE:
			hideChanged = this->autoHide != autoHiding;
			this->mouse_over = false;
			if (this->activeIcon)
			{
				this->activeIcon = 0;
				if (hideChanged || autoHiding)
				{
					GetStyleSettings();
					goto update;
				}
				InvalidateRect(hwnd, NULL, FALSE);
			}
			else
			if (hideChanged || autoHiding)
			{
				GetStyleSettings();
				goto update;
			}
			break;

		case WM_TIMER:
			if (MENU_TRACKMOUSE_TIMER == wParam)
			{
				if (hwnd != window_under_mouse())
				{
					KillTimer(hwnd, wParam);
					PostMessage(hwnd, WM_MOUSELEAVE, 0, 0);
				}
				break;
			}

			if (TASK_RISE_TIMER == wParam)
			{
				KillTimer(hwnd, wParam);
				if (hwnd == window_under_mouse())
					handle_task_timer(this->my_Folder.task_over);
				break;
			}

		case WM_KEYUP:
		{
			if (wParam == VK_NUMPAD7) 
				BBP_set_place(this, 7);
			else if (wParam == VK_NUMPAD8) 
			{
				BBP_set_place(this, 8);
				this->orient_vertical = false;
			}
			else if (wParam == VK_NUMPAD9) 
				BBP_set_place(this, 9);
			else if (wParam == VK_NUMPAD4) 
			{
				BBP_set_place(this, 4);
				this->orient_vertical = true;
			}
			else if (wParam == VK_NUMPAD6) 
			{
				BBP_set_place(this, 6);
				this->orient_vertical = true;
			}
			else if (wParam == VK_NUMPAD1) 
				BBP_set_place(this, 1);
			else if (wParam == VK_NUMPAD2) 
			{
				BBP_set_place(this, 2);
				this->orient_vertical = false;
			}
			else if (wParam == VK_NUMPAD3) 
				BBP_set_place(this, 3);
			else if (wParam == VK_NUMPAD5 || wParam == VK_RETURN)
			{
				BBP_set_autoHide(this, false == this->autoHide);
				goto update;
			}
			else if (wParam == VK_BACK)
				SendMessage(g_PI->hwnd, BB_BROADCAST, 0, (LPARAM)"@bbIconBox.common.create *browse*");
			else if (wParam == VK_SUBTRACT)
			{
				char szTemp[MAX_PATH];
				strcpy(szTemp, this->rcpath);
				SendMessage(BBhwnd, BB_EDITFILE, (WPARAM)-1, (LPARAM)szTemp);
			}
			else if (wParam == VK_ADD)
				this->alwaysOnTop = false == this->alwaysOnTop;
			else if (wParam == VK_ESCAPE)	
				this->orient_vertical = false == this->orient_vertical;
			
			invalidate();			
		}
		break;

#ifdef BBOPT_MEMCHECK
			if (CHECK_MEM_TIMER == wParam)
			{
				if (0 == this->index)
				{
					KillTimer(hwnd, wParam);
					m_alloc_check_memory();
					char buffer[200]; sprintf(buffer, "bbIconBox mem-check: %d bytes", m_alloc_size());
					SendMessage(BBhwnd, BB_SETTOOLBARLABEL, 0, (LPARAM)buffer);
					SetTimer(hwnd, CHECK_MEM_TIMER, 10000, NULL);
				}
				break;
			}
#endif
			break;

		case BBIB_DELETE:
		{
			//char rckey[80];
			//sprintf(rckey, "%s.*:", this->rc_key);
			//DeleteSetting(g_rcpath, rckey);

			this->m_name[0] = 0;
			show_menu(false);
			delete this;
			write_boxes();
			break;
		}

		case BBIB_UPDATE:
			show_menu(false);
			break;

		case BBIB_FOLDERCHANGED:
			PostMessage(hwnd, BB_TRAYUPDATE, 0, 0);
			break;

		case BB_BROADCAST:
			if (0 == memicmp ((LPCSTR)lParam, "@bbIconBox.common.", 18))
			{
				if (g_PI == this) common_broam((LPCSTR)lParam+18);
				PostMessage(hwnd, BBIB_UPDATE, 0, 0);
			}
			break;

		default:
			return DefWindowProc(hwnd,message,wParam,lParam);

	//====================
	}
	return 0;
}

//===========================================================================
struct icon_box *new_folder (const char *name, const char *path)
{

	char instance_id[MAX_PATH];
	char box_path[MAX_PATH];
	char *q = instance_id, c; const char *p = name;
	do
	{
		c = *p++;
		if (' ' == c || '.' == c || ':' == c) *q++ = '+';
		else *q++ = c;
	} while (c);

	if (NULL == path)
	{
		char rckey[MAX_PATH];
		sprintf(rckey, "%s.%s.path:", szAppName, instance_id);
		path = strcpy(box_path, ReadString(g_rcpath, rckey, "DESKTOP"));
	}

	icon_box *DI;

	if (0 == strcmp(path, "TRAY"))
	{
		DI = new tray_box();
	}
	else
	if ((0 == memcmp(path, "TASK", 4)) && (NOT_XOBLITE))
	{
		DI = new task_box(path[4]?path[4]-'0':0);
	}
#ifdef INCLUDE_MODE_DESK
	else
	if (0 == strcmp(path, "DESK"))
	{
		DI = new desk_box();
	}
#endif
	else
	{
		DI = new folder_box();
	}

	strcpy(DI->m_name, name);
	strcpy(DI->m_title, name);
	strcpy(DI->my_Folder.path, path);
	strcpy(DI->rcpath, g_rcpath);
	sprintf(DI->m_szInstName, "%s.%s", szAppName, instance_id);

	DI->hSlit       = g_hSlit;
	DI->hInstance   = g_hInstance;
	DI->class_name  = szAppName;
	DI->rc_key      = DI->m_szInstName;
	DI->broam_key   = DI->m_szInstName;

	// Get plugin and style settings...
	if (false == DI->GetRCSettings())
	{
		delete DI;
		return false;
	}

	DI->GetStyleSettings();
	DI->CalcMetrics(&DI->width, &DI->height);
	if (false == BBP_Init_Plugin(DI))
	{
		return false;
	}

	DI->LoadFolder();
	DI->UpdateMetrics();

	DI->next = NULL;
	icon_box **pp = & g_PI;
	while (*pp) pp = (icon_box**)&(*pp)->next;
	*pp = DI;

	DI->index = box_count++;
	return DI;
}


int beginPlugin(HINSTANCE hPluginInstance);
int beginPluginEx(HINSTANCE hPluginInstance, HWND hSlit)
{
	if (BBhwnd)
	{
		MessageBox(NULL, "Dont load me twice!", szAppName, MB_OK|MB_TOPMOST|MB_SETFOREGROUND);
		return 1;
	}

	BBhwnd  = GetBBWnd();
	BBVersion = (char*)bbVersion();

	g_hSlit = hSlit;
	g_hInstance = hPluginInstance;
	*(FARPROC*)&pAllowSetForegroundWindow = GetProcAddress(GetModuleHandle("USER32"), "AllowSetForegroundWindow");
	*(FARPROC*)&tlGetTaskListPtr = GetProcAddress(GetModuleHandle(NULL), "GetTaskListPtr");

	if (NOT_XOBLITE)
		tl = bbIconBox_GetTaskListPtr();

	OleInitialize(NULL);
	InitToolTips(hPluginInstance);

	locate_file(g_hInstance, g_rcpath, szAppName, (char *)"rc");

	char rckey[80];
	sprintf(rckey, "%s.id.count:", szAppName);
	int n = ReadInt(g_rcpath, rckey, 0);
	if (n < 1) WriteInt(g_rcpath, rckey, n = 1);

	box_count = 0;
	while (box_count < n)
	{
		char buffer[MAX_PATH];
		sprintf(rckey, "%s.id.%d:", szAppName, box_count+1);
		const char *p = ReadString(g_rcpath, rckey, NULL);
		if (NULL == p)
		{
			if (box_count) break;
			WriteString(g_rcpath, rckey, p = "desktop");
		}

		if (NULL == new_folder(strcpy(buffer, p), NULL))
		{
			endPlugin(hPluginInstance);
			return 1;
		}
	}
	return 0;
}

//===========================================================================

void endPlugin(HINSTANCE hPluginInstance)
{
	while (g_PI) delete g_PI;
	ExitToolTips();
	OleUninitialize();
#ifdef BBOPT_MEMCHECK
	m_alloc_check_leaks("bbIconBox");
#endif
}

//===========================================================================
