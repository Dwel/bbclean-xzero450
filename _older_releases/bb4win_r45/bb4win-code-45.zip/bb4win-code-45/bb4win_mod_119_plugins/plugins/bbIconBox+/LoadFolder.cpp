/*
 ============================================================================

  This file is part of bbIconBox+ source code.
  bbIconBox+ is a plugin for Blackbox for Windows

  Copyright � 2004 grischka
  Copyright � 2009 The Blackbox for Windows Development Team
  http://bb4win.sf.net/bblean
  http://bb4win.sourceforge.net

 ============================================================================

  bbIconBox is free software, released under the GNU General Public License
  (GPL version 2 or later).

  http://www.fsf.org/licenses/gpl.html

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

 ============================================================================
*/

#define NO_INTSHCUT_GUIDS
#define NO_SHDOCVW_GUIDS
//#define _WIN32_WINNT 0x0500
//#define _WIN32_IE 0x0500
#include "BBApi.h"
#include "Utils.h"
#ifndef BBOPT_MEMCHECK
#define m_alloc(n) ((void*)new char[n])
#define c_alloc(n) memset(new char[n], 0, n)
#define m_free(v)  (delete[] (char*)v)
#endif
#include <commctrl.h>
#include <shlobj.h>
#include <shellapi.h>
#include "bbPlugin.h"
#include "../../blackbox/Pidl.h"
#include "bbIconBox+.h"

UINT add_change_notify_entry(HWND hwnd, const _ITEMIDLIST *pidl);
void remove_change_notify_entry(UINT id_notify);
Item *join_folders(Item *mi);

char *cut_name_from_path(char *path);
bool is_full_path(const char *path);
char* unquote(char *d, const char *s);

LPSTR NextToken(LPSTR string, const char** buf, const char *delims)
{
	int len = strlen(*buf);
	char *p = Tokenize(*buf, string, delims);
	*buf += len - strlen(p);
	return string;
}

#ifndef CSIDL_PROGRAM_FILES
#define CSIDL_PROGRAM_FILES 0x0026
#endif

#include "../../blackbox/Pidl.cpp"
#define NOT_XOBLITE strlen(BBVersion) != 7 || strlen(BBVersion) == 5

//////////////////////////////////////////////////////////////////////

void ClearFolder(Folder *pFolder)
{
	Item *item = pFolder->items;
	while (item)
	{
		if (MODE_FOLDER == pFolder->mode)
		{
			freeIDList(item->pidl);
			if (item->hIcon) DestroyIcon(item->hIcon);
		}
		Item* next = item->next;
		delete item;
		item = next;
	}
	pFolder->items = NULL;

	if (pFolder->id_notify)
	{
		remove_change_notify_entry(pFolder->id_notify);
		pFolder->id_notify = 0;
	}

	delete_pidl_list(&pFolder->pidl_list);
}

//////////////////////////////////////////////////////////////////////
// Function:    LoadFolder
// Purpose:     enumerate items in a folder, sort them, and insert them
//              into a menu
//////////////////////////////////////////////////////////////////////

void LoadFolder(Folder *pFolder, int iconsize, bool is_visible, HWND hwnd)
{
	struct pidl_node *pidl_list = get_folder_pidl_list (pFolder->path);

	//dbg_printf("path %s pidl_list %x", pFolder->path, pidl_list);

	pFolder->pidl_list = pidl_list;

	// nothing to do on NULL pidl's
	if (NULL==pidl_list)
		return;

	LPCITEMIDLIST pIDFolder = pidl_list->v;
	pFolder->id_notify = add_change_notify_entry(hwnd, pIDFolder);

	// get an interface of the task-allocator
	LPMALLOC pMalloc;
	if (NOERROR != SHGetMalloc(&pMalloc))
		return;

	Item **ppItems = &pFolder->items;
	while (pidl_list)
	{
		LPCITEMIDLIST pIDFolder = pidl_list->v;

		// get a COM interface of the folder
		IShellFolder* pThisFolder = sh_get_folder_interface(pIDFolder);
		if (pThisFolder)
		{
			LPENUMIDLIST pEnumIDList = NULL;
			HRESULT hr;

			// get the folders "EnumObjects" interface
			hr = pThisFolder->EnumObjects(
					NULL, 0
					| SHCONTF_FOLDERS
					| SHCONTF_NONFOLDERS
					//| SHCONTF_INCLUDEHIDDEN
					,
					&pEnumIDList
					);

			if (SUCCEEDED(hr))
			{
				LPITEMIDLIST pID;
				ULONG nReturned;

				// call the enum-interface, until no more items are returned
				while (S_FALSE!=pEnumIDList->Next(1, &pID, &nReturned) && 1==nReturned)
				{
					ULONG uAttr = SFGAO_FOLDER // we need to know if it's a folder
						//| SFGAO_HASSUBFOLDER
						//| SFGAO_LINK
						//| SFGAO_HIDDEN
						//| SFGAO_FILESYSTEM
						//| SFGAO_FILESYSANCESTOR
						;

					// check, if it's a folder or file
					pThisFolder->GetAttributesOf(1, (LPCITEMIDLIST*)&pID, &uAttr);
					//if (uAttr & SFGAO_LINK)

					// Join the relative item-pidl and the folder-pidl to the full path
					// (the task allocator is used to allocate the new object)
					LPITEMIDLIST pIDFull = joinIDlists(pIDFolder, pID);

					Item *item = new Item;
					item -> is_folder = uAttr & SFGAO_FOLDER;
					item -> pidl = pIDFull;

					//Pidl_GetDisplayName(pThisFolder, pID, SHGDN_NORMAL, item -> szTip);

					HIMAGELIST sysimgl;
					SHFILEINFO shinfo;
					UINT cbfileinfo;

					cbfileinfo = SHGFI_PIDL | SHGFI_SYSICONINDEX | SHGFI_SHELLICONSIZE | SHGFI_DISPLAYNAME;
					//cbfileinfo = SHGFI_PIDL | SHGFI_ICON | SHGFI_SHELLICONSIZE | SHGFI_DISPLAYNAME;
					if (iconsize <= 16) cbfileinfo |= SHGFI_SMALLICON;

					sysimgl = (HIMAGELIST)SHGetFileInfo((LPCSTR)pIDFull, 0, &shinfo, sizeof(SHFILEINFO), cbfileinfo);
					if (sysimgl && is_visible)
					{
						item -> hIcon = ImageList_GetIcon(sysimgl, shinfo.iIcon, ILD_NORMAL);
						//item -> hIcon = shinfo.hIcon;
						sysimgl = NULL;
						strcpy_max(item->szTip, shinfo.szDisplayName, sizeof item->szTip);
					}
					else
					{
						item -> hIcon = NULL;
						item->szTip[0] = 0;
					}

					// add item to the list
					item -> next = *ppItems, *ppItems = item;

					// free the relative pID
					pMalloc->Free(pID);
				}
				// release the folders enum interface
				pEnumIDList->Release();
			}
			// release the folder interface itself
			pThisFolder->Release();
		}

		pidl_list = pidl_list -> next;
	}

	// release the task allocator interface
	pMalloc->Release();

	pFolder->items = join_folders(pFolder->items);
}

//===========================================================================
#define m_pszTitle szTip

int cmp_fn(Item** m1, Item** m2)
{
	return stricmp((*m1)->m_pszTitle, (*m2)->m_pszTitle);
}

// Not ideal - convert list to array, sort it, convert to list again
Item * Sort(Item *MI)
{
	Item *i, **a; int n;
	n=0; dolist(i, MI) n++;
	a = (Item**)m_alloc(n*sizeof(Item*));
	n=0; dolist(i, MI) a[n]=i, n++;
	qsort(a, n, sizeof(Item*), (int(*)(const void*,const void*))cmp_fn);
	for (i=NULL;n;) a[--n]->next=i, i=a[n];
	m_free(a);
	return i;
}

//===========================================================================

Item *join_folders(Item *items)
{
	items = Sort(items);
	Item *mi = items, *mn;
	if (mi) while (NULL != (mn = mi->next))
	{
		// compare first with second
		if (0 == stricmp(mi->m_pszTitle, mn->m_pszTitle))
		{
			// set list ptr to the 3rd item, which becomes the second now
			mi->next = mn->next;

			// delete the second menu item
			freeIDList(mn->pidl);
			if (mn->hIcon) DestroyIcon(mn->hIcon);
			delete mn;
		}
		else
		{
			// the second is now the first
			mi = mn;
		}
	}
	return items;
}

//===========================================================================
// Function: cut_name_from_path
// Purpose:  get the pointer to the filename
// In:
// Out:
//===========================================================================

char *cut_name_from_path(char *path)
{
	int nLen = strlen(path);
	while (nLen && path[nLen-1] != '\\') nLen--;
	path[nLen]=0;
	return path;
}

//===========================================================================
int exec_pidl(const _ITEMIDLIST *pidl, LPCSTR arg)
{
	char szFullName[MAX_PATH];
	szFullName[0]=0;

	SHGetPathFromIDList(pidl, szFullName);
	cut_name_from_path(szFullName);

	//bb_MessageBox(0, szFullName);

	SHELLEXECUTEINFO sei;
	ZeroMemory(&sei,sizeof(sei));
	sei.cbSize = sizeof(sei);
	sei.fMask = SEE_MASK_INVOKEIDLIST | SEE_MASK_IDLIST | SEE_MASK_FLAG_NO_UI;
	//sei.hwnd = NULL;
	//sei.lpVerb = NULL;
	//sei.lpFile = NULL;
	sei.lpParameters = arg;
	sei.lpDirectory = szFullName;
	sei.nShow = SW_SHOWNORMAL;
	sei.lpIDList = (void*)pidl;
	return ShellExecuteEx(&sei);
}

//===========================================================================

//===========================================================================
#if 1

void EnumTray (TRAYENUMPROC lpEnumFunc, LPARAM lParam)
{
	for (int i = 0, s = GetTraySize(); i < s; i++)
		if (FALSE == lpEnumFunc(GetTrayIcon(i), lParam))
			break;
}

void EnumTasks (TASKENUMPROC lpEnumFunc, LPARAM lParam)
{
#ifdef NOT_XOBLITE  
	/*struct tasklist *tl;*/
	dolist (tl, bbIconBox_GetTaskListPtr())
		if (FALSE == lpEnumFunc(tl, lParam))
			break;
#endif
}

void EnumDesks (DESKENUMPROC lpEnumFunc, LPARAM lParam)
{
	DesktopInfo info;
	GetDesktopInfo(&info);
	string_node *p = info.deskNames;
	for (int n = 0; n < info.ScreensX; n++)
	{
		DesktopInfo DI;
		DI.number = n;
		DI.deskNames = info.deskNames;
		DI.isCurrent = n == info.number;
		DI.name[0] = 0;
		if (p) strcpy(DI.name, p->str), p = p->next;

		if (FALSE == lpEnumFunc(&DI, lParam))
			break;
	}
}

//------------------------------------------------------
// emulation code for 0.9x versions

void set_task_flags(HWND hwnd, UINT lParam)
{
	// skip odd message sent by the toolbar
	if (hwnd && FALSE == IsWindow(hwnd))
		return;

#ifdef NOT_XOBLITE  
	/*struct tasklist *tl;*/

	//new_tasklist();

	for (tl = bbIconBox_GetTaskListPtr(); tl; tl = tl->next)
	{
		if (tl->hwnd == hwnd)
			tl->flashing = TASKITEM_FLASHED == lParam;

		if (TASKITEM_ACTIVATED == lParam)
			tl->active = tl->hwnd == hwnd;
	}
#endif
}

#endif

//===========================================================================

//===========================================================================
#ifndef SHCNF_ACCEPT_INTERRUPTS
struct _SHChangeNotifyEntry
{
	const _ITEMIDLIST *pidl;
	BOOL fRecursive;
};
#define SHCNF_ACCEPT_INTERRUPTS 0x0001 
#define SHCNF_ACCEPT_NON_INTERRUPTS 0x0002
#define SHCNF_NO_PROXY 0x8000
#endif

#ifndef SHCNE_DISKEVENTS
#define SHCNE_DISKEVENTS    0x0002381FL
#define SHCNE_GLOBALEVENTS  0x0C0581E0L // Events that dont match pidls first
#define SHCNE_ALLEVENTS     0x7FFFFFFFL
#define SHCNE_INTERRUPT     0x80000000L // The presence of this flag indicates
#endif

UINT (WINAPI *pSHChangeNotifyRegister)(
	HWND hWnd, 
	DWORD dwFlags, 
	LONG wEventMask, 
	UINT uMsg, 
	DWORD cItems,
	struct _SHChangeNotifyEntry *lpItems
	);

BOOL (WINAPI *pSHChangeNotifyDeregister)(UINT ulID);

UINT add_change_notify_entry(HWND hwnd, const _ITEMIDLIST *pidl)
{

	if (NULL == pSHChangeNotifyRegister)
	{
		HMODULE shell_lib = GetModuleHandle("SHELL32");
		*(FARPROC*)&pSHChangeNotifyRegister = GetProcAddress(shell_lib,(char*)0x2);
		*(FARPROC*)&pSHChangeNotifyDeregister = GetProcAddress(shell_lib,(char*)0x4);
	}

	struct _SHChangeNotifyEntry E;
	E.pidl = pidl;
	E.fRecursive = FALSE;
	return pSHChangeNotifyRegister(
		hwnd,
		SHCNF_ACCEPT_INTERRUPTS|SHCNF_ACCEPT_NON_INTERRUPTS|SHCNF_NO_PROXY,
		SHCNE_ALLEVENTS,
		BBIB_FOLDERCHANGED,
		1,
		&E
		);
}

void remove_change_notify_entry(UINT id_notify)
{
	pSHChangeNotifyDeregister(id_notify);
}

//===========================================================================
// Function: SetToolTip
// Purpose: To assign a ToolTip to an icon
// In:      the position of the icon, the text
//===========================================================================

HWND hToolTips;
struct tt
{
	struct tt *next;
	char used_flg;
	char text[MAX_TIPTEXT];
	TOOLINFO ti;
} *tt0;

void SetToolTip(HWND hwnd, RECT *tipRect, char *tipText)
{
	if (NULL==hToolTips) return;

	struct tt **tp, *t; unsigned n=0;
	for (tp=&tt0; NULL!=(t=*tp); tp=&t->next)
	{
		if (hwnd == t->ti.hwnd && 0==memcmp(&t->ti.rect, tipRect, sizeof(RECT)))
		{
			t->used_flg = 1;
			if (0!=strcmp(t->ti.lpszText, tipText))
			{
				strcpy(t->text, tipText);
				SendMessage(hToolTips, TTM_UPDATETIPTEXT, 0, (LPARAM)&t->ti);
			}
			return;
		}
		if (t->ti.uId > n)
			n = t->ti.uId;
	}

	t = new struct tt;
	t->used_flg  = 1;
	t->next = NULL;

	strcpy(t->text, tipText);
	*tp = t;

	memset(&t->ti, 0, sizeof(TOOLINFO));

	t->ti.cbSize   = sizeof(TOOLINFO);
	t->ti.uFlags   = TTF_SUBCLASS;
	t->ti.hwnd     = hwnd;
	t->ti.uId      = n+1;
	//t->ti.hinst    = NULL;
	t->ti.lpszText = t->text;
	t->ti.rect     = *tipRect;
	SendMessage(hToolTips, TTM_ADDTOOL, 0, (LPARAM)&t->ti);

	HFONT toolFont  = CreateStyleFont((StyleItem *)GetSettingPtr(SN_TOOLBAR));
	SendMessage(hToolTips, WM_SETFONT, (WPARAM)toolFont, (LPARAM)true);
}

//===========================================================================
// Function: ClearToolTips
// Purpose:  clear all tooltips, which are not longer used
//===========================================================================

void ClearToolTips(HWND hwnd)
{
	struct tt **tp, *t;
	tp=&tt0; while (NULL!=(t=*tp))
	{
		if (hwnd != t->ti.hwnd)
		{
			tp=&t->next;
		}
		else
		if (0==t->used_flg)
		{
			SendMessage(hToolTips, TTM_DELTOOL, 0, (LPARAM)&t->ti);
			*tp=t->next;
			delete t;
		}
		else
		{
			t->used_flg = 0;
			tp=&t->next;
		}
	}
}

//===========================================================================
// Function: InitToolTips
//===========================================================================

void InitToolTips(HINSTANCE hInstance)
{
	INITCOMMONCONTROLSEX ic;
	ic.dwSize = sizeof(INITCOMMONCONTROLSEX);
	ic.dwICC = ICC_BAR_CLASSES;

	InitCommonControlsEx(&ic);

	hToolTips = CreateWindowEx(
		WS_EX_TOPMOST,
		TOOLTIPS_CLASS,
		NULL,
		TTS_ALWAYSTIP | WS_POPUP | TTS_NOPREFIX,
		CW_USEDEFAULT,
		CW_USEDEFAULT,
		CW_USEDEFAULT,
		CW_USEDEFAULT,
		NULL,
		NULL,
		hInstance,
		NULL
		);

	if (hToolTips)
	{
		SendMessage(hToolTips, TTM_SETMAXTIPWIDTH, 0, 300);

		//SendMessage(hToolTips, TTM_SETDELAYTIME, TTDT_AUTOMATIC, 200);
		SendMessage(hToolTips, TTM_SETDELAYTIME, TTDT_AUTOPOP, 4000);
		SendMessage(hToolTips, TTM_SETDELAYTIME, TTDT_INITIAL, 50/*500*/);
		SendMessage(hToolTips, TTM_SETDELAYTIME, TTDT_RESHOW,  0/*200*/);
	}
}

void ExitToolTips()
{
	if (hToolTips) DestroyWindow(hToolTips);
}

//===========================================================================

#define NIN_BALLOONSHOW (WM_USER + 2)
#define NIN_BALLOONHIDE (WM_USER + 3)
#define NIN_BALLOONTIMEOUT (WM_USER + 4)
#define NIN_BALLOONUSERCLICK (WM_USER + 5)

#define TTM_SETTITLEA (WM_USER+32)  // wParam = TTI_*, lParam = char* szTitle
#define TTS_BALLOON     0x40

#define NIIF_NONE       0x00000000
#define NIIF_INFO       0x00000001
#define NIIF_WARNING    0x00000002
#define NIIF_ERROR      0x00000003

#define TTI_NONE        0
#define TTI_INFO        1
#define TTI_WARNING     2
#define TTI_ERROR       3

class win_balloon
{
	systemTray icon;
	systemTrayBalloon balloon;
	HWND hwndBalloon;
	WNDPROC prev_wndproc;
	bool finished;

public:
	win_balloon (plugin_info * mPI, systemTray *pIcon, RECT r)
	{
		HWND hwndParent = mPI->hwnd;
		HINSTANCE hInstance = mPI->hInstance;

		ClientToScreen(hwndParent, (POINT*)&r.left);
		ClientToScreen(hwndParent, (POINT*)&r.right);

		this->icon  = *pIcon;
		this->balloon = *pIcon->pBalloon;
		this->finished = false;

		int xpos = (r.left+r.right)/2;
		int ypos = (r.top+r.bottom)/2;

		TOOLINFO ti;
		memset(&ti, 0, sizeof ti);
		ti.cbSize   = sizeof(TOOLINFO);
		ti.uFlags   = TTF_TRACK;
		ti.hwnd     = hwndParent;
		ti.uId      = 1;
		ti.lpszText = balloon.szInfo;

		hwndBalloon = CreateWindowEx(
			WS_EX_TOPMOST|WS_EX_TOOLWINDOW,
			TOOLTIPS_CLASS,
			NULL,
			WS_POPUP | TTS_NOPREFIX | TTS_BALLOON,
			0,0,0,0,
			hwndParent,
			NULL,
			hInstance,
			NULL
			);

		SendMessage(hwndBalloon, TTM_SETMAXTIPWIDTH, 0, 270);
		SendMessage(hwndBalloon, TTM_ADDTOOL, 0, (LPARAM)&ti);
		SendMessage(hwndBalloon, TTM_SETTITLEA, balloon.dwInfoFlags, (LPARAM)balloon.szInfoTitle);
		SendMessage(hwndBalloon, TTM_TRACKPOSITION, 0, MAKELPARAM(xpos, ypos));
		SendMessage(hwndBalloon, TTM_TRACKACTIVATE, TRUE, (LPARAM)&ti);

		SetWindowLong(hwndBalloon, GWL_USERDATA, (LONG)this);
		prev_wndproc = (WNDPROC)SetWindowLong(hwndBalloon, GWL_WNDPROC, (LONG)wndproc);

		SetTimer(hwndBalloon, 700, imax(8000, balloon.uInfoTimeout), NULL);
		Post(NIN_BALLOONSHOW);
	}

private:
	~win_balloon()
	{
		finished = true;
		DestroyWindow(hwndBalloon);
	}

	void Post(LPARAM lParam)
	{
		PostMessage(icon.hWnd, icon.uCallbackMessage, icon.uID, lParam);
	}

	static LRESULT wndproc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
	{
		win_balloon *p = (win_balloon *)GetWindowLong(hwnd, GWL_USERDATA);
		switch (message)
		{       
			case WM_CREATE:
				break;

			case WM_DESTROY:
				if (false == p->finished)
					p->Post(NIN_BALLOONHIDE);
				break;

			case WM_TIMER:
				if (700 != wParam) break;
				p->Post(NIN_BALLOONTIMEOUT);
				delete p;
				return 0;

			case WM_RBUTTONDOWN:
			case WM_LBUTTONDOWN:
			case WM_MBUTTONDOWN:
				p->Post(NIN_BALLOONUSERCLICK);
				delete p;
				return 0;

			default:
				break;
		}
		return CallWindowProc (p->prev_wndproc, hwnd, message, wParam, lParam);
	}
};

void start_balloon(plugin_info * mPI, systemTray *pIcon, RECT iconRect)
{
	new win_balloon(mPI, pIcon, iconRect);
}

//===========================================================================

//===========================================================================
