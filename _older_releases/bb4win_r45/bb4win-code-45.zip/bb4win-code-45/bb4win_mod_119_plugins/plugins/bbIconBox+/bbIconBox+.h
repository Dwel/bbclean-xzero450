/*
 ============================================================================

  This file is part of bbIconBox+ source code.
  bbIconBox+ is a plugin for Blackbox for Windows

  Copyright � 2004 grischka
  Copyright � 2009 The Blackbox for Windows Development Team
  http://bb4win.sf.net/bblean
  http://bb4win.sourceforge.net

 ============================================================================

  bbIconBox is free software, released under the GNU General Public License
  (GPL version 2 or later).

  http://www.fsf.org/licenses/gpl.html

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

 ============================================================================
*/

#define MAX_TIPTEXT 200

struct Item
{
	struct Item * next;
	struct _ITEMIDLIST *pidl;
	HICON hIcon;
	int id;
	bool active;
	bool is_folder;
	char szTip [MAX_TIPTEXT];
};

struct Folder
{
	struct Folder * next;
	struct Item * items;
	int mode;
	int desk;
	HWND task_over;
	UINT id_notify;
	struct pidl_node *pidl_list;
	char path[MAX_PATH];
	class CDropTarget *drop_target;
};

#define MODE_FOLDER 0
#define MODE_TRAY 1
#define MODE_TASK 2
#define MODE_DESK 3

#define TASK_RISE_TIMER 4
#define MENU_TRACKMOUSE_TIMER 5
#define CHECK_MEM_TIMER 6

int exec_pidl(const _ITEMIDLIST *pidl, LPCSTR arg);
void ClearFolder(Folder*);
void LoadFolder(Folder *pFolder, int iconsize,  bool is_visible, HWND hwnd);

void SetToolTip(HWND hwnd, RECT *tipRect, char *tipText);
void ClearToolTips(HWND hwnd);
void InitToolTips(HINSTANCE);
void ExitToolTips(void);

class CDropTarget *init_drop_targ(HWND hwnd);
void exit_drop_targ (class CDropTarget *m_dropTarget);
const struct _ITEMIDLIST *indrag_get_pidl(HWND hwnd, POINT *);

void set_task_flags(HWND hwnd, UINT lParam);
bool select_folder(HWND hwnd, const char *title, char *name, char *path);

// ---------------------------------------------
/*struct winStruct
{
	struct winStruct *next;
	struct taskinfo info;
	HWND window;
	int index;
	bool active;
	bool iconic;
};

extern int winCount;

void build_winlist(void);
void free_winlist(void);
void setup_ratio(int width, int height);
void get_virtual_rect(RECT *d, winStruct *w, RECT *r);
winStruct *get_winstruct(int index);


void init_tasks(HWND hPluginWnd, HINSTANCE hInst);
void exit_tasks(void);*/

tasklist* bbIconBox_GetTaskListPtr(void);
extern struct tasklist *tl;

void start_balloon(plugin_info * mPI, systemTray *pIcon, RECT iconRect);

// ---------------------------------------------

#define BBIB_DELETE (WM_USER + 100)
#define BBIB_UPDATE (WM_USER + 101)
#define BBIB_FOLDERCHANGED (WM_USER + 102)

