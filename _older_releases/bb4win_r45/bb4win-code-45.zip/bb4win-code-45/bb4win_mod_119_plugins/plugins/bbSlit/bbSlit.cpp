/******************************************************************************
* bbSlit - A Babysitter for your plugins                                      *
  bbSlit is a plugin for Blackbox for Windows
*******************************************************************************
* Copyright (c) 2003 Brian Hartvigsen						                    *
* Copyright (c) 2009 The Blackbox for Windows Development Team  *
*******************************************************************************
  Blackbox for Windows is free software, released under the
  GNU General Public License (GPL version 2 or later), with an extension
  that allows linking of proprietary modules under a controlled interface.
  What this means is that plugins etc. are allowed to be released
  under any license the author wishes. Please note, however, that the
  original Blackbox gradient math code used in Blackbox for Windows
  is available under the BSD license.

  http://www.fsf.org/licenses/gpl.html
  http://www.fsf.org/licenses/gpl-faq.html#LinkingOverControlledInterface
  http://www.xfree86.org/3.3.6/COPYRIGHT2.html#5

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.
*************************************************************************************/

#include "BBApi.h"
#include "../bbPlugin/moreutils.cpp"
#include <vector>
using namespace std;

#define PLUGIN_NAME		  1
#define PLUGIN_VERSION	  2
#define PLUGIN_AUTHOR	  3
#define PLUGIN_RELEASE	  4
#define PLUGIN_LINK		  5
#define PLUGIN_EMAIL	  6
#define PLUGIN_UPDATE_URL 8

LPCSTR szAppName = "bbSlit";
LPCSTR szAppVersion = "01.08";
LPCSTR szAppAuthor = "Brian \"Tres`ni\" Hartvigsen|TheDevTeam";
LPCSTR szAppEmail = "irc://irc.freenode.net/bb4win";
LPCSTR szAppLink = "http://bb4win.sourceforge.net/";
LPCSTR szAppRelease = "2009-06-01";
LPCSTR szAppDefault = "bbSlit 01.08";
LPCSTR szInfoUpdateURL = "http://www.lostinthebox.com/viewforum.php?t=2939";

typedef int (*pBeginSlitPlugin)(HINSTANCE hMainInstance, HWND hBBSlit);
typedef int (*pBeginPluginEx)(HINSTANCE hMainInstance, HWND hBBSlit);
typedef int (*pBeginPlugin)(HINSTANCE hMainInstance);
typedef void (*pEndPlugin)(HINSTANCE hMainInstance);
typedef LPCSTR (*pPluginInfo)(int field);

vector<HWND> vSlitWindows;				//Windows currently docked in Slit
vector<HINSTANCE> vSlitPlugins;			//Plugins loaded in slit

LRESULT CALLBACK slitProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
void trackWindow();
void getStyleSettings();
void getRCSettings();
void setPluginPositions();
void setSlitPosition();
void showMenu(bool popup);
void loadPlugins();
void unloadPlugins();
void aboutPlugins();

HWND SlitWnd, BBWnd;
HINSTANCE SlitInstance;

StyleItem SlitStyle;
int SlitBevel, SlitBorder, SlitHangout, SlitHandle;

bool SlitToggle = false;
bool SlitAutoHide = false;
bool SlitOnTop = false;
bool SlitVertical;
bool SlitShown;
bool FullScreen;
char SlitPlacement[12];
char RCPath[MAX_PATH];

bool SlitTransOn = false;
BYTE SlitTrans = 255;

int SlitWidth=0, SlitHeight=0;
int SlitX, SlitY, SlitHideX, SlitHideY;

int SlitMsgs[] = {BB_RECONFIGURE, BB_BROADCAST, 0};

int beginPlugin(HINSTANCE hMainInstance)
{
	WNDCLASS wc;
	ZeroMemory(&wc, sizeof(wc));

	BBWnd = GetBBWnd();
	SlitInstance = hMainInstance;

	wc.lpfnWndProc = slitProc;
	wc.hInstance = hMainInstance;
	wc.lpszClassName = "BBSlit";
	if(!RegisterClass(&wc))
	{
		MessageBox(BBWnd, "Error registering window class", "bbSlit", MB_OK | MB_ICONERROR | MB_TOPMOST);
		return 1;
	}

	SlitWnd = CreateWindowEx(
		WS_EX_TOOLWINDOW,								// window style
		"bbSlit",										// our window class name
		NULL,											// NULL -> does not show up in task manager!
		WS_POPUP | WS_CLIPCHILDREN | WS_CLIPSIBLINGS,	// window parameters
		0,												// x position
		0,												// y position
		0,												// window width
		0,												// window height
		NULL,											// parent window
		NULL,											// no menu
		hMainInstance,									// hInstance of .dll
		NULL);
	if(!SlitWnd)
	{
		MessageBox(BBWnd, "Error creating window!", "bbSlit", MB_OK | MB_ICONERROR | MB_TOPMOST);
		return 1;
	}
	
	SendMessage(BBWnd, BB_REGISTERMESSAGE, (WPARAM)SlitWnd, (LPARAM)SlitMsgs);
	
	getStyleSettings();
	getRCSettings();
	setSlitPosition();
	
	if (SlitOnTop)
		SetWindowPos(SlitWnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOACTIVATE | SWP_NOSIZE | SWP_NOMOVE);

	MakeSticky(SlitWnd);

	loadPlugins();
	
	return 0;
}

void endPlugin(HINSTANCE hMainInstance)
{
	SendMessage(BBWnd, BB_UNREGISTERMESSAGE, (WPARAM)SlitWnd, (LPARAM)SlitMsgs);

	unloadPlugins();

	DestroyWindow(SlitWnd);
	UnregisterClass("bbSlit", hMainInstance);
}


LPCSTR pluginInfo(int field)
{
	switch(field)
	{
	case PLUGIN_NAME: return szAppName;
	case PLUGIN_VERSION: return szAppVersion;
	case PLUGIN_AUTHOR: return szAppAuthor;
	case PLUGIN_EMAIL: return szAppEmail;
	case PLUGIN_LINK: return szAppLink;
	case PLUGIN_RELEASE: return szAppRelease;
	case PLUGIN_UPDATE_URL: return szInfoUpdateURL;
	default: return szAppDefault;
	}
}

LRESULT CALLBACK slitProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch(uMsg)
	{
		case WM_DISPLAYCHANGE:
		{
			setSlitPosition();
		}
		break;

		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hWnd, &ps);
			HDC buf = CreateCompatibleDC(NULL);
			HBITMAP bufbmp = CreateCompatibleBitmap(hdc, SlitWidth, SlitHeight);
			HBITMAP oldbuf = (HBITMAP)SelectObject(buf, bufbmp);
			RECT r;

			GetClientRect(hWnd, &r);
			MakeStyleGradient(buf, &r, &SlitStyle, true);
			BitBlt(hdc, 0, 0, SlitWidth, SlitHeight, buf, 0, 0, SRCCOPY);

			SelectObject(buf, oldbuf);
			DeleteDC(buf);
			DeleteObject(bufbmp);
			EndPaint(hWnd, &ps);
		}
		break;

		case WM_LBUTTONDOWN:
			UpdateWindow(SlitWnd);
			if (GetAsyncKeyState(VK_CONTROL) & 0x8000)
			{
				// start moving, when control-key is held down
				PostMessage(SlitWnd, WM_SYSCOMMAND, 0xf012, 0);
				break;
			}
			break;

		case WM_RBUTTONUP:
		{
			showMenu(true);
		}
		break;

		case WM_WINDOWPOSCHANGED:
		{
			WINDOWPOS* wp = (WINDOWPOS*)lParam;
			SlitX = wp->x;
			SlitY = wp->y;
			WriteString(RCPath, "bbSlit.placement:", "User");
			WriteInt(RCPath, "bbSlit.x:", SlitX);
			WriteInt(RCPath, "bbSlit.y:", SlitY);
		}
		break;

		case WM_MOUSEMOVE:
		{
			if (SlitAutoHide)
			{
				SetTimer(SlitWnd, 1, 250, NULL);
				trackWindow();
			}
		}
		break;

		case WM_TIMER:
		{
			if (SlitAutoHide)
			{
				POINT pt;
				GetCursorPos(&pt);
				ScreenToClient(SlitWnd, &pt);
				
				RECT rct = {0, 0, SlitWidth, SlitHeight};
				if (!PtInRect(&rct, pt))
				{
					SetWindowPos(SlitWnd, NULL, SlitHideX, SlitHideY, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
					SlitShown = false;
					KillTimer(SlitWnd, 1);
				}
				else
				{
					trackWindow();
				}
			}
			else
			{
				KillTimer(SlitWnd, 1);
				trackWindow();
			}
		}
		break;

		case SLIT_ADD:
		{
			vSlitWindows.push_back((HWND) lParam);
			if(IsWindow((HWND)lParam))
			{
				SetWindowLong((HWND)lParam, GWL_STYLE, (GetWindowLong((HWND)lParam, GWL_STYLE) & ~WS_POPUP) | WS_CHILD);
				SetParent((HWND)lParam, hWnd);
			}

			setPluginPositions();
		}
		break;

		case SLIT_REMOVE:
		{
			vector<HWND>::iterator test;
			for(test = vSlitWindows.begin(); test != vSlitWindows.end(); test++)
				if(*test == (HWND) lParam)
				{
					vSlitWindows.erase(test);
					break;
				}
			setPluginPositions();

			if(IsWindow((HWND)lParam))
			{
				SetWindowLong((HWND)lParam, GWL_STYLE, (GetWindowLong((HWND)lParam, GWL_STYLE) & ~WS_CHILD) | WS_POPUP);
				SetParent((HWND)lParam, NULL);
			}
		}
		break;

		case SLIT_UPDATE:
		{
			setPluginPositions();
		}
		break;

		case BB_RECONFIGURE:
		{
			getStyleSettings();
			getRCSettings();
			setPluginPositions();
		}
		break;

		case BB_BROADCAST:
		{
			char temp[MAX_PATH];
			strcpy(temp, (LPCSTR)lParam);

			if ((!_stricmp(temp, "@BBShowPlugins")) && SlitToggle)
			{
				ShowWindow(SlitWnd, SW_SHOW);
				InvalidateRect(SlitWnd, NULL, true);
			}
			else if ((!_stricmp(temp, "@BBHidePlugins")) && SlitToggle)
			{
				ShowWindow(SlitWnd, SW_HIDE);
			}
			else if(IsInString(temp,"@bbSlit"))
			{
				char broam[32], cmd[32], par[32], extra[32];
				LPSTR tokens[4];
				tokens[0] = broam;
				tokens[1] = cmd;
				tokens[2] = par;
				tokens[3] = extra;
				
				broam[0] = cmd[0] = par[0] = extra[0] = '\0';
				BBTokenize (temp, tokens, 3, extra);
				if(!_stricmp(cmd, "About"))
				{
					char temp[MAX_LINE_LENGTH];
					sprintf(temp, "%s %s (%s)\n\n%s\n%s\n%s", szAppName, szAppVersion, szAppRelease, szAppAuthor, szAppEmail, szAppLink);
					MessageBox(SlitWnd, temp, "About bbSlit", MB_OK | MB_SETFOREGROUND);
				}
				if(!_stricmp(cmd, "EditRC"))
				{
					char path[MAX_PATH];
					GetBlackboxEditor(path);
					BBExecute(NULL, NULL, path, RCPath, NULL, SW_SHOWNORMAL, false);
				}
				else if(!_stricmp(cmd, "Toggle"))
				{
					if(!_stricmp(par, "OnTop"))
					{
						if (!SlitOnTop && (_stricmp(extra,"off") != 0))
						{
							SetWindowPos(SlitWnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOACTIVATE | SWP_NOSIZE | SWP_NOMOVE);
							SlitOnTop = true;
						}
						else if(_stricmp(extra, "on") != 0)
						{
							SetWindowPos(SlitWnd, HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOACTIVATE | SWP_NOSIZE | SWP_NOMOVE);
							SlitOnTop = false;
						}
						WriteBool(RCPath, "bbSlit.onTop:", SlitOnTop);
					}
					else if(!_stricmp(par, "Shade"))
					{
						if(!SlitAutoHide  && (_stricmp(extra,"off") != 0))
						{
							SetTimer(SlitWnd, 1, 250, NULL);
							trackWindow();
							SlitAutoHide = true;
						}
						else if(_stricmp(extra, "on") != 0)
						{
							SlitAutoHide = false;
						}
						WriteBool(RCPath, "bbSlit.shade:", SlitAutoHide);
						setSlitPosition();
					}
					else if(!_stricmp(par, "Plugins"))
					{
						if(!SlitToggle && (_stricmp(extra,"off") != 0))
							SlitToggle = true;
						else if(_stricmp(extra, "on") != 0)
							SlitToggle = false;
						
						WriteBool(RCPath, "bbSlit.pluginToggle:", SlitToggle);
					}
					else if(!_stricmp(par, "Handle"))
					{
						if(!SlitHandle && (_stricmp(extra,"off") != 0))
							SlitHandle = true;
						else if(_stricmp(extra, "on") != 0)
							SlitHandle = false;
						
						WriteBool(RCPath, "bbSlit.dragHandle:", SlitHandle);
					}

					break;
				}
				else if(!_stricmp(cmd, "Placement"))
				{
					strcpy(SlitPlacement, par);
					setSlitPosition();
					WriteString(RCPath, "bbSlit.placement:", SlitPlacement);
					break;
				}
				else if(!_stricmp(cmd, "FullScreen"))
				{
					FullScreen = false == FullScreen;
					setSlitPosition();
					WriteBool(RCPath, "bbSlit.fullScreen:", FullScreen);
					break;
				}
				else if(!_stricmp(cmd, "Orientation"))
				{
					if(!_stricmp(par, "Vertical"))
						SlitVertical = true;
					else
						SlitVertical = false;
					
					setPluginPositions();
					WriteString(RCPath, "bbSlit.direction:", SlitVertical ? "Vertical" : "Horizontal");
					break;
				}
				else if( !_stricmp(cmd, "AlphaValue" ) )
				{
					if( SlitTrans == 255 ) break;

					WriteInt(RCPath, "bbSlit.alpha.value:", *(int*)atoi(extra));
					SlitTrans = BYTE(atoi(extra));
					SetTransparency( SlitWnd, SlitTrans );
				}
			}
		}
		break;

		default:
			return DefWindowProc(hWnd, uMsg, wParam, lParam);
	}

	return 0;
}

void trackWindow()
{
	RECT rt;
	
	SlitShown = true;
	GetWindowRect(SlitWnd, &rt);
	if((rt.top != SlitY) || (rt.left != SlitX))
		SetWindowPos(SlitWnd, NULL, SlitX, SlitY, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
}

//=============================================================================
bool get_style(StyleItem *si, const char *key)
{
    const char *s, *p;
    COLORREF c; int w;
    char fullkey[80], *r;

    memset(si, 0, sizeof *si);
    r = strchr(strcpy(fullkey, key), 0);
    s = stylePath();

    strcpy(r, ".appearance:");
    p = ReadString(s, fullkey, NULL);
    if (p) {
        si->bordered = IsInString(p, "border");
    } else {
        strcpy(r, ":");
        p = ReadString(s, fullkey, NULL);
        if (NULL == p)
            return false;
        si->bordered = true;
    }
    ParseItem(p, si);

    if (B_SOLID != si->type || si->interlaced)
        strcpy(r, ".color1:");
    else
        strcpy(r, ".backgroundColor:");
    c = ReadColor(s, fullkey, NULL);
    if ((COLORREF)-1 == c) {
        strcpy(r, ".color:");
        c = ReadColor(s, fullkey, NULL);
        if ((COLORREF)-1 == c)
            return false;
    }

    si->Color = si->ColorTo = c;
    if (B_SOLID != si->type || si->interlaced) {
        strcpy(r, ".color2:");
        c = ReadColor(s, fullkey, NULL);
        if ((COLORREF)-1 == c) {
            strcpy(r, ".colorTo:");
            c = ReadColor(s, fullkey, NULL);
        }
        if ((COLORREF)-1 != c)
            si->ColorTo = c;
    }

    if (si->bordered) {
        strcpy(r, ".borderColor:");
        c = ReadColor(s, fullkey, NULL);
        if ((COLORREF)-1 != c)
            si->borderColor = c;
        else
            si->borderColor = ReadColor(s, "borderColor:", "black");

        strcpy(r, ".borderWidth:");
        w = ReadInt(s, fullkey, -100);
        if (-100 != w)
            si->borderWidth = w;
        else
            si->borderWidth = ReadInt(s, "borderWidth:", 1);
    }

    strcpy(r, ".marginWidth:");
    w = ReadInt(s, fullkey, -100);
    if (-100 != w)
        si->marginWidth = w;
    else
        si->marginWidth = ReadInt(s, "bevelWidth:", 2);
    return true;
}

void getStyleSettings()
{
    StyleItem si, *S;
    S = NULL;

	bool newMetrics = false;
	void *p = GetSettingPtr(35); //SN_NEWMETRICS aka SN_ISSTYLE070
	newMetrics = HIWORD(p) ? *(bool*)p : NULL!=p;

	S = &si;
	if (false == get_style(S, "slit"))
		S = (StyleItem*)GetSettingPtr(SN_TOOLBAR);
	SlitStyle = *S;

	SlitBevel = newMetrics ? SlitStyle.marginWidth : *(int*)GetSettingPtr(SN_BEVELWIDTH);
	SlitBorder = newMetrics ? SlitStyle.borderWidth : *(int*)GetSettingPtr(SN_BORDERWIDTH);

	SlitHangout = imax(SlitBevel + SlitBorder, 3);
}

void getRCSettings()
{
	locate_file(SlitInstance, RCPath, szAppName, "rc");

	strcpy(SlitPlacement, ReadString(RCPath, "bbSlit.placement:", "TopCenter"));
	SlitVertical = (bool)(!_stricmp("Vertical", ReadString(RCPath, "bbSlit.direction:", "Vertical")));
	SlitAutoHide = ReadBool(RCPath, "bbSlit.shade:", false);
	SlitOnTop = ReadBool(RCPath, "bbSlit.onTop:", false);
	SlitToggle = ReadBool(RCPath, "bbSlit.pluginToggle:", false);
	SlitTrans = ReadInt(RCPath, "bbSlit.alpha.value:", 255 );
	FullScreen = ReadBool(RCPath, "bbSlit.fullScreen:", false);
	SlitHandle = ReadBool(RCPath, "bbSlit.dragHandle:", false);
	SlitShown = !SlitAutoHide;
	SlitTransOn = (SlitTrans != 255 );
	
	SetTransparency(SlitWnd, SlitTrans );
}

void setPluginPositions()
{
	if (vSlitWindows.size() > 0)
	{
		int maxdelta = 0;
		int pluginwidth, pluginheight;
		vector<HWND>::iterator hwndSlitPlugin;
		
		//====================
		
		// Scan through the plugin list and calculate the
		// maximum plugin width (vertical mode) or height (horizontal mode)...
		for (hwndSlitPlugin = vSlitWindows.begin(); hwndSlitPlugin != vSlitWindows.end(); hwndSlitPlugin++)
		{
			if (IsWindow(*hwndSlitPlugin)) // Chekck if the window is valid...
			{
				RECT r = {0, 0, 0, 0};
				GetWindowRect(*hwndSlitPlugin, &r);
				
				if (SlitVertical)
				{
					pluginwidth = r.right - r.left;
					if (pluginwidth > maxdelta) maxdelta = pluginwidth;
				}
				else
				{
					pluginheight = r.bottom - r.top;
					if (pluginheight > maxdelta) maxdelta = pluginheight;
				}
			}
			else // ...if not, we remove it from the list...
			{
				vSlitWindows.erase(hwndSlitPlugin);
				hwndSlitPlugin--;
			}
		}

		int offset = SlitBorder + SlitBevel;
		int tempX = offset;
		int tempY = offset;
		for(hwndSlitPlugin = vSlitWindows.begin(); hwndSlitPlugin != vSlitWindows.end(); hwndSlitPlugin++)
		{
			int padding;
			RECT r = {0, 0, 0, 0};

			GetWindowRect(*hwndSlitPlugin, &r);
			
			pluginwidth = r.right - r.left;
			pluginheight = r.bottom - r.top;
			
			if (SlitVertical)
			{
				// Calculate necessary padding to get a centered x position...
				if (pluginwidth == maxdelta) padding = SlitHandle ? SlitHangout : 0;
				else padding = (maxdelta - pluginwidth) / 2;
				SetWindowPos(*hwndSlitPlugin, NULL, (tempX + padding), tempY, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
				tempY = tempY + pluginheight + offset;
			}
			else
			{
				// Calculate necessary padding to get a centered y position...
				if (pluginheight == maxdelta) padding = SlitHandle ? SlitHangout : 0;
				else padding = (maxdelta - pluginheight) / 2;
				SetWindowPos(*hwndSlitPlugin, NULL, tempX, (tempY + padding), 0, 0, SWP_NOZORDER | SWP_NOSIZE);
				tempX = tempX + pluginwidth + offset;
			}

		}
		maxdelta += SlitHandle ? SlitHangout : 0;
		if(SlitVertical)
		{
			SlitWidth = maxdelta + (offset * 2);
			SlitHeight = tempY;
		}
		else
		{
			SlitWidth = tempX;
			SlitHeight = maxdelta + (offset * 2);
		}
		setSlitPosition();
	}

	if (vSlitWindows.size() > 0)
		ShowWindow(SlitWnd, SW_SHOWNORMAL);
	else
		ShowWindow(SlitWnd, SW_HIDE);
}

void setSlitPosition()
{
	int ScreenWidth = FullScreen ? GetSystemMetrics(SM_CXVIRTUALSCREEN) : GetSystemMetrics(SM_CXSCREEN);
    int ScreenHeight = FullScreen ? GetSystemMetrics(SM_CYVIRTUALSCREEN) : GetSystemMetrics(SM_CYSCREEN);


	if (!_stricmp(SlitPlacement, "BottomCenter"))
	{
		SlitX = (ScreenWidth - SlitWidth) / 2;
		SlitY = ScreenHeight - SlitHeight;
	}
	else if (!stricmp(SlitPlacement, "TopLeft"))
	{
		SlitX = 0;
		SlitY = 0;
	}
	else if (!_stricmp(SlitPlacement, "BottomLeft"))
	{
		SlitX = 0;
		SlitY = ScreenHeight - SlitHeight;
	}
	else if (!_stricmp(SlitPlacement, "TopRight"))
	{
		SlitX = ScreenWidth - SlitWidth;
		SlitY = 0;
	}
	else if (!_stricmp(SlitPlacement, "BottomRight"))
	{
		SlitX = ScreenWidth - SlitWidth;
		SlitY = ScreenHeight - SlitHeight;
	}
	else if(!_stricmp(SlitPlacement, "CenterLeft"))
	{
		SlitY = (ScreenHeight - SlitHeight) / 2;
		SlitX = 0;
	}
	else if(!_stricmp(SlitPlacement, "CenterRight"))
	{
		SlitY = (ScreenHeight - SlitHeight) / 2;
		SlitX = ScreenWidth - SlitWidth;
	}
	else //if(!stricmp(SlitPlacement, "TopCenter"))
	{
		SlitX = ReadInt(RCPath, "bbSlit.x:", (ScreenWidth - SlitWidth) / 2 );
		SlitY = ReadInt(RCPath, "bbSlit.y:", 0);
	}

	SlitHideX = SlitX;
	SlitHideY = SlitY;
	
	if(SlitAutoHide)
	{
		if((IsInString(SlitPlacement, "Left") && SlitVertical) || !_stricmp(SlitPlacement, "CenterLeft"))
			SlitHideX = SlitX - (SlitWidth - SlitHangout);
		else if((IsInString(SlitPlacement, "Right")  && SlitVertical) || (!_stricmp(SlitPlacement, "CenterRight")))
			SlitHideX = ScreenWidth - SlitHangout;
		else if (IsInString(SlitPlacement, "Bottom"))
			SlitHideY = ScreenHeight - SlitHangout;
		else if(IsInString(SlitPlacement, "Top"))
			SlitHideY = SlitY - (SlitHeight - SlitHangout);
	}

	if (SlitShown)
		MoveWindow(SlitWnd, SlitX, SlitY, SlitWidth, SlitHeight, true);
    else
		MoveWindow(SlitWnd, SlitHideX, SlitHideY, SlitWidth, SlitHeight, true);
	
	InvalidateRect(SlitWnd, NULL, true);
}

void showMenu(bool popup)
{
	Menu *pMenu, *pMenuPos, *pMenuOr;
	bool MonitorCount = GetSystemMetrics(SM_CMONITORS) > 1;
	
	pMenu = MakeNamedMenu("bbSlit", "bbSlit_IDMain", popup);
	MakeMenuItem(pMenu, "Always On Top", "@bbSlit Toggle OnTop", SlitOnTop);
	MakeMenuItem(pMenu, "Shade", "@bbSlit Toggle Shade", SlitAutoHide);
	MakeMenuItem(pMenu, "Use Handle", "@bbSlit Toggle Handle", SlitHandle);
	if( SlitTrans != 255 )
		MakeMenuItemInt(pMenu, "Alpha Transparency", "@bbSlit AlphaValue", SlitTrans, 0, 255 );
	MakeMenuItem(pMenu, "Toggle with Plugins", "@bbSlit Toggle Plugins", SlitToggle);
	MakeMenuNOP(pMenu, NULL);

	pMenuPos = MakeNamedMenu("Placement", "bbSlit_IDPos", popup);
	MakeMenuItem(pMenuPos, "Top Left", "@bbSlit Placement TopLeft", (bool)(!_stricmp(SlitPlacement, "TopLeft")));
	MakeMenuItem(pMenuPos, "Top Center", "@bbSlit Placement TopCenter", (bool)(!_stricmp(SlitPlacement, "TopCenter")));
	MakeMenuItem(pMenuPos, "Top Right", "@bbSlit Placement TopRight", (bool)(!_stricmp(SlitPlacement, "TopRight")));
	MakeMenuItem(pMenuPos, "Center Left", "@bbSlit Placement CenterLeft", (bool)(!_stricmp(SlitPlacement, "CenterLeft")));
	MakeMenuItem(pMenuPos, "Center Right", "@bbSlit Placement CenterRight", (bool)(!_stricmp(SlitPlacement, "CenterRight")));
	MakeMenuItem(pMenuPos, "Bottom Left", "@bbSlit Placement BottomLeft", (bool)(!_stricmp(SlitPlacement, "BottomLeft")));
	MakeMenuItem(pMenuPos, "Bottom Center", "@bbSlit Placement BottomCenter", (bool)(!_stricmp(SlitPlacement, "BottomCenter")));
	MakeMenuItem(pMenuPos, "Bottom Right", "@bbSlit Placement BottomRight", (bool)(!_stricmp(SlitPlacement, "BottomRight")));
	if (MonitorCount)
	{
		MakeMenuNOP(pMenuPos, NULL);
		MakeMenuItem(pMenuPos, "Full Screen", "@bbSlit FullScreen", FullScreen);
	}
	MakeSubmenu(pMenu, pMenuPos, "Placement");

	pMenuOr = MakeNamedMenu("Orientation", "bbSlit_IDOr", popup);
	MakeMenuItem(pMenuOr, "Vertical", "@bbSlit Orientation Vertical", (SlitVertical == true));
	MakeMenuItem(pMenuOr, "Horizontal", "@bbSlit Orientation Horizontal", (SlitVertical == false));
	MakeSubmenu(pMenu, pMenuOr, "Orientation");
	MakeMenuNOP(pMenu, NULL);

	MakeMenuItem(pMenu, "Edit Settings", "@bbSlit EditRC", false);
	MakeMenuItem(pMenu, "About bbSlit", "@bbSlit About bbSlit", false);

	ShowMenu(pMenu);
}

void loadPlugins()
{
	char szBuffer[MAX_LINE_LENGTH]="";
	char message[MAX_LINE_LENGTH];

	FILE *f = FileOpen(plugrcPath());
	while(ReadNextCommand(f, szBuffer, sizeof(szBuffer)))
	{
		if (szBuffer[0] != '&') continue;
		for(unsigned i = 0; i < strlen(szBuffer); i++)
			szBuffer[i] = szBuffer[i + 1];

		HINSTANCE hModule = LoadLibrary(szBuffer);
		if (hModule)
		{
			pBeginPluginEx beginPluginEx = (pBeginPluginEx)GetProcAddress(hModule, "beginPluginEx");
			pBeginSlitPlugin beginSlitPlugin = (pBeginSlitPlugin)GetProcAddress(hModule, "beginSlitPlugin");
			pEndPlugin endPlugin = (pEndPlugin)GetProcAddress(hModule, "endPlugin");

			if (!endPlugin)
			{
				strcpy(message, szBuffer);
				strcat(message, "\nThe plugin you are trying to load does not have a endPlugin.\nPlease contact the plugin author.");
				MBoxErrorValue(message);
				Log("[BBSlit] This plugin does not have a endPlugin", szBuffer);
				continue;
			}
			if (!beginSlitPlugin && !beginPluginEx)
			{
				strcpy(message, szBuffer);
				strcat(message, "\nThe plugin you are trying to load does not have a beginSlitPlugin.\nThis means the plugin was not designed for the slit.\nIf you would like to see it slit-able, please contact the plugin author.");
				MBoxErrorValue(message);
				Log("[BBSlit] This plugin does not have a beginSlitPlugin", szBuffer);                 
			}
			if(beginSlitPlugin || beginPluginEx)
			{
				try
				{
					if(beginPluginEx)
						beginPluginEx(hModule, SlitWnd);
					else if(beginSlitPlugin)
						beginSlitPlugin(hModule, SlitWnd);
					
					vSlitPlugins.push_back(hModule);
					continue;
				}
				catch (...)
				{
					;
				}
			}

			pBeginPlugin beginPlugin = (pBeginPlugin)GetProcAddress(hModule, "beginPlugin");
			if(!beginPlugin)
			{
				strcpy(message, szBuffer);
				strcat(message, "The plugin you are trying to load does not have a beginPlugin.\nPlease contact the plugin author.\n");
				MBoxErrorValue(message);
				Log("[BBSlit] This plugin does not have a beginSlitPlugin", szBuffer);
				continue;
			}
			try
			{
				beginPlugin(hModule);
				vSlitPlugins.push_back(hModule);
			}
			catch(...)
			{
				FreeLibrary(hModule);
				Log("[BBSlit] The plugin did not load properly.", szBuffer);
			}
		}
		else
		{
			char message[MAX_LINE_LENGTH];
			strcpy(message, szBuffer);
			strcat(message, "\nThe plugin you are trying to load does not exist.\nPlease check your plugin configuration file.");
			MBoxErrorValue(message);
		}
	}
	
	FileClose(f);
}

void unloadPlugins()
{
	for(unsigned i = 0; i < vSlitPlugins.size(); i++)
	{
		pEndPlugin endPlugin = (pEndPlugin)GetProcAddress(vSlitPlugins[i], "endPlugin");
		endPlugin(vSlitPlugins[i]);
		FreeLibrary(vSlitPlugins[i]);
	}
	vSlitPlugins.clear();
	vSlitWindows.clear();
}
