/******************************************************************************
* uberbox is a plugin for Blackbox for Windows							*
*******************************************************************************
* Copyright (c) 2003 Brian Hartvigsen						                    *
* Copyright (c) 2006 John Williamson						                    *
* Copyright (c) 2008-2009 The Blackbox for Windows Development Team  *
*******************************************************************************
  Blackbox for Windows is free software, released under the
  GNU General Public License (GPL version 2 or later), with an extension
  that allows linking of proprietary modules under a controlled interface.
  What this means is that plugins etc. are allowed to be released
  under any license the author wishes. Please note, however, that the
  original Blackbox gradient math code used in Blackbox for Windows
  is available under the BSD license.

  http://www.fsf.org/licenses/gpl.html
  http://www.fsf.org/licenses/gpl-faq.html#LinkingOverControlledInterface
  http://www.xfree86.org/3.3.6/COPYRIGHT2.html#5

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.
*************************************************************************************/

#define HIST_SIZE 650
#define ALI_SIZE 250
#pragma warning(disable : 4996)
#pragma comment (lib, "blackbox.lib")
#include "BBApi.h"

#ifdef __BORLANDC__
#define _stricmp stricmp
#endif

#ifdef MAX_LINE_LENGTH
    #undef MAX_LINE_LENGTH
#endif
#define MAX_LINE_LENGTH 4096

class Broambox
{
public:
  HWND hEditWnd;
  HWND hSlit;
  bool shown;
  int x, y, width, height;
  WNDPROC wpEditProc;
  void AddAlias (char *alias, char *expands);
  COLORREF textColor;
  bool useAutoHide;
  HANDLE LastACHandle;
  void AutoCompletePath (char *path);
  void SaveSettings(void);
  void ShowAliases();
  Broambox (HINSTANCE, HWND);
  bool CreateBroambox ();
  void DestroyBroambox ();
  void PaintBroambox (HDC, LPRECT);
  void ReadSettings ();
  void ReplaceFont ();

  void ShowWindow ();
  void ShowWindowAt (int x, int y);
  void HideWindow ();
  void SizeBroambox ()
  {
	  MoveWindow (hEditWnd, x, y, width, height, TRUE);
	  ShowWindow ();
  }

  void EnterSlit ();
  void UpdateSlit ();
  bool InSlit ()
  {
	  return (inSlit && (hSlit != NULL));
  }
  void ToggleInSlit ()
  {
	  if (hSlit == NULL)
		  return;
	  if (InSlit ())
		  ShowWindowAt(x, y);
	  else
		  EnterSlit ();
  }
  void Execute ();
  void HistoryPrev ();
  void HistoryNext ();

  LRESULT RButtonDown (HWND, UINT, WPARAM, LPARAM);

  HINSTANCE hMainInst;
  void AutoCompleteNext (char *str, int istab);
  void AutoCompletePrev (char *str);
  void AutoCompleteReset ();
  char localDir[MAX_PATH];
  HWND hBB4Win;
  int stylePtr;
  bool sameBorder;
  int bevelStyle;
  int alpha;
  char location[8];
  
  bool inSlit;
private:
  int nAli;
  char alias_names[ALI_SIZE][200];
  char alias_vals[ALI_SIZE][600];
  void ExpandAlias (char *ret_val, char *alias_val, char *remaining,
		    char *args);
  void ExpandAliases (char *buf, char *args);
  
  void AutoComplete (char *text);
  void reverseHistory ();
  int lastTabCompleteIndex;

  void SetWinFont (HWND win, HFONT font);
  HFONT aliasFont;
  HFONT hEditFont;

  bool tempSlit;
  bool isSlitAutoHide;
  const char* commandLine;

  StyleItem *mainStyle;
  StyleItem *editStyle;
  void DisplayMenu(bool popup);

  int bevelWidth, borderWidth;
  int fontHeight;
  int historyIndex;
  int historyCount;
  char history[HIST_SIZE][650];
};
