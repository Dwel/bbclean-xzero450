#define IS_SPC(c) ((unsigned char)(c) <= 32)
#define GET_X_LPARAM(lParam)   ((int)(short)LOWORD(lParam))
#define GET_Y_LPARAM(lParam)   ((int)(short)HIWORD(lParam))
#define DBGR
/******************************************************************************
* uberbox is a plugin for Blackbox for Windows							*
*******************************************************************************
* Copyright (c) 2003 Brian Hartvigsen						                    *
* Copyright (c) 2006 John Williamson						                    *
* Copyright (c) 2008-2009 The Blackbox for Windows Development Team  *
*******************************************************************************
  Blackbox for Windows is free software, released under the
  GNU General Public License (GPL version 2 or later), with an extension
  that allows linking of proprietary modules under a controlled interface.
  What this means is that plugins etc. are allowed to be released
  under any license the author wishes. Please note, however, that the
  original Blackbox gradient math code used in Blackbox for Windows
  is available under the BSD license.

  http://www.fsf.org/licenses/gpl.html
  http://www.fsf.org/licenses/gpl-faq.html#LinkingOverControlledInterface
  http://www.xfree86.org/3.3.6/COPYRIGHT2.html#5

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.
*************************************************************************************/

#include "Broambox.h"
#include "../bbPlugin/moreutils.cpp"

#pragma comment (lib, "user32.lib")
#pragma comment (lib, "gdi32.lib")
#pragma comment (lib, "shell32.lib")

extern LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
extern LRESULT CALLBACK EditProc (HWND, UINT, WPARAM, LPARAM);
int messages[] = { BB_BROADCAST, BB_RECONFIGURE, 0 };
char path[MAX_PATH];

Broambox::Broambox (HINSTANCE hInstance, HWND hWnd)
{
  hMainInst = hInstance;

  hBB4Win = GetBBWnd ();
  hSlit = hWnd;
  hEditWnd = NULL;

  hEditFont = NULL;

  mainStyle = NULL;
  editStyle = NULL;

  inSlit = false;

  tempSlit = false;

  historyIndex = 0;
  historyCount = 0;
  ZeroMemory (&history, sizeof (history));

  ReadSettings ();
}

bool Broambox::CreateBroambox ()
{
	hEditWnd = CreateWindowEx (WS_EX_TOOLWINDOW | WS_EX_ACCEPTFILES,
		"EDIT",
		NULL,
		WS_POPUP | WS_VISIBLE | ES_AUTOHSCROLL |
		ES_MULTILINE, x, y, width, height, NULL, NULL,
		hMainInst, NULL);

	wpEditProc =
    (WNDPROC) (LONG_PTR) SetWindowLong (hEditWnd, GWL_WNDPROC, (LONG) (LONG_PTR) (WNDPROC) EditProc);

  SendMessage (hBB4Win, BB_REGISTERMESSAGE, (WPARAM) hEditWnd,
               (LPARAM) messages);
  MakeSticky (hEditWnd);

  if (InSlit ())
    SendMessage (hSlit, SLIT_ADD, 0, (LPARAM) hEditWnd);
  if (!shown)
	  HideWindow ();

  commandLine = GetOSVersion() < 40 ? "command.com" : "cmd.exe";

  GetModuleFileName (hMainInst, path, sizeof (path));
  int nLen = strlen (path) - 1;
  while (nLen > 0 && path[nLen] != '\\')
    nLen--;
  path[nLen + 1] = 0;
  strcpy (localDir, path);
  sprintf(path, "%s%s", localDir, "tmp");
  if (!SetCurrentDirectory(path))
  {
	  SetCurrentDirectory(localDir);
	  BBExecute (NULL, NULL, commandLine, "/c md tmp", NULL, SW_HIDE, false);
  }

  ReplaceFont ();

  return 0;
}

void
Broambox::DestroyBroambox ()
{
  SendMessage (hBB4Win, BB_UNREGISTERMESSAGE, (WPARAM) hEditWnd,
               (LPARAM) messages);
  RemoveSticky (hEditWnd);

  if (hEditFont)
    DeleteObject (hEditFont);
  DestroyWindow (hEditWnd);

  UnregisterClass (pluginInfo (PLUGIN_NAME), hMainInst);
}

void
Broambox::PaintBroambox (HDC hdc, LPRECT rp)
{

  RECT bounds = *rp;

  if (bevelWidth < 3) 
      mainStyle->bevelstyle = editStyle->bevelstyle = bevelStyle;

  if (false == sameBorder)
    {
		MakeStyleGradient (hdc, rp, mainStyle, false);

		bounds.bottom -= (bevelWidth + borderWidth);
		bounds.top += (bevelWidth + borderWidth);
		bounds.right -= (bevelWidth + borderWidth);
		bounds.left += (bevelWidth + borderWidth);

		MakeStyleGradient (hdc, &bounds, editStyle, false);
    }
  else
     MakeStyleGradient (hdc, rp, editStyle, false);
}

void
Broambox::reverseHistory ()
{
  int i, j;
  if (!historyCount)
    return;

  char tmp[MAX_LINE_LENGTH];
  i = 0;
  j = historyCount - 1;

  while (i < j)
    {
      strcpy (tmp, history[i]);
      strcpy (history[i], history[j]);
      strcpy (history[j], tmp);
      i++;
      j--;
    }
}

void
Broambox::AddAlias (char *alias, char *expands)
{
  sprintf (path, "%saliases.rc", localDir);

  FILE *f_ali = fopen (path, "a");
  if (!f_ali)
	  fopen (".\\aliases.rc", "w");
  if (f_ali)
  {
	  fprintf (f_ali, "%s %s\n", alias, expands);
	  fflush (f_ali);
	  fclose (f_ali);
  }
}

const char *style_strings[] = {
	"not used"			,
	"Toolbar"          ,

	"Toolbar Button"    ,
	"Toolbar Button Pressed"		,
	"Toolbar Label"   ,

	"Toolbar Window Label"    ,
	"Toolbar Clock"		,
	"Menu Title"     ,

	"Menu Frame"        ,
	"Menu Hilite"      ,
	NULL
};

const char *bevel_strings[] = {
	"Flat Bevel"			,
	"Raised Bevel"        ,
	"Sunken Bevel"      ,
	"Default Bevel"      ,
	NULL
};

void Broambox::SaveSettings(void)
{
	sprintf(path, "%s\\%s", localDir, "uberbox.rc");

	WriteInt (path, "broambox.x:", x);
	WriteInt (path, "broambox.y:", y);
	WriteInt (path, "broambox.width:", width);
	WriteInt (path, "broambox.alpha:", alpha);

	WriteString(path, "broambox.style:", style_strings[stylePtr]);
	WriteString(path, "broambox.bevelStyle:", bevel_strings[bevelStyle]);
	WriteString(path, "broambox.location:", location);

	WriteBool (path, "broambox.sameBorder:", sameBorder);
	WriteBool (path, "broambox.autohide:", useAutoHide);
	WriteBool (path, "broambox.visible:", shown);
	WriteBool (path, "broambox.useslit:", inSlit);
}

void
Broambox::ReadSettings ()
{
  char temp[32];
  char pathh[MAX_PATH], patha[MAX_PATH];
  int nLen;

  /* Get the module path */
  GetModuleFileName (hMainInst, path, sizeof (path));
  nLen = strlen (path) - 1;
  while (nLen > 0 && path[nLen] != '\\')
    nLen--;
  path[nLen + 1] = 0;
  strcpy (localDir, path);
  
  sprintf (pathh, "%shistory.rc", path);
  sprintf (patha, "%saliases.rc", path);

  nAli = historyCount = 0;


  // Load History 
  FILE *f_hist = fopen (pathh, "r");
  if (!f_hist)
    {
      sprintf (pathh, ".\\history.rc");
      f_hist = fopen (pathh, "r");
    }

  if (f_hist)
    {
      char histbuf[MAX_LINE_LENGTH];
      char *hist_read;
      do
	{
	  hist_read = fgets (histbuf, (sizeof (histbuf) - 1), f_hist);
	  if (hist_read)
	    {
	      hist_read[strlen (hist_read) - 1] = '\0';
	      strcpy (history[historyCount++], hist_read);
	    }
	}
      while (hist_read && (historyCount < HIST_SIZE));

      fclose (f_hist);
    }
  reverseHistory ();		//Oops

  FILE *f_ali = fopen (patha, "r");
  if (!f_ali)
    {
      sprintf (patha, ".\\aliases.rc");


      f_ali = fopen (patha, "r");
    }

  if (f_ali)
    {
      char alibuf[MAX_LINE_LENGTH], *alival;
      char *ali_read;
      do
	{
	  ali_read = fgets (alibuf, (sizeof (alibuf) - 1), f_ali);
	  if (ali_read)
	    {

	      alival = strchr (ali_read, ' ');

	      if (alival)
		{
		  *(alival++) = '\0';
		  alival[strlen (alival) - 1] = '\0';
		}


	      if (alival)
		strcpy (alias_vals[nAli], alival);
	      else
		strcpy (alias_vals[nAli], "");

	      strcpy (alias_names[nAli++], ali_read);
	    }
	}
      while (ali_read);

      fclose (f_ali);
    }

  sprintf (path, "%suberbox.rc", localDir);

  x = ReadInt (path, "broambox.x:", 595);
  y = ReadInt (path, "broambox.y:", 30);

 
  const char *bevel_string = ReadString (path, "broambox.bevelStyle:", "Sunken Bevel");
  bevelStyle        = get_string_index(bevel_string, bevel_strings);

  const char *style_string = ReadString (path, "broambox.style:", "Toolbar Button Pressed");
  stylePtr        = get_string_index(style_string, style_strings);

  sameBorder = ReadBool (path, "broambox.sameBorder:", false);
  width = ReadInt (path, "broambox.width:", 200);
  alpha = ReadInt (path, "broambox.alpha:", *(int *)GetSettingPtr(SN_MENUALPHA));
  inSlit = ReadBool (path, "broambox.useslit:", false);
  useAutoHide = ReadBool (path, "broambox.autohide:", false);
  shown = ReadBool (path, "broambox.visible:", true);
  const char *check = ReadString(path, "broambox.location:", (char *)"com");
  strcpy(location, strlen(check) < 2 ? "com" : check);

  // Get style settings from the current style file...
  strcpy (path, stylePath ());

  // syntax test
  bool nix = false;
  strcpy(temp, ReadString(path, "toolbar.appearance:", (char *)"no"));
  if (strlen(temp) != 2) nix = true;

  // Get the applicable colors...
  // ...gradient type, bevel etc. (using a StyleItem)...
  editStyle = new StyleItem;
  editStyle = (StyleItem *)GetSettingPtr(stylePtr);
  if (editStyle->parentRelative)
	  editStyle = stylePtr == SN_TOOLBAR ? (StyleItem *)GetSettingPtr(SN_MENUFRAME) : (StyleItem *)GetSettingPtr(SN_TOOLBAR);
  textColor = editStyle->TextColor;

  mainStyle = new StyleItem;
  int j = stylePtr == SN_MENUFRAME ? SN_MENUTITLE : (stylePtr == SN_TOOLBAR ? SN_TOOLBARWINDOWLABEL : (stylePtr < SN_MENUTITLE ? SN_TOOLBAR : SN_MENUFRAME));
  mainStyle = (StyleItem *)GetSettingPtr(j);
  if (mainStyle->parentRelative)
	mainStyle = (StyleItem *)GetSettingPtr(SN_MENUFRAME);

  fontHeight = stylePtr == SN_TOOLBAR ? editStyle->FontHeight : (stylePtr == SN_MENUFRAME ? editStyle->FontHeight : mainStyle->FontHeight);

  // ...and some additional parameters
  bevelWidth = nix ? mainStyle->marginWidth : *(int *)GetSettingPtr(SN_BEVELWIDTH);
  borderWidth = nix ? mainStyle->borderWidth : *(int *)GetSettingPtr(SN_BORDERWIDTH);
  height = fontHeight + 2 + (2 * bevelWidth) + (borderWidth * 2);
}

void
Broambox::SetWinFont (HWND win, HFONT font)
{
  if (font != NULL)
    DeleteObject (font);

  font = CreateStyleFont((StyleItem *)GetSettingPtr(stylePtr < 7 ? SN_TOOLBAR : SN_MENUFRAME));

  SendMessage (win, WM_SETFONT, (WPARAM) font, FALSE);
}

void
Broambox::ReplaceFont ()
{
  if (hEditFont != NULL)
    DeleteObject (hEditFont);

  hEditFont = CreateStyleFont((StyleItem *)GetSettingPtr(stylePtr < 7 ? SN_TOOLBAR : SN_MENUFRAME));

  SendMessage (hEditWnd, WM_SETFONT, (WPARAM) hEditFont, FALSE);

  TEXTMETRIC TXM;
  HDC hdc = CreateCompatibleDC (NULL);
  SelectObject (hdc, hEditFont);
  GetTextMetrics (hdc, &TXM);
  DeleteDC (hdc);

  int realfontheight = TXM.tmHeight;    //pixel

  RECT r;
  GetClientRect (hEditWnd, &r);

  int extraspace = (r.bottom - realfontheight) / 2;
  if (extraspace < 0)
    extraspace = 0;

  r.left = extraspace + 1;
  r.right -= extraspace + 1;
  r.top = extraspace;
  r.bottom -= extraspace;

  SendMessage (hEditWnd, EM_SETRECT, 0, (LPARAM) & r);
}

void
Broambox::ExpandAlias (char *ret_val, char *alias_val, char *remaining,
                       char *args)
{
  char *arg;
  char tmp[MAX_PATH];
  if (strlen(alias_val) >= sizeof path)
	  return;
  strcpy (path, alias_val);

  arg = strstr (path, "<args>");
  if (arg)
    {
      *(arg) = '\0';
      arg += 6;
      strcpy (ret_val, path);
      strcat (ret_val, remaining);
      strcat (ret_val, arg);
    }
  else
    {
      strcpy (tmp, path);
      char *start = tmp;
      if (start && *start == '"')
        {
          start++;
          while (*start && *start != '"')
            start++;
        }
      char *remg = strchr (start, ' ');

      if (remg)
        {
          *(remg++) = '\0';
          strcpy (ret_val, tmp);
          strcpy (args, remg);
          if (remaining)
            strcat (args, remaining);
        }
      else
        {
          strcpy (ret_val, path);
          if (remaining)
            strcpy (args, remaining);
        }
    }
}

void
Broambox::ExpandAliases (char *buf, char *args)
{
  char *firstword;
  char *remaining;
  char *start;
  int found_match = 0;
  char tmp[MAX_LINE_LENGTH];
  if (strlen(buf) >= sizeof tmp)
	  return;
  strcpy (tmp, buf);
  start = tmp;
  if (start && *start == '"')
    {
      start++;
      while (*start && *start != '"')
        start++;
    }

  remaining = strchr (start, ' ');
  if (remaining)
    *(remaining++) = '\0';
  firstword = tmp;

  char ret_val[MAX_LINE_LENGTH];
  strcpy (ret_val, tmp);
  if (remaining)
    strcpy (args, remaining);
  else
    strcpy (args, "");

  if (firstword)
    {

      if (firstword[0] == '?' && remaining)
        {
          int remln = strlen (remaining);
          /* Fix for search engines */
          for (int j = 0; j < remln; j++)
            {
              if (remaining[j] == ' ')
                remaining[j] = '+';
            }
        }

	  for (int i = 0; i < nAli; i++)
	  {
		  if (alias_names[i] && alias_vals[i])
		  {
			  if (!(_stricmp (firstword, alias_names[i])))
			  {
				  ExpandAlias (ret_val, alias_vals[i], remaining, args);

				  found_match = 1;
				  break;
			  }
		  }
	  }

      if (!found_match && firstword[0] == '?')
        {
			sprintf (ret_val, "http://www.google.%s/search?q=", location);
			if (remaining)
				strcat (ret_val, remaining);
        }
    }
  strcpy (buf, ret_val);
}

void
Broambox::Execute ()
{
  bool redirect = false;
  bool edit = false;
  char *buf;
  char bufs[MAX_LINE_LENGTH], args[MAX_LINE_LENGTH];
  char hbuf[MAX_LINE_LENGTH];

  GetWindowText (hEditWnd, bufs, sizeof (bufs));
  buf = bufs;
  strcpy (hbuf, buf);

  if (*buf == '*')
    {
      redirect = true;
      buf++;
    }

  if (*buf == '#')
    {
      edit = true;
      buf++;
    }

  ExpandAliases (buf, args);

  for (unsigned int i = 0; i < strlen (buf); i++)
    {
      if (IS_SPC (buf[i]))
        buf[i] = ' ';
    }

  for (unsigned int i = 0; i < strlen (args); i++)
    {
      if (IS_SPC (args[i]))
        args[i] = ' ';
    }

  if (strlen (buf) < 2)
    return;

  if (buf[0] == '@')
    {
      if(strlen(args)>0)
      {
        strcat (buf, " ");
        strcat (buf, args);
      }

      PostMessage (hBB4Win, BB_BROADCAST, 0, (LPARAM) strdup (buf));
    }
  else if (buf[0] == '[' && buf[strlen (buf) - 1] == ']')
    {
      if (!_stricmp (buf, "[exit]") || !_stricmp (buf, "[quit]"))
        PostMessage (hBB4Win, BB_QUIT, 0, 0);
      else if (!_stricmp (buf, "[shutdown]"))
        PostMessage (hBB4Win, BB_SHUTDOWN, 0, 0);
      else if (!_stricmp (buf, "[reboot]"))
        PostMessage (hBB4Win, BB_SHUTDOWN, 1, 0);
      else if (!_stricmp (buf, "[logoff]"))
        PostMessage (hBB4Win, BB_SHUTDOWN, 2, 0);
      else if (!_stricmp (buf, "[hibernate]"))
        PostMessage (hBB4Win, BB_SHUTDOWN, 3, 0);
      else if (!_stricmp (buf, "[suspend]"))
        PostMessage (hBB4Win, BB_SHUTDOWN, 4, 0);
      else if (!_stricmp (buf, "[lock]"))
        PostMessage (hBB4Win, BB_SHUTDOWN, 5, 0);
      else if (!_stricmp (buf, "[run]"))
        PostMessage (hBB4Win, BB_RUN, 0, 0);
      else if (!_stricmp (buf, "[reconfig]"))
        PostMessage (hBB4Win, BB_RECONFIGURE, 0, 0);
      else if (!_stricmp (buf, "[restart]"))
        PostMessage (hBB4Win, BB_RESTART, 0, 0);
      else if (!_stricmp (buf, "[editstyle]"))
        PostMessage (hBB4Win, BB_EDITFILE, 0, 0);
      else if (!_stricmp (buf, "[editmenu]"))
        PostMessage (hBB4Win, BB_EDITFILE, 1, 0);
      else if (!_stricmp (buf, "[editplugins]"))
        PostMessage (hBB4Win, BB_EDITFILE, 2, 0);
      else if (!_stricmp (buf, "[editextensions]"))
        PostMessage (hBB4Win, BB_EDITFILE, 3, 0);
    }
  else
    {
		if (redirect)
		{
			char tempfile[32];
			char buffer[MAX_PATH];
			GetBlackboxEditor(buffer);
			tmpnam (tempfile);
			sprintf (path, "/c %s %s > %stmp\\%s", buf, args, localDir, tempfile);

			BBExecute (NULL, NULL, commandLine, path, NULL, SW_HIDE, false);
			sprintf (path, "%stmp\\%s", localDir, tempfile);
			Sleep (300);
			FILE *inf = fopen (tempfile, "r");
			if (inf)
			{
				char input[65536];
				input[fread (input, 1, sizeof (input), inf)] = '\0';
			}
			BBExecute(NULL, NULL, buffer, path, NULL, SW_SHOWNORMAL, false);
		}
		else if (edit)
		{
			char buffer[MAX_PATH];
			GetBlackboxEditor(buffer);
			sprintf (path, "%s%s", buf, args);
			BBExecute(NULL, NULL, buffer, path, NULL, SW_SHOWNORMAL, false);
		}
		else
		{
			if (!BBExecute (NULL, NULL, buf, args, NULL, SW_SHOWNORMAL, true))
			{
				sprintf(path, "http://%s", buf);
				BBExecute(NULL, NULL, path, "", NULL, SW_SHOWNORMAL, false);
			}
		}
  }

  SetWindowText (hEditWnd, "");

  if(buf[0]!='@')
  {	
	strcat(buf, " ");
	strcat(buf, args);
  }

  if (strlen (hbuf) > 1)
    {
	  sprintf (path, "%shistory.rc", localDir);

	  for (int i = historyCount - 1; i >= 0; i--)
	  {
		  if (!_stricmp(hbuf, history[i]))
			  return;
		  strcpy (history[i + 1], history[i]);
	  }

	  strcpy (history[0], hbuf);

      if (historyCount < HIST_SIZE)
        historyCount++;

      FILE *f_hist = fopen (path, "a");

      if (!f_hist)
        f_hist = fopen (".\\history.rc", "w");
      if (f_hist)
        {
          fprintf (f_hist, "%s\n", hbuf);
          fflush (f_hist);
          fclose (f_hist);
        }
    }
}

void
Broambox::ShowWindow ()
{
  SaveSettings();
  if (!InSlit ())
    ShowWindowAt (x, y);
}

void
Broambox::ShowWindowAt (int x, int y)
{
  if (InSlit ())
    {
      tempSlit = true;
      SendMessage (hSlit, SLIT_REMOVE, 0, (LPARAM) hEditWnd);
      inSlit = false;
	  SaveSettings();
	  ReadSettings();
    }
  SetWindowPos (hEditWnd, HWND_TOPMOST, x, y, 0, 0,
	  SWP_NOSENDCHANGING | SWP_NOSIZE | SWP_SHOWWINDOW);
  SetTransparency(hEditWnd, (BYTE)alpha);
}

void
Broambox::HideWindow ()
{
  SaveSettings();
  if (tempSlit && hSlit != NULL)
  {
	  EnterSlit ();
	  tempSlit = false;
  }
  else if (!InSlit ())
	  SetWindowPos (hEditWnd, NULL, x, y, 0, 0,
	  SWP_NOZORDER | SWP_NOSENDCHANGING | SWP_NOSIZE |
	  SWP_HIDEWINDOW);
}

void
Broambox::EnterSlit ()
{
  if (!InSlit ())
    {
	  SetTransparency(hEditWnd, 255);
      SendMessage (hSlit, SLIT_ADD, 0, (LPARAM) hEditWnd);
      inSlit = true;
	  SaveSettings();
    }
}

void
Broambox::UpdateSlit ()
{
  if (InSlit ())
    SendMessage (hSlit, SLIT_UPDATE, 0, 0);
}

void
Broambox::AutoCompletePath (char *tmp)
{
  int n, k;
  bool quoted = false;
  int qindex = 0;

  if (strlen(tmp) >= sizeof path)
	  return;
  strcpy (path, tmp);
  if (sizeof path < 1)
	  return;
  n = strlen (path) - 1;
  k = strlen (path) - 1;
  while (path[k] != '\\' && k > 0)
    k--;
  k++;
  while (path[n] == ' ' && n > 0)
    n--;

  if (path[n] == '"')
    {
      quoted = true;
      qindex = n;
      n--;
      while (path[n] != '"' && n > 0)
        n--;
    }
  else
    while (path[n] != ' ' && n > 0)
      n--;
  n++;
  if (!quoted)
    strcat (path, "*");
  else
    {
      path[qindex] = '*';
      strcat (path, "\"");
    }


  WIN32_FIND_DATA fd;
  if (!LastACHandle)
    LastACHandle = FindFirstFile (path + n, &fd);
  else
    FindNextFile (LastACHandle, &fd);
  if(LastACHandle!=INVALID_HANDLE_VALUE && !strcmp(fd.cFileName, "."))
	  FindNextFile (LastACHandle, &fd);
  if(LastACHandle!=INVALID_HANDLE_VALUE && !strcmp(fd.cFileName, ".."))

  if (LastACHandle != INVALID_HANDLE_VALUE && strlen (fd.cFileName) < 2)
    LastACHandle = FindFirstFile (tmp + n, &fd);
  if (LastACHandle != INVALID_HANDLE_VALUE)
    {
	  if(!quoted && strchr(fd.cFileName, ' '))
	  {
		char qtmp[MAX_PATH];
		strcpy(qtmp, path);
		qtmp[n] = '\"';
		strcpy(qtmp+n+1, path+n);
		quoted = 1;
		k++;
		strcpy(path, qtmp);
	  }
      strcpy (path + k, fd.cFileName);
	  if(quoted)
		  strcat(path, "\"");
      SetWindowText (hEditWnd, path);
	  if(quoted)
		  SendMessage (hEditWnd, EM_SETSEL, strlen (path)-1, strlen (path)-1);
	  else
          SendMessage (hEditWnd, EM_SETSEL, strlen (path), strlen (path));
    }
  else
    {
      LastACHandle = NULL;
    }
}

void
Broambox::AutoCompleteReset (void)
{
  lastTabCompleteIndex = 0;
}

void
Broambox::AutoCompleteNext (char *cur, int istab)
{
  int j;
  int prev = lastTabCompleteIndex - 1;
  if (prev < 0)
    prev += historyCount;
  for (int i = 0; i < historyCount; i++)
    {
      j = (i + lastTabCompleteIndex) % historyCount;

      if (strstr (history[j], cur) == history[j]
          && (!istab || _stricmp (history[j], history[prev])))
        {
          SetWindowText (hEditWnd, history[j]);
          lastTabCompleteIndex = j + 1;
          break;
        }
    }
  SendMessage (hEditWnd, EM_SETSEL, (WPARAM)0, (LPARAM)-1);
  SendMessage (hEditWnd, EM_SETSEL, (WPARAM)-1, (LPARAM)0);
}

void
Broambox::AutoCompletePrev (char *cur)
{
  int j, k;
  for (int i = 0; i < historyCount; i++)
    {
      k = (i + lastTabCompleteIndex) % historyCount;
      j = historyCount - k;

      if (strstr (history[j], cur) == history[j])
        {
          SetWindowText (hEditWnd, history[j]);
          lastTabCompleteIndex = j - 1;
          if (lastTabCompleteIndex < 0)
            lastTabCompleteIndex += historyCount;
          break;
        }
    }
  SendMessage (hEditWnd, EM_SETSEL, 0, 0xffffffff);
  SendMessage (hEditWnd, EM_SETSEL, 0xffffffff, 0);
}

void
Broambox::AutoComplete (char *cur)
{
  for (int i = 0; i < historyCount; i++)
    {
      if (strstr (history[i], cur) == history[i])
        SetWindowText (hEditWnd, history[i]);
    }

  SendMessage (hEditWnd, EM_SETSEL, 0, 0xffffff);
  SendMessage (hEditWnd, EM_SETSEL, 0xffffff, 0);
}


void
Broambox::HistoryNext ()
{
  char *szBuf;

  if (historyIndex >= historyCount)
    {
      szBuf = history[historyCount - 1];
      historyIndex = historyCount;
    }
  else
    szBuf = history[historyIndex++];

  SetWindowText (hEditWnd, szBuf);

  SendMessage (hEditWnd, EM_SETSEL, 0, 0xffffffff);
  SendMessage (hEditWnd, EM_SETSEL, 0xffffffff, 0);
}

void
Broambox::HistoryPrev ()
{
  char *szBuf;

  if (historyIndex <= 0)
    {
      szBuf = (char *)"";
      historyIndex = 0;
    }
  else
    {
      if (historyIndex != 1)
        szBuf = history[historyIndex - 2];
      else
        szBuf = (char *)"";
      historyIndex--;
    }

  SetWindowText (hEditWnd, szBuf);

  SendMessage (hEditWnd, EM_SETSEL, 0, 0xffffffff);
  SendMessage (hEditWnd, EM_SETSEL, 0xffffffff, 0);
}

void Broambox::ShowAliases()
{
  char ali[MAX_LINE_LENGTH];
  char out[65536];
  out[0] = '\0';
      RECT rect;
      RECT drect;
      GetWindowRect (GetDesktopWindow (), &drect);
      GetWindowRect (hEditWnd, &rect);
      int bx = rect.left + 800;
      int by = rect.top + 500;
      int dx = width, dy = height;
      if (bx > drect.right)
        dx = drect.right - bx - 800;
      if (by > drect.bottom)
        dy = drect.bottom - by - 500;

	  HWND hAliasWnd = CreateWindowEx (WS_EX_TOOLWINDOW,
		  "EDIT",
		  "Ub@rBox_lite",
		  WS_POPUP | WS_VISIBLE | WS_VSCROLL
		  | ES_MULTILINE | WS_OVERLAPPEDWINDOW,
		  rect.left + dx, rect.top + dy, 800,
		  500,
		  NULL,
		  NULL,
		  hMainInst,
		  NULL);


	  for (int i = 0; i < nAli; i++)
	  {
		  sprintf (ali, "%s %s\r\n", alias_names[i], alias_vals[i]);
		  strcat (out, ali);
	  }

	  SetWindowText (hAliasWnd, out);
      SetWinFont (hAliasWnd, aliasFont);
}

void Broambox::DisplayMenu(bool popup)
{
	Menu *pMenu, *pEdit, *pFrame, *pStyle;

	pMenu = MakeNamedMenu("Ub@rBox_lite", "uBox", popup);
	MakeMenuItem(pMenu, "Show Aliases", "@BroamBox.ShowAliases", false);

	MakeMenuNOP(pMenu,NULL);
    pFrame = MakeNamedMenu("Frame", "uFrame", popup);
	for (int n = 0; n < 4; ++n)
	{
		char b2[80];
		sprintf(b2, "@BroamBox.Bevel %d", n);
		MakeMenuItem(pFrame, bevel_strings[n], b2, bevelStyle == n);
	}

	MakeMenuNOP(pFrame, NULL);
	MakeMenuItemInt(pFrame, "Width", "@BroamBox.Width", width, 1, 2000);
	MakeMenuItem(pFrame, "Same Border", "@BroamBox.SameBorder", sameBorder);
	MakeMenuItemInt(pFrame, "Alpha", "@BroamBox.Alpha", alpha, 0, 255);
	MakeMenuNOP(pFrame, NULL);
	MakeMenuItem(pFrame, "Autohide", "@BroamBox.Autohide", useAutoHide);
	MakeMenuItem(pFrame, "Use Slit", "@BroamBox.ToggleSlit", inSlit);	
	MakeSubmenu(pMenu, pFrame, "Frame");

    pStyle = MakeNamedMenu("Style", "uStyle", popup);
	for (int n = 1; n < SN_MENUBULLET; ++n)
	{
		char b2[80];
		sprintf(b2, "@BroamBox.Style %d", n);
		MakeMenuItem(pStyle, style_strings[n], b2, stylePtr == n);
		if (n % 3 == 0)
			MakeMenuNOP(pStyle, NULL);
	}
	MakeSubmenu(pMenu, pStyle, "Style");

    pEdit = MakeNamedMenu("Edit", "uEdit", popup);
	MakeMenuItem(pEdit, "Reload All", "@BroamBox.Reload", false);
	MakeMenuItem(pEdit, "Edit Aliases", "@BroamBox.EditAliases", false);
	MakeMenuItem(pEdit, "Edit History", "@BroamBox.EditHistory", false);
	MakeMenuItem(pEdit, "Edit Settings", "@BroamBox.EditRC", false);
	MakeMenuItemString(pEdit, "Location", "@BroamBox.Location", location);
	MakeSubmenu(pMenu, pEdit, "Edit");

	MakeMenuNOP(pMenu, NULL);
	MakeMenuItem(pMenu, "Documentation", "@BroamBox.LoadDocs", false);
	MakeMenuItem(pMenu, "About", "@BroamBox.About", false);

	ShowMenu(pMenu);
}

LRESULT
  Broambox::RButtonDown (HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	if (GetAsyncKeyState (VK_CONTROL) & 0x8000)
	{
		DisplayMenu(true);
		return 0;
	}
	else 
	if (GetAsyncKeyState (VK_SHIFT) & 0x8000)
	{
		SendMessage(hBB4Win, BB_BROADCAST, 0, (LPARAM)"@BroamBox.ShowAliases");
		return 0;
	}
     
  return CallWindowProc (wpEditProc, hWnd, uMsg, wParam, lParam);
}
