/******************************************************************************
* uberbox is a plugin for Blackbox for Windows							*
*******************************************************************************
* Copyright (c) 2003 Brian Hartvigsen						                    *
* Copyright (c) 2006 John Williamson						                    *
* Copyright (c) 2008-2009 The Blackbox for Windows Development Team  *
*******************************************************************************
  Blackbox for Windows is free software, released under the
  GNU General Public License (GPL version 2 or later), with an extension
  that allows linking of proprietary modules under a controlled interface.
  What this means is that plugins etc. are allowed to be released
  under any license the author wishes. Please note, however, that the
  original Blackbox gradient math code used in Blackbox for Windows
  is available under the BSD license.

  http://www.fsf.org/licenses/gpl.html
  http://www.fsf.org/licenses/gpl-faq.html#LinkingOverControlledInterface
  http://www.xfree86.org/3.3.6/COPYRIGHT2.html#5

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.
*************************************************************************************/

#define IS_NUMERIC_KEY(key) ((key >= 0x30) && (key <= 0x39))
#define IS_ALPHA_KEY(key) ((key >= 0x41) && (key <= 0x5A))
#define IS_NUMPAD_KEY(key) ((key >= 0x60) && (key <= 0x6F))
#define IS_OTHER_KEY(key) ((key == VK_SPACE) || (key == VK_BACK) || (key == VK_DELETE))

#define KEY_CHECK(key) (IS_NUMERIC_KEY(key) || IS_ALPHA_KEY(key) || IS_NUMPAD_KEY(key) || IS_OTHER_KEY(key))

#define _WIN32_WINNT 0x0500

#include "Broambox.h"
#include "bblib.h"
#include <shellapi.h>

char szVersion [] = "UberBox_lite 1.2";
char szAppName [] = "Ub@rBox_lite";
char szInfoVersion [] = "1.2";
char szAuthor [] = "tzec | Tres'ni | unkamunka";
char szInfoRelDate [] = "2009-06-01";
char szInfoLink [] = "http://bb4win.sourceforge.net/";
char szInfoEmail [] = "irc://irc.freenode.net/bb4win";
char szInfoUpdateURL [] = "http://www.lostinthebox.com/viewtopic.php?t=3048";
char szCopyright [] = "2003-2009 John Williamson | Brian \"Tresni\" Hartvigsen";
static const char broam_prefix[] = "@broambox.";

Broambox *pBBox;

extern "C"
{
	DLL_EXPORT int beginPlugin (HINSTANCE hInstance);
	DLL_EXPORT int beginPluginEx (HINSTANCE hInstance, HWND hWnd)
	{
		pBBox = new Broambox (hInstance, hWnd);
		return pBBox->CreateBroambox ();
	}
	DLL_EXPORT void endPlugin (HINSTANCE hInstance)
	{
		pBBox->SaveSettings();
		pBBox->DestroyBroambox ();
		delete (pBBox);
	}
	DLL_EXPORT LPCSTR pluginInfo (int field)
	{
		static char *infostr[9] =
		{
			szVersion,
			szAppName,
			szInfoVersion,
			szAuthor,
			szInfoRelDate,
			szInfoLink,
			szInfoEmail,
			(char *)("@BroamBox.About"
			"@BroamBox.Focus"
			"@BroamBox.SameBorder"
			"@BroamBox.EditSettings"
			"@BroamBox.EditHistory"
			"@BroamBox.EditAliases"
			"@BroamBox.ToggleSlit"
			"@BroamBox.Reload"
			"@BroamBox.Autohide"
			"@BroamBox.Hide"
			"@BroamBox.Show"
			"@BroamBox.Toggle" 
			"@BroamBox.ShowAliases"),
			szInfoUpdateURL
		};
		return (field >= 0 && field < 9) ? infostr[field] : infostr[0];
	}
};

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK EditProc (HWND, UINT, WPARAM, LPARAM);

void about_box(void)
{
	char buffer[256];
	sprintf(buffer, "%s - %s\n\n � %s\n\n\n%s\n\n%s", szVersion, szInfoRelDate, szCopyright, szInfoUpdateURL, szInfoEmail);
	MessageBox(pBBox->hBB4Win, buffer, szAppName, MB_OK);
}

int focused = 0;
#define AUTOHIDE_TIMER 21451

void
autoHide (int hide, HWND win)
{
  RECT winRect;
  RECT drect;
  GetWindowRect (win, &winRect);
  GetWindowRect (GetDesktopWindow (), &drect);
  if (hide && pBBox->useAutoHide && !focused)
    {
      int width = pBBox->width;
      int height = pBBox->height;
      int x = pBBox->x;
      int y = pBBox->y;
      int ox = x;
      int oy = y;
      if (y <= x)
        {
		  oy = 0;
          height = 3;
        }
      else if (x <= y)
        {
		  ox = 0;
          width = 3;
        }
	  // height computation too CPU-intensive
      if (y + 24 >= drect.bottom)
		  oy = drect.bottom - 24;
      if (x + width >= drect.right)
          ox = drect.right - width;

      SetWindowPos (win, HWND_TOPMOST, ox, oy, width, height,
                    SWP_NOMOVE | SWP_NOACTIVATE | SWP_NOZORDER);

	  if (x < 0 || x + width >= drect.right)
		  pBBox->x = ox;
	  if (y < 0 || y + 24 >= drect.bottom)
		  pBBox->y = oy;
    }
  else
    {
	  SetTransparency(pBBox->hEditWnd, focused ? 255 : (BYTE)pBBox->alpha);
      SetWindowPos (win, HWND_TOPMOST, pBBox->x, pBBox->y, pBBox->width,
                    pBBox->height, SWP_NOACTIVATE | SWP_NOZORDER);
	  DWORD startSel, endSel;
	  PostMessage(win, EM_SCROLLCARET, 0, 0);
	  SendMessage(win,         // handle to destination window 
		  EM_GETSEL,           // message to send
		  (WPARAM)&startSel,     // starting position (LPDWORD)
		  (LPARAM)&endSel);
	  SendMessage(win, EM_SETSEL, startSel, endSel);
      pBBox->ReplaceFont ();
    }
  
  if (pBBox->useAutoHide)
    {
      if (focused)
        {
          focused--;
          SetTimer (win, AUTOHIDE_TIMER, 1000, NULL);
        }
      else
        {
          SetTimer (win, AUTOHIDE_TIMER, 50, NULL);
        }
    }
}

bool aliasDragDrop = false;
bool inTab = false;
char tabStr[MAX_PATH], curText[MAX_LINE_LENGTH];
int zDelta;
HWND aliasWnd = NULL;
char aliasStr[400];
INT_PTR CALLBACK
AliasDlgFunc (HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
  HWND textWnd;

  switch (uMsg)
  {

    case WM_INITDIALOG:
      char str[MAX_LINE_LENGTH];
      SetFocus (GetDlgItem (hwndDlg, 401));
	  if(!aliasDragDrop)
	  {
		  ShowWindow(GetDlgItem(hwndDlg, 403), SW_HIDE);
		  ShowWindow(GetDlgItem(hwndDlg, 404), SW_HIDE);
		  sprintf (str, "Alias for: %s", curText);
		  textWnd = GetDlgItem (hwndDlg, 402);
		  SetWindowText (textWnd, str);
	  }
	  else
	  {
		  ShowWindow(GetDlgItem(hwndDlg, 403), SW_SHOW);
		  ShowWindow(GetDlgItem(hwndDlg, 404), SW_SHOW);
		  sprintf (str, "Alias for: %s", file_basename(curText));
		  SetWindowText(GetDlgItem(hwndDlg, 404), str);
	  }
      return true;
      break;

    case WM_CLOSE:

      DestroyWindow (hwndDlg);
      aliasWnd = NULL;
      return TRUE;


	case WM_COMMAND:
		switch (LOWORD (wParam))
		{

	case IDCANCEL:
		DestroyWindow (hwndDlg);
		aliasWnd = NULL;

		return TRUE;
		break;

	case IDOK:
		int gotText = GetDlgItemText (hwndDlg,
			401,
			aliasStr,
			sizeof (aliasStr));
		if (gotText)
		{
			char args[64];
			if(aliasDragDrop && GetDlgItemText(hwndDlg, 403, args, sizeof(args)))
			{
				if(strlen(args)>0)
					strcat(curText, " ");
				strcat(curText, args);
			}

			pBBox->AddAlias (aliasStr, curText);
		}
		DestroyWindow (hwndDlg);
		aliasWnd = NULL;

		return TRUE;
		break;
	}

	default:
      return false;
    }
}

void
AddAlias (char *str, bool dragdrop)
{
  if (strlen (str) > 1)
    {
      strcpy (curText, str);
	  aliasDragDrop = dragdrop;
      DialogBox (pBBox->hMainInst, MAKEINTRESOURCE (400), NULL, AliasDlgFunc);
      ShowWindow (aliasWnd, SW_SHOW);
    }
}

int ParseBool(char *lwr)
{

	if(lwr && (strstr(lwr, "yes")==lwr || strstr(lwr, "on")==lwr || strstr(lwr, "true")==lwr || strstr(lwr, "1")==lwr))
		return 1;
	else
		return 0;

}

POINT PrevPoint;
bool prevValid = false;
LRESULT CALLBACK
EditProc (HWND hText, UINT msg, WPARAM wParam, LPARAM lParam)
{

HDROP hp;

  switch (msg)
    {
    case WM_TIMER:
      {
        if (wParam == AUTOHIDE_TIMER)
          {
            POINT pt;
            RECT rect;
            GetCursorPos (&pt);
            GetWindowRect (hText, &rect);

            if (pt.x >= pBBox->x && pt.x <= pBBox->x + pBBox->width
                && pt.y >= pBBox->y && pt.y <= pBBox->y + pBBox->height)
              {
	  SetTransparency(pBBox->hEditWnd, 255);
                autoHide (0, hText);
              }
            else
              autoHide (1, hText);
	  SetTransparency(pBBox->hEditWnd, pBBox->alpha);
          }

      }
	  break;

    case WM_SETFOCUS:
      {
		focused = 1;
        autoHide (0, hText);
        SendMessage (hText, EM_SETSEL, 0, -1);
        KillTimer (hText, AUTOHIDE_TIMER);
        SetTimer (hText, AUTOHIDE_TIMER, 1000, NULL);
		
      }
      break;

    case WM_KILLFOCUS:
      {
	    focused = 0;
        autoHide (1, hText);
		SetWindowPos (hText, HWND_NOTOPMOST, 0, 0, 0, 0,
			SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);


      }
      break;

    case WM_MOUSEMOVE:
      {
        autoHide (0, hText);
      }
      break;

    case WM_NCHITTEST:
      {
        if (((GetAsyncKeyState (VK_CONTROL) & 0x8000) || (GetAsyncKeyState (VK_SHIFT) & 0x8000)) && !pBBox->inSlit)
          return HTCAPTION;
      }

    case WM_NCRBUTTONUP:
      {
        autoHide (0, hText);
        return pBBox->RButtonDown (hText, msg, wParam, lParam);
      }

    case WM_MOVE:
      pBBox->x = (int) (short) LOWORD (lParam);
      pBBox->y = (int) (short) HIWORD (lParam);
      pBBox->SaveSettings();
      break;
    case WM_MOUSEWHEEL:
      zDelta = GET_WHEEL_DELTA_WPARAM (wParam);
      if (zDelta < 0)
        wParam = VK_DOWN;
      else if (zDelta > 0)
        wParam = VK_UP;
    case WM_KEYDOWN:
      {
	    if(wParam == VK_ESCAPE)
		{
			if(prevValid)
			{
				POINT pt;
				GetCursorPos (&pt);
				SetCursorPos (PrevPoint.x, PrevPoint.y);

				mouse_event (MOUSEEVENTF_MIDDLEDOWN, PrevPoint.x, PrevPoint.y, 0, 0);
				Sleep(20);

				mouse_event (MOUSEEVENTF_MIDDLEUP, PrevPoint.x, PrevPoint.y, 0, 0);
				mouse_event (MOUSEEVENTF_MIDDLEDOWN, PrevPoint.x, PrevPoint.y, 0, 0);

				mouse_event (MOUSEEVENTF_MIDDLEUP, PrevPoint.x, PrevPoint.y, 0, 0);

				SetCursorPos (pt.x, pt.y);
			}
            return 0;
		}
        if ((GetAsyncKeyState (VK_CONTROL) & 0x8000) && wParam == 0x4C) // Ctrl-L key
          {
            char tmp[MAX_LINE_LENGTH];
            GetWindowText (hText, tmp, sizeof (tmp) - 1);
            AddAlias (tmp, false);
            return 0;
          }
        if ((GetAsyncKeyState (VK_CONTROL) & 0x8000) && wParam == 0x49) //Ctrl-I
          {
            char txt[MAX_LINE_LENGTH];
            char broadStr[MAX_LINE_LENGTH];
            GetWindowText (hText, txt, sizeof (txt));
            sprintf (broadStr, "@BBInterface Control Create Button %s", txt);


            PostMessage (pBBox->hBB4Win, BB_BROADCAST, 0,
                         (LPARAM) strdup (broadStr));
            sprintf (broadStr,
                     "@BBInterface Control SetAgent %s MouseUp Bro@m \"@BroamBox.Relay %s\"",
                     txt, txt);
            MessageBox (NULL, broadStr, NULL, MB_OK);
            PostMessage (pBBox->hBB4Win, BB_BROADCAST, 0,
                         (LPARAM) strdup (broadStr));
            sprintf (broadStr,
                     "@BBInterface Control SetAgent %s Caption StaticText \"%s\"",
                     txt, txt);

            PostMessage (pBBox->hBB4Win, BB_BROADCAST, 0,
                         (LPARAM) strdup (broadStr));
            return 0;
          }
        if ((GetAsyncKeyState (VK_CONTROL) & 0x8000) && wParam == 0x41) //Ctrl-A
          {
			SendMessage(pBBox->hBB4Win, BB_BROADCAST, 0, (LPARAM)"@broambox.autoHide");
            return 0;
          }
        if ((GetAsyncKeyState (VK_CONTROL) & 0x8000) && wParam == 0x45) //Ctrl-E
          {
			SendMessage(pBBox->hBB4Win, BB_BROADCAST, 0, (LPARAM)"@broambox.editaliases");
            return 0;
          }

        autoHide (0, hText);
        KillTimer (hText, AUTOHIDE_TIMER);
        SetTimer (hText, AUTOHIDE_TIMER, 1000, NULL);
        if (wParam == VK_TAB)
          {
            char cur_text[MAX_PATH];
            GetWindowText (hText, cur_text, MAX_PATH);

            if (GetAsyncKeyState (VK_SHIFT) & 0x8000)
              {
                pBBox->AutoCompletePath (cur_text);
              }
            else
              {
                if (!inTab)
                  {
                    strcpy (tabStr, cur_text);
                    pBBox->AutoCompleteNext (cur_text, 1);
                    inTab = true;
                  }
                else
                  {
                    pBBox->AutoCompleteNext (tabStr, 1);
                  }
              }
            return 0;
          }

        if (wParam == VK_DOWN)
          {
            char cur_text[MAX_PATH];
            GetWindowText (hText, cur_text, MAX_PATH);
            if (strlen (cur_text) < 1 || (inTab && strlen (tabStr) < 1))
              {
                pBBox->HistoryPrev ();
                inTab = 1;
                strcpy (tabStr, "");
              }
            else
              {
                if (!inTab)
                  {
                    strcpy (tabStr, cur_text);
                    pBBox->AutoCompleteNext (cur_text, 0);
                    inTab = true;
                  }
                else
                  {
                    pBBox->AutoCompleteNext (tabStr, 0);
                  }

              }
            return 0;
          }
        if (wParam == VK_UP)
          {
            char cur_text[255];
            GetWindowText (hText, cur_text, 255);
            if (strlen (cur_text) < 1 || (inTab && strlen (tabStr) < 1))
              {
                pBBox->HistoryNext ();
                inTab = 1;
                strcpy (tabStr, "");
              }
            else
              {
                if (!inTab)
                  {
                    strcpy (tabStr, cur_text);
                    pBBox->AutoCompletePrev (cur_text);
                    inTab = true;
                  }
                else
                  {
                    pBBox->AutoCompletePrev (tabStr);
                  }
              }
            return 0;
          }
        if (KEY_CHECK (wParam))
          InvalidateRect (hText, NULL, true);
      }
      break;

    case WM_CHAR:
      {
	    focused = 1;
        if (wParam == VK_TAB || wParam == VK_UP || wParam == VK_DOWN)
          {
            return 0;
          }
        if (pBBox->LastACHandle)
          FindClose (pBBox->LastACHandle);
        pBBox->LastACHandle = NULL;
        pBBox->AutoCompleteReset ();
        inTab = false;

        if (wParam == VK_RETURN)
          {
            pBBox->Execute ();
            return 0;
          }
      }
      break;

    case WM_CLOSE:
      {
        return 0;
      }
      break;                    // no ALT+F4

    case WM_PAINT:
      {
        PAINTSTRUCT ps;

        HDC hdc = BeginPaint (hText, &ps);
        RECT r;
        GetClientRect (hText, &r);

        HDC buf = CreateCompatibleDC (NULL);
        HGDIOBJ oldbuf =
          SelectObject (buf, CreateCompatibleBitmap (hdc, r.right, r.bottom));

        pBBox->PaintBroambox (buf, &r);

        CallWindowProc (pBBox->wpEditProc, hText, msg, (WPARAM) buf, lParam);

        BitBlt (hdc, 0, 0, r.right, r.bottom, buf, 0, 0, SRCCOPY);

        DeleteObject (SelectObject (buf, oldbuf));
        DeleteDC (buf);

        EndPaint (hText, &ps);
        return 0;
      }
      break;

    case WM_CTLCOLOREDIT:
      {
        SetTextColor ((HDC) wParam, pBBox->textColor);
        SetBkMode ((HDC) wParam, TRANSPARENT);
        return (LRESULT) GetStockObject (NULL_BRUSH);
      }
      break;

    case WM_ERASEBKGND:
      return TRUE;

	case WM_DROPFILES:
		char fileBuf[MAX_LINE_LENGTH];
		hp = (HDROP) wParam;
		DragQueryFile(hp,0,fileBuf,sizeof(fileBuf));
		AddAlias (fileBuf, true);
		DragFinish(hp);
		return 0;
		break;

	case BB_BROADCAST:
		{
			const char *msg_string = (LPCSTR)lParam;
			char path[MAX_PATH];

			// check general broams
			if (!_stricmp (msg_string, "@BBShowPlugins"))
			{
				pBBox->ShowWindow ();
				break;
			}
			if (!_stricmp (msg_string, "@BBHidePlugins"))
			{
				pBBox->HideWindow ();
				break;
			}

			// check broams sent from our own menu
			const int broam_prefix_len = sizeof broam_prefix - 1; // minus terminating \0
			if (!memicmp(msg_string, broam_prefix, broam_prefix_len))
			{
				msg_string += broam_prefix_len;
				char *args = strchr ((char *)msg_string, ' ');
				bool p = false;
				if(args)
				{
					args++;
					if (!_stricmp (args, "true")) 
						p = true;
				}
				if (!_stricmp (msg_string, "Focus"))
				{
					focused = 1;
					RECT rect;
					POINT pt;
					prevValid = true;
					EnableWindow (hText, true);
					GetWindowRect (hText, &rect);
					ShowWindow (hText, SW_SHOWNORMAL);
					SetFocus (hText);
					SetWindowPos (hText, HWND_TOP, 0, 0, 0, 0,
						SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW);
					autoHide (0, hText);

					GetCursorPos (&pt);
					SetCursorPos (rect.left, rect.top);
					mouse_event (MOUSEEVENTF_LEFTDOWN, rect.left, rect.top, 0, 0);
					mouse_event (MOUSEEVENTF_MOVE, rect.left, rect.top, 0, 0);
					SetWindowPos (hText, HWND_TOPMOST, 0, 0, 0, 0,
						SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW);

					mouse_event (MOUSEEVENTF_LEFTUP, rect.left, rect.top, 0, 0);

					SetCursorPos (pt.x, pt.y);
					PrevPoint.x = pt.x;
					PrevPoint.y = pt.y;
					break;
				}
				if (!memicmp (msg_string, "Relay", 5))
				{
					char tmp[MAX_LINE_LENGTH];
					GetWindowText (hText, tmp, sizeof (tmp));
					if (args)
						SetWindowText (hText, args );
					pBBox->Execute ();
					SetWindowText (hText, tmp);
					break;
				}
				if(!memicmp (msg_string, "Style", 5))
				{
					pBBox->stylePtr = args ? (int)strtol(args,NULL,10) : SN_TOOLBARBUTTONP;
					pBBox->SaveSettings();
					pBBox->ReadSettings();
					break;
				}
				if(!memicmp (msg_string, "Bevel", 5))
				{
					pBBox->bevelStyle = args ? (int)strtol(args,NULL,10) : 3;
					pBBox->SaveSettings();
					pBBox->ReadSettings();
					break;
				}
				if(!_stricmp (msg_string, "ShowAliases"))
				{
					pBBox->ShowAliases();
					break;
				}
				if(!memicmp (msg_string, "Width", 5))
				{
					if(args)
					{
						pBBox->width = (int)strtol(args,NULL,10);
						pBBox->SaveSettings(); 
						pBBox->ReadSettings();
						pBBox->SizeBroambox();
					}
					break;
				}
				if(!memicmp (msg_string, "Alpha", 5))
				{
					if(args)
					{
						pBBox->alpha = (int)strtol(args,NULL,10);
						pBBox->SaveSettings(); 
						pBBox->ReadSettings();
						pBBox->SizeBroambox();
					}
					break;
				}
				if(!_stricmp (msg_string, "Reload"))
				{
					pBBox->ReadSettings();
					pBBox->SizeBroambox();
					pBBox->ReplaceFont();
					break;
				}
				if (!_stricmp (msg_string, "LoadDocs"))
				{
					sprintf(path, "%s\\%s", pBBox->localDir, "uberbox.html");
					BBExecute(pBBox->hBB4Win, "open", path, NULL, NULL, SW_SHOWNORMAL, false);
					break;
				}
				if (!memicmp(msg_string, "Show", 4))
				{
					pBBox->shown = args ? p : true;
					if (pBBox->shown == true)
						pBBox->ShowWindow ();
					else
						pBBox->HideWindow ();
					break;
				}
				if (!memicmp(msg_string, "Hide", 4))
				{
					pBBox->shown =  args ? !p : false;
					if (pBBox->shown == true)
						pBBox->ShowWindow ();
					else
						pBBox->HideWindow ();
					break;
				}
				if(!memicmp (msg_string, "sameBorder", 10))
				{
					pBBox->sameBorder = args ? p : !pBBox->sameBorder;
					pBBox->SaveSettings(); 
					break;
				}
				if(!memicmp (msg_string, "autoHide", 9))
				{
					pBBox->useAutoHide = args ? p : !pBBox->useAutoHide;
					pBBox->SaveSettings(); 
					break;
				}
				if(!memicmp (msg_string, "location", 8))
				{
					if (args)
						strcpy(pBBox->location, args);
					else
						strcpy(pBBox->location, "com");
					pBBox->SaveSettings(); 
					break;
				}
				if (!_stricmp (msg_string, "ToggleSlit"))
				{
					pBBox->ToggleInSlit ();
					break;
				}
				if (!_stricmp (msg_string, "Toggle"))
				{
					if (!pBBox->shown)
						pBBox->ShowWindow ();
					else
						pBBox->HideWindow ();
					break;
				}
				if (!_stricmp (msg_string, "About"))
				{
					about_box ();
					break;
				}
				char buffer[MAX_PATH];
				GetBlackboxEditor(buffer);
				if(!_stricmp (msg_string, "EditRC"))
				{
					sprintf (path, "%s\\%s", pBBox->localDir, "uberbox.rc");
					BBExecute(NULL, NULL, buffer, path, NULL, SW_SHOWNORMAL, false);
					break;
				}

				if(!_stricmp (msg_string, "EditAliases"))
				{
					sprintf (path, "%s\\%s", pBBox->localDir, "aliases.rc");
					BBExecute(NULL, NULL, buffer, path, NULL, SW_SHOWNORMAL, false);
					break;
				}
				if(!_stricmp (msg_string, "EditHistory"))
				{
					sprintf (path, "%s\\%s", pBBox->localDir, "history.rc");
					BBExecute(NULL, NULL, buffer, path, NULL, SW_SHOWNORMAL, false);
					break;
				}
			}
		}
		return 0;


  case BB_RECONFIGURE:
      {
        pBBox->ReadSettings ();
        pBBox->SizeBroambox ();
        pBBox->ReplaceFont ();
      } 
      return 0;
    }
  return CallWindowProc (pBBox->wpEditProc, hText, msg, wParam, lParam);
}
