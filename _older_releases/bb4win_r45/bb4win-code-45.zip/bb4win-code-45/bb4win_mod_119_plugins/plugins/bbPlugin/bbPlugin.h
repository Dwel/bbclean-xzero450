/*
 ============================================================================

  This file is part of the bbLean source code.

  Copyright � 2004 grischka
  http://bb4win.sf.net/bblean

  bbLean is free software, released under the GNU General Public License
  (GPL version 2 or later).

  http://www.fsf.org/licenses/gpl.html

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

 ============================================================================
*/  // BBPlugin.h

struct plugin_info
{
	HINSTANCE hInstance;
	struct plugin_info *next;

	const char *class_name;
	HWND hwnd;

	HWND hSlit;
	HMONITOR hMon;
	RECT mon_rect;
	int monitorCount;
	bool fullScreen;

	// config vars
	int place;

	int xpos;
	int ypos;
	int oldx;
	int oldy;
	int width;
	int height;
	int snapWindow;

	bool useSlit;
	bool alwaysOnTop;
	bool autoHide;
	bool usingWin2kPlus;
	bool transparent;
	BYTE alpha;

	int saturation;
	int hue;

	bool clickRaise;
	bool pluginToggle;
	bool visible;

	bool orient_vertical;

	// state vars
	bool inSlit;
	bool toggled_hidden;
	bool auto_hidden;
	bool auto_shown;
    bool mouse_over;
    char suspend_autohide;

	bool is_moving;
	bool is_sizing;
	bool is_visible;
	BYTE has_alpha;

	// misc
	char rcpath[MAX_PATH];
	const char *rc_key;
	const char *broam_key;
	int broam_key_len;

	bool is_bar;
	bool no_icons;

	// virtual functions
	virtual void process_broam(const char *temp, int f) {}
	virtual void show_menu(bool f) {}
	virtual void pos_changed(void) {}
	virtual LRESULT wnd_proc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam, LRESULT *ret) = 0;
	virtual ~plugin_info() {}
};

enum
{
	POS_User          ,

	POS_BottomLeft    ,
	POS_BottomCenter  ,
	POS_BottomRight   ,

	POS_CenterLeft    ,
	POS_AutoHide	  ,
	POS_CenterRight   ,

	POS_TopLeft       ,
	POS_TopCenter     ,
	POS_TopRight      ,

    POS_Center        ,
	POS_Top           ,
	POS_Bottom        ,
	POS_Left          ,
	POS_Right         ,
    POS_CenterH ,
    POS_CenterV ,

	POS_LAST
};

//===========================================================================
#ifdef __cplusplus
extern "C" {
#endif

#ifdef BBP_LIB
#define BBP_DLL_EXPORT extern "C" __declspec(dllexport)
#else
#define BBP_DLL_EXPORT extern "C"
#endif

#define AUTOHIDE_TIMER 1

#define BBP_clear(_P) ZeroMemory(&_P->hInstance,\
	sizeof *_P - ((int)&_P->hInstance - (int)_P));

#define BBP_clear_(_struct,_first)\
    memset(&_first, 0, sizeof(*_struct)-((char*)&_struct->_first-(char*)_struct))

BBP_DLL_EXPORT int  BBP_Init_Plugin(struct plugin_info *PI);
BBP_DLL_EXPORT void BBP_Exit_Plugin(struct plugin_info *PI);
BBP_DLL_EXPORT bool BBP_handle_message(struct plugin_info *PI, HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam, LRESULT *pResult);
BBP_DLL_EXPORT int BBP_messagebox(plugin_info *PI, int flags, const char *fmt, ...);
BBP_DLL_EXPORT int BBP_messagebox(plugin_info *PI, int flags, const char *fmt, ...);
BBP_DLL_EXPORT int BBP_messagebox(plugin_info *PI, int flags, const char *fmt, ...);
BBP_DLL_EXPORT int BBP_messagebox(plugin_info *PI, int flags, const char *fmt, ...);

BBP_DLL_EXPORT bool BBP_read_window_modes(struct plugin_info *PI, const char *rcfile);
BBP_DLL_EXPORT void BBP_write_window_modes(struct plugin_info *PI);

BBP_DLL_EXPORT void BBP_set_window_modes(struct plugin_info *PI);
BBP_DLL_EXPORT void BBP_set_place(struct plugin_info *PI, int place);
BBP_DLL_EXPORT void BBP_set_size(struct plugin_info *PI, int w, int h);
BBP_DLL_EXPORT void BBP_set_visible(plugin_info *PI, bool hidden);
BBP_DLL_EXPORT void BBP_set_autoHide(struct plugin_info *PI, bool set);
BBP_DLL_EXPORT void BBP_reconfigure(struct plugin_info *PI);

BBP_DLL_EXPORT const char *BBP_placement_string(int pos);

BBP_DLL_EXPORT void BBP_write_string(struct plugin_info *PI, const char *rcs, const char *val);
BBP_DLL_EXPORT void BBP_write_int(struct plugin_info *PI, const char *rcs, int val);
BBP_DLL_EXPORT void BBP_write_bool(struct plugin_info *PI, const char *rcs, bool val);

BBP_DLL_EXPORT const char* BBP_read_string(struct plugin_info *PI, char *dest, const char *rcs, const char *def);
BBP_DLL_EXPORT int  BBP_read_int(struct plugin_info *PI, const char *rcs, int def);
BBP_DLL_EXPORT bool BBP_read_bool(struct plugin_info *PI, const char *rcs, bool def);

//===========================================================================
struct n_menu;

BBP_DLL_EXPORT n_menu *n_makemenu(const char *title);
BBP_DLL_EXPORT n_menu *n_submenu(n_menu *m, const char *text);
BBP_DLL_EXPORT void n_showmenu(n_menu *m, const char *broam_key, bool popup);
BBP_DLL_EXPORT void n_menuitem_nop(n_menu *m, const char *text = NULL);
BBP_DLL_EXPORT void n_menuitem_cmd(n_menu *m, const char *text, const char *cmd);
BBP_DLL_EXPORT void n_menuitem_bol(n_menu *m, const char *text, const char *cmd, bool check);
BBP_DLL_EXPORT void n_menuitem_int(n_menu *m, const char *text, const char *cmd, int val, int vmin, int vmax);
BBP_DLL_EXPORT void n_menuitem_str(n_menu *m, const char *text, const char *cmd, const char *init);
BBP_DLL_EXPORT void n_disable_lastitem(n_menu *m);

BBP_DLL_EXPORT void BBP_n_insertmenu(struct plugin_info *PI, n_menu *m);
BBP_DLL_EXPORT void BBP_n_placementmenu(struct plugin_info *PI, n_menu *m);
BBP_DLL_EXPORT void BBP_n_orientmenu(struct plugin_info *PI, n_menu *m);
BBP_DLL_EXPORT void BBP_n_windowmenu(struct plugin_info *PI, n_menu *m);
BBP_DLL_EXPORT bool BBP_broam_int(plugin_info *PI, const char *temp, const char *key, int *ip);
BBP_DLL_EXPORT bool BBP_broam_string(plugin_info *PI, const char *temp, const char *key, const char **ps);
BBP_DLL_EXPORT bool BBP_broam_bool(plugin_info *PI, const char *temp, const char *key, bool *ip);

//===========================================================================

BBP_DLL_EXPORT bool check_mouse(HWND hwnd);
BBP_DLL_EXPORT void BBDrawText(HDC hDC, const char *lpString, int nCount, RECT *lpRect, unsigned uFormat, StyleItem * pSI);

#ifndef __cplusplus
BBP_DLL_EXPORT plugin_info *BBP_create_info(void);
#endif

#define BBP_BROAM_HANDLED 1
#define BBP_BROAM_COMMON 4
#define BBP_BROAM_METRICS 2

#ifdef __cplusplus
}
#endif

//===========================================================================
