/*
 ============================================================================

  This file is part of the bbLean source code.

  Copyright � 2004 grischka
  http://bb4win.sf.net/bblean

  bbLean is free software, released under the GNU General Public License
  (GPL version 2 or later).

  http://www.fsf.org/licenses/gpl.html

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

 ============================================================================
*/

#include "BBApi.h"
#include "bblib.h"
#include "BBPlugin.h"

#define ST static

ST char *BBVersion;
#define BB4WIN strlen(BBVersion) == 5
#define NOT_XOBLITE strlen(BBVersion) != 7 || strlen(BBVersion) == 5

//===========================================================================
// API: SetFullTransparency
// Purpose: Wrapper, win9x compatible
// In:      HWND, alpha
// Out:     bool
//===========================================================================

BOOL (WINAPI *qSetLayeredWindowAttributes)(HWND, COLORREF, BYTE, DWORD) = NULL;

bool SetFullTransparency(HWND hwnd, BYTE alpha)
{
	HMODULE hUser32=LoadLibraryA("user32.dll");
	if (hUser32)
		qSetLayeredWindowAttributes=(BOOL(WINAPI*)(HWND, COLORREF, BYTE, DWORD))GetProcAddress(hUser32, "SetLayeredWindowAttributes");
    if (NULL == qSetLayeredWindowAttributes) return false;

    LONG wStyle1, wStyle2;
    wStyle1 = wStyle2 = GetWindowLong(hwnd, GWL_EXSTYLE);

    if (alpha < 255) wStyle2 |= WS_EX_LAYERED;
    else wStyle2 &= ~WS_EX_LAYERED;

    if (wStyle2 != wStyle1)
        SetWindowLong(hwnd, GWL_EXSTYLE, wStyle2);

    if (wStyle2 & WS_EX_LAYERED)
		return 0 != qSetLayeredWindowAttributes(hwnd, 0, alpha, LWA_COLORKEY);

    return true;
}

//===========================================================================
// Function: GetOSVersion - bb4win_mod
// Purpose: Retrieves info about the current OS & bit version
// In: None
// Out: int = Returns an integer indicating the OS & bit version
//===========================================================================

OSVERSIONINFO osInfo;
bool         using_NT;

int GetOSVersion(void)
{
    ZeroMemory(&osInfo, sizeof(osInfo));
    osInfo.dwOSVersionInfoSize = sizeof(osInfo);
    GetVersionEx(&osInfo);

	//64-bit OS test, when running as 32-bit under WoW
	BOOL bIs64BitOS= FALSE;
	typedef BOOL (WINAPI *LPFN_ISWOW64PROCESS)(HANDLE, PBOOL);
	LPFN_ISWOW64PROCESS fnIsWow64Process = (LPFN_ISWOW64PROCESS)GetProcAddress(GetModuleHandle("kernel32"),"IsWow64Process");
	if (NULL != fnIsWow64Process)
		fnIsWow64Process(GetCurrentProcess(), &bIs64BitOS);
	/*usingx64 = bIs64BitOS;
	//64-bit OS test, if compiled as native 64-bit. In case we ever need it.
	if (!usingx64)
		usingx64=(sizeof(int)!=sizeof(void*));*/

    using_NT         = osInfo.dwPlatformId == VER_PLATFORM_WIN32_NT;

    if (using_NT)
		return ((osInfo.dwMajorVersion * 10) + osInfo.dwMinorVersion + (bIs64BitOS ? 5 : 0)); // NT 40; Win2kXP 50; Vista 60; etc.


	if (osInfo.dwPlatformId == VER_PLATFORM_WIN32_WINDOWS)
    {
        if (osInfo.dwMinorVersion >= 90)
            return 30; // Windows ME
        if (osInfo.dwMinorVersion >= 10)
            return 20; // Windows 98
    }
	return 10; // Windows 95
}

//===========================================================================
// shell support forks

LPCSTR BBP_bbVersion()
{
	static BOOL(WINAPI*pMakeMenuSEP)(Menu *PluginMenu);	
	LPCSTR bbv = GetBBVersion();
	if (0 == _memicmp(bbv, "bbLean (boxCore", 14)) return "boxCore";
	if (0 == _memicmp(bbv, "bbLean 1.16 (bbClean", 20)) return "bbCleanNEB";
	if (0 == _memicmp(bbv, "bbLean|bb4win_mod", 17)) return "bb4win_mod";
	if (0 == (_memicmp(bbv, "bb", 2) + strlen(bbv) - 3)) return "xoblite";
	if (0 == _memicmp(bbv, "0", 1)) return "bb4win";
	*(FARPROC*)&pMakeMenuSEP = GetProcAddress((HINSTANCE)GetModuleHandle(NULL),"MakeMenuSEP");
	if (pMakeMenuSEP) return "bbLeanMod";
	return bbv;
}

//*****************************************************************************

void UpdateMonitorInfo(struct plugin_info *PI)
{

	if (PI->fullScreen)
	{	// single mon (or treat as such)
		PI->mon_rect.left = PI->mon_rect.top = 0;
		PI->mon_rect.right = GetSystemMetrics(SM_CXVIRTUALSCREEN);
		PI->mon_rect.bottom = GetSystemMetrics(SM_CYVIRTUALSCREEN);
	}
	else
	{	// multimon - current monitor
		PI->hMon = MonitorFromWindow(PI->hwnd, MONITOR_DEFAULTTONEAREST);
		MONITORINFO mInfo;
		mInfo.cbSize = sizeof(MONITORINFO);
		GetMonitorInfo(PI->hMon, &mInfo);

		PI->mon_rect.left = mInfo.rcMonitor.left;
		PI->mon_rect.right = mInfo.rcMonitor.right;
		PI->mon_rect.top = mInfo.rcMonitor.top;
		PI->mon_rect.bottom = mInfo.rcMonitor.bottom;
	}
}

//*****************************************************************************

int get_place(struct plugin_info *PI)
{
	UpdateMonitorInfo(PI);

	int sw  = PI->mon_rect.right  - PI->mon_rect.left;
	int sh  = PI->mon_rect.bottom - PI->mon_rect.top;
	int x   = PI->xpos - PI->mon_rect.left;
	int y   = PI->ypos - PI->mon_rect.top;
	int w   = PI->width;
	int h   = PI->height;

	x = iminmax(x, 0, sw - w);
	y = iminmax(y, 0, sh - h);

	bool top        = y == 0;
	bool vcenter    = y == sh/2 - h/2;
	bool bottom     = y == (sh - h);

	bool left       = x == 0;
	bool center     = x == sw/2 - w/2;
	bool right      = x == (sw - w);

	if (top)
	{
		if (left)   return POS_TopLeft   ;
		if (center) return POS_TopCenter ;
		if (right)  return POS_TopRight  ;
		return POS_Top;
	}

	if (bottom)
	{
		if (left)   return POS_BottomLeft   ;
		if (center) return POS_BottomCenter ;
		if (right)  return POS_BottomRight  ;
		return POS_Bottom;
	}

	if (left)
	{
		if (vcenter) return POS_CenterLeft;
		return POS_Left;
	}

	if (right)
	{
		if (vcenter) return POS_CenterRight;
		return POS_Right;
	}

    if (center)
    {
        if (vcenter) return POS_Center;
        return POS_CenterH;
    }

    if (vcenter)
        return POS_CenterV;

	return POS_User;
}

//===========================================================================

void set_place(struct plugin_info *PI)
{
	int sw  = PI->mon_rect.right  - PI->mon_rect.left;
	int sh  = PI->mon_rect.bottom - PI->mon_rect.top;
	int x   = PI->xpos - PI->mon_rect.left;
	int y   = PI->ypos - PI->mon_rect.top;
	int w   = PI->width;
	int h   = PI->height;

	int place = PI->autoHide ? POS_AutoHide : PI->place;

	switch (place)
	{
		case POS_Top:
		case POS_TopLeft:
		case POS_TopCenter:
		case POS_TopRight:
			y = 0;
			break;

		case POS_CenterLeft:
		case POS_CenterRight:
        case POS_CenterV:
        case POS_Center:
			y = sh/2 - h/2;
			break;

		case POS_Bottom:
		case POS_BottomLeft:
		case POS_BottomCenter:
		case POS_BottomRight:
			y = sh - h;
			break;

		/*case POS_AutoHide:
			if (PI->ypos < imin(PI->xpos, sw - PI->xpos))
				y = 0;
			else
			if ((sh - PI->ypos) < imin(PI->xpos, sw - PI->xpos))
				y = sh - h;
			else 
				goto rcy;
			break;

		case POS_User:
rcy:		y = BBP_read_int(PI,  "position.y", PI->ypos);
			break;*/
	}

	switch (place)
	{
		case POS_Left:
		case POS_TopLeft:
		case POS_CenterLeft:
		case POS_BottomLeft:
			x = 0;
			break;

		case POS_TopCenter:
		case POS_BottomCenter:
        case POS_CenterH:
        case POS_Center:
			x = sw/2 - w/2;
			break;

		case POS_Right:
		case POS_TopRight:
		case POS_CenterRight:
		case POS_BottomRight:
			x = sw - w;
			break;

		/*case POS_AutoHide:
			if (PI->xpos < imin(PI->ypos, sh - PI->ypos))
				x = 0;
			else
			if ((sw - PI->xpos) < imin(PI->ypos, sh - PI->ypos))
				x = sw - w;
			else
				goto rcx;
			break;

		case POS_User:
rcx:		x = BBP_read_int(PI,  "position.x", PI->xpos);
			break;*/
	}

	if (false == PI->is_bar)
	{
		switch (place)
		{
		case POS_TopCenter:
		case POS_BottomCenter:
			PI->orient_vertical = false;
			break;

		case POS_CenterLeft:
		case POS_CenterRight:
		case POS_CenterV:
		case POS_Center:
			PI->orient_vertical = true;
			break;
		}
	}

	PI->xpos = PI->mon_rect.left + iminmax(x, 0, sw - w);
	PI->ypos = PI->mon_rect.top  + iminmax(y, 0, sh - h);
}

//===========================================================================

void BBP_set_window_modes(struct plugin_info *PI)
{
	bool useslit = PI->useSlit && PI->hSlit;
    bool visible = PI->visible && (false == PI->toggled_hidden || useslit);
    bool updateslit = false;

	PI->auto_hidden = false;

	if (PI->inSlit && false == useslit)
	{
		SendMessage(PI->hSlit, SLIT_REMOVE, 0, (LPARAM)PI->hwnd);
		PI->inSlit = false;
	}

    if (visible != PI->is_visible)
    {
        ShowWindow(PI->hwnd, visible ? SW_SHOWNA : SW_HIDE);
        PI->is_visible = visible;
        updateslit = true;
    }

	if (useslit)
	{
		RECT r; GetWindowRect(PI->hwnd, &r);
		int w = r.right - r.left;
		int h = r.bottom - r.top;
		bool update_size = (w != PI->width || h != PI->height);

		if (update_size)
        {
			SetWindowPos(
			PI->hwnd,
			NULL,
			0,
			0,
			PI->width,
			PI->height,
			SWP_NOACTIVATE|SWP_NOMOVE|SWP_NOZORDER
			);
            updateslit = true;
        }

		if (false == PI->inSlit)
		{
			SetTransparency(PI->hwnd, 255);
			SendMessage(PI->hSlit, SLIT_ADD, (WPARAM)PI->broam_key, (LPARAM)PI->hwnd);
			PI->inSlit = true;
		}
	else
		if (updateslit)
		{
			SendMessage(PI->hSlit, SLIT_UPDATE, 0, (LPARAM)PI->hwnd);
		}
}
	else
	{
		set_place(PI);
		int x = PI->xpos;
		int y = PI->ypos;

		if (PI->autoHide && false == PI->auto_shown)
		{
			int hangout = 3;
			/*int place = PI->place;*/
			if (x == PI->mon_rect.left)
				x += (hangout - PI->width);
			else
			if (x == (PI->mon_rect.right - PI->width))
					x += (PI->width - hangout);
			else
			if (y == PI->mon_rect.top)
				y += (hangout - PI->height);
			else
			if (y == (PI->mon_rect.bottom - PI->height))
					y += (PI->height - hangout);
			PI->auto_hidden = true;
		}

		HWND hwnd_after; UINT flags;

		if (WS_CHILD & GetWindowLong(PI->hwnd, GWL_STYLE))
		{
			flags = SWP_NOACTIVATE|SWP_NOZORDER;
			hwnd_after = NULL;
		}
		else
		{
			flags = SWP_NOACTIVATE;
			if (PI->alwaysOnTop || PI->auto_shown || PI->auto_hidden)
				hwnd_after = HWND_TOPMOST;
			else
				hwnd_after = HWND_NOTOPMOST;
		}

		SetWindowPos(
			PI->hwnd,
			hwnd_after,
			x,
			y,
			PI->width,
			PI->height,
			flags
			);

		BYTE trans = PI->auto_hidden ? 255 : PI->alpha;
		if (PI->has_alpha != trans)
		{
			if (PI->transparent)
				SetFullTransparency(PI->hwnd, trans);
			else
				SetTransparency(PI->hwnd, trans);
			PI->has_alpha = trans;
		}
	}

	PI->pos_changed();
}

//===========================================================================

const char *placement_strings[] = {
	"User"          ,

	"BottomLeft"    ,
	"BottomCenter"  ,
	"BottomRight"   ,

	"CenterLeft"    ,
	"AutoHide"		,
	"CenterRight"   ,

	"TopLeft"       ,
	"TopCenter"     ,
	"TopRight"      ,

    "Center"        ,
	"Top"           ,
	"Bottom"        ,
	"Left"          ,
	"Right"         ,
	
    "CenterH" ,
    "CenterV" ,
	NULL
};

const char *menu_placement_strings[] = {
	"User"          ,

	"Bottom Left"    ,
	"Bottom Center"  ,
	"Bottom Right"   ,

	"Center Left"    ,
	"Autohide"		 ,
	"Center Right"   ,

	"Top Left"       ,
	"Top Center"     ,
	"Top Right"      ,

    "Center Screen"  ,
	"Top"           ,
	"Bottom"        ,
	"Left"          ,
	"Right"         ,
	NULL
};

//===========================================================================
const char *BBP_placement_string(int pos)
{
	if (pos < 0 || pos >= POS_LAST) pos = 0;
	return placement_strings[pos];
}

//===========================================================================

void BBP_write_string(struct plugin_info *PI, const char *rcs, const char *val)
{
	if (0 == PI->rcpath[0]) return;
	char buffer[256];
	sprintf(buffer, "%s.%s:", PI->rc_key, rcs);
	WriteString(PI->rcpath, buffer, val);
}

void BBP_write_int(struct plugin_info *PI, const char *rcs, int val)
{
	if (0 == PI->rcpath[0]) return;
	char buffer[256];
	sprintf(buffer, "%s.%s:", PI->rc_key, rcs);
	WriteInt(PI->rcpath, buffer, val);
}

void BBP_write_bool(struct plugin_info *PI, const char *rcs, bool val)
{
	if (0 == PI->rcpath[0]) return;
	char buffer[256];
	sprintf(buffer, "%s.%s:", PI->rc_key, rcs);
	WriteBool(PI->rcpath, buffer, val);
}

const char* BBP_read_string(struct plugin_info *PI, char *dest, const char *rcs, const char *def)
{
	char buffer[256];
	sprintf(buffer, "%s.%s:", PI->rc_key, rcs);
	const char *p = ReadString(PI->rcpath, buffer, def);
	if (p && dest) return strcpy(dest, p);
	return p;
}

int BBP_read_int(struct plugin_info *PI, const char *rcs, int def)
{
	char buffer[256];
	sprintf(buffer, "%s.%s:", PI->rc_key, rcs);
	return ReadInt(PI->rcpath, buffer, def);
}

bool BBP_read_bool(struct plugin_info *PI, const char *rcs, bool def)
{
	char buffer[256];
	sprintf(buffer, "%s.%s:", PI->rc_key, rcs);
	return ReadBool(PI->rcpath, buffer, def);
}

void write_rc(struct plugin_info *PI, void *v)
{
	if (v == &PI->xpos)
	{
		BBP_write_string    (PI, "placement", BBP_placement_string(PI->place));
		BBP_write_int       (PI, "position.x", PI->xpos);
		BBP_write_int       (PI, "position.y", PI->ypos);
	}
	else
	if (v == &PI->width)
	{
		BBP_write_int       (PI, "width",  PI->width);
		BBP_write_int       (PI, "height", PI->height);
	}
	else
	if (v == &PI->useSlit)
		BBP_write_bool      (PI, "useSlit", PI->useSlit);
	else
	if (v == &PI->alwaysOnTop)
		BBP_write_bool      (PI, "onTop", PI->alwaysOnTop);
	else
	if (v == &PI->autoHide)
		BBP_write_bool      (PI, "autoHide", PI->autoHide);
	else
	if (v == &PI->clickRaise)
		BBP_write_bool      (PI, "clickRaise", PI->clickRaise);
	else
	if (v == &PI->snapWindow)
		BBP_write_int      (PI, "snapToEdge", PI->snapWindow);
	else
	if (v == &PI->pluginToggle)
		BBP_write_bool      (PI, "pluginToggle", PI->pluginToggle);
	else
	if (v == &PI->alpha)
		BBP_write_int       (PI, "alpha.value", PI->alpha);
	else
	if (v == &PI->transparent)
		BBP_write_bool      (PI, "transparent", PI->transparent);
	else
	if (v == &PI->fullScreen)
		BBP_write_bool       (PI, "fullScreen", PI->fullScreen);
	else
	if (v == &PI->saturation)
		BBP_write_int       (PI, "icon.saturation", PI->saturation);
	else
	if (v == &PI->hue)
		BBP_write_int       (PI, "icon.hue", PI->hue);
	else
	if (v == &PI->orient_vertical)
		BBP_write_string    (PI, "orientation", PI->orient_vertical ? "vertical" : "horizontal");
}

//===========================================================================

bool BBP_read_window_modes(struct plugin_info *PI, const char *rcfile)
{
	locate_file(PI->hInstance, PI->rcpath, rcfile, (char *)"rc");
	PI->xpos = BBP_read_int(PI,  "position.x", 20);
	PI->ypos = BBP_read_int(PI,  "position.y", 20);

	const char *place_string = BBP_read_string(PI, NULL, "placement", NULL);
	PI->place = place_string
		? get_string_index(place_string, placement_strings)
		: POS_User
		;

	PI->hMon = MonitorFromPoint(*(POINT*)&PI->xpos, MONITOR_DEFAULTTONEAREST);
	PI->monitorCount = GetSystemMetrics(SM_CMONITORS);
	PI->fullScreen	= PI->monitorCount > 1 ? BBP_read_bool(PI, "fullScreen", false) : true;
	UpdateMonitorInfo(PI);

	set_place(PI);

	PI->useSlit         = BBP_read_bool(PI, "useSlit", false);
	PI->alwaysOnTop     = BBP_read_bool(PI, "onTop", false);
	PI->autoHide        = BBP_read_bool(PI, "autoHide", false);
	PI->snapWindow      = BBP_read_int(PI, "snapToEdge", 20);
	PI->pluginToggle    = BBP_read_bool(PI, "pluginToggle", true);
	PI->clickRaise      = BBP_read_bool(PI, "clickRaise", true);
	// testing for PI->usingWin2kPlus @ this point always yields !=
	PI->transparent     = BBP_read_bool(PI, "transparent", false);
	PI->alpha			= (BYTE)eightScale_up(BBP_read_int(PI,  "alpha.value",  *(int *)GetSettingPtr(SN_MENUALPHA)));
	if (false == PI->no_icons)
	{
		PI->saturation		= eightScale_up(BBP_read_int(PI,  "icon.saturation", 3));
		PI->hue				= eightScale_up(BBP_read_int(PI,  "icon.hue", 2));
	}
	if (false == PI->is_bar)
		PI->orient_vertical = 0 == stricmp("vertical", BBP_read_string(PI, NULL, "orientation", "vertical"));
	if (NULL == place_string)
	{
		BBP_write_window_modes(PI);
		return false;
	}
	return true;
}

void BBP_write_window_modes(struct plugin_info *PI)
{
	write_rc(PI, &PI->xpos);
	write_rc(PI, &PI->useSlit);
	write_rc(PI, &PI->alwaysOnTop);
	write_rc(PI, &PI->autoHide);
	write_rc(PI, &PI->clickRaise);
	write_rc(PI, &PI->snapWindow);
	write_rc(PI, &PI->pluginToggle);
	write_rc(PI, &PI->alpha);
	write_rc(PI, &PI->transparent);
	if (PI->monitorCount > 1)
		write_rc(PI, &PI->fullScreen);
	if (false == PI->no_icons) 
	{
		write_rc(PI, &PI->saturation);
		write_rc(PI, &PI->hue);
	}
	if (false == PI->is_bar) 
		write_rc(PI, &PI->orient_vertical);
}

//===========================================================================

void set_pluginToggle(struct plugin_info *PI, bool pluginToggle)
{
	PI->pluginToggle = pluginToggle;
	BBP_set_window_modes(PI);
	write_rc(PI, &PI->pluginToggle);
}

void set_useSlit(struct plugin_info *PI, bool useSlit)
{
	PI->useSlit = useSlit;
	BBP_set_window_modes(PI);
	write_rc(PI, &PI->useSlit);
}

void set_alwaysOnTop(struct plugin_info *PI, bool alwaysOnTop)
{
	PI->alwaysOnTop = alwaysOnTop;
	BBP_set_window_modes(PI);
	write_rc(PI, &PI->alwaysOnTop);
}

void set_snapWindow(struct plugin_info *PI, int snapWindow)
{
	PI->snapWindow = snapWindow;
	BBP_set_window_modes(PI);
	write_rc(PI, &PI->snapWindow);
}

void set_alpha(struct plugin_info *PI, int alpha)
{
	PI->alpha = (BYTE)alpha;
	BBP_set_window_modes(PI);
	PI->alpha = eightScale_down(PI->alpha);
	write_rc(PI, &PI->alpha);
}

void set_transparent(struct plugin_info *PI, bool transparent)
{
	PI->transparent = transparent;
	BBP_reconfigure(PI);
	write_rc(PI, &PI->transparent);
}

void BBP_exit_moving(struct plugin_info *PI)
{
	if (false == PI->inSlit && PI->is_moving)
	{
		RECT r; GetWindowRect(PI->hwnd, &r);
		PI->xpos = r.left;
		PI->ypos = r.top;
		PI->width = r.right - r.left;
		PI->height = r.bottom - r.top;
		PI->place = get_place(PI);
		write_rc(PI, &PI->xpos);
	}
	PI->is_moving = false;
	PI->is_sizing = false;
}

void BBP_set_place(struct plugin_info *PI, int n)
{
	PI->place = n;
	BBP_set_window_modes(PI);
	write_rc(PI, &PI->xpos);
}

void BBP_set_size(struct plugin_info *PI, int w, int h)
{
	if (PI->width != w || PI->height != h)
	{
		PI->width = w, PI->height = h;
		BBP_set_window_modes(PI);
	}
}

//===========================================================================
// autohide

bool check_mouse(HWND hwnd)
{
    POINT pt;
    RECT rct;
    if (GetCapture() == hwnd)
        return 1;
    GetCursorPos(&pt);
    GetWindowRect(hwnd, &rct);
    if (PtInRect(&rct, pt))
        return 1;
    return 0;
}

void set_autohide_timer(plugin_info *PI, bool set)
{
    if (set)
        SetTimer(PI->hwnd, AUTOHIDE_TIMER, 100, NULL);
    else
        KillTimer(PI->hwnd, AUTOHIDE_TIMER);
}

void BBP_set_autoHide(struct plugin_info *PI, bool set)
{
	if (set != PI->autoHide)
	{
		PI->autoHide = set;
		write_rc(PI, &PI->autoHide);
	}

    PI->suspend_autohide = false;
    PI->auto_shown = set && check_mouse(PI->hwnd);
    if (PI->auto_shown)
        set_autohide_timer(PI, true);
    BBP_set_window_modes(PI);
}

//===========================================================================

int BBP_handle_broam(struct plugin_info *PI, const char *temp)
{

	if (!stricmp(temp, "useSlit"))
	{
		set_useSlit(PI, false == PI->useSlit);
		return 1;
	}

	if (!stricmp(temp, "pluginToggle"))
	{
		set_pluginToggle(PI, false == PI->pluginToggle);
		return 1;
	}

	if (!stricmp(temp, "onTop"))
	{
		set_alwaysOnTop(PI, false == PI->alwaysOnTop);
		return 1;
	}

	if (!stricmp(temp, "clickRaise"))
	{
		PI->clickRaise = false == PI->clickRaise;
		write_rc(PI, &PI->clickRaise);
		return 1;
	}

	if (!memicmp(temp, "snapWindow ", 11))
	{
		set_snapWindow(PI, atoi(temp + 11));
		return 1;
	}

	if (!memicmp(temp, "alphaValue ", 11))
	{
		set_alpha(PI, eightScale_up(atoi(temp + 11)));
		return 1;
	}

	if (!stricmp(temp, "transparent"))
	{
		set_transparent(PI, false == PI->transparent);
		return 1;
	}

	if (!memicmp(temp, "icon.saturation ", 16))
	{
		PI->saturation = atoi(temp + 16);
		write_rc(PI, &PI->saturation);
		return 1;
	}

	if (!memicmp(temp, "icon.hue ", 9))
	{
		PI->hue = atoi(temp + 9);
		write_rc(PI, &PI->hue);
		return 1;
	}

	if (!memicmp(temp, "Placement.", 10))
	{
		int n = get_string_index(temp + 10, placement_strings);
		if (-1 != n)
		{
			BBP_set_place(PI, n);
		}
		return 1;
	}

	if (!stricmp(temp, "fullScreen"))
	{
		PI->fullScreen = false == PI->fullScreen;
		UpdateMonitorInfo(PI);
		get_place(PI);
		set_place(PI);
		BBP_reconfigure(PI);
		write_rc(PI, &PI->fullScreen);
		return 1;
	}

	if (!stricmp(temp, "AutoHide"))
	{
		BBP_set_autoHide(PI, false == PI->autoHide);
		return 1;
	}

	if (!stricmp(temp, "EditRC"))
	{
		char szTemp[MAX_PATH];
		GetBlackboxEditor(szTemp);
		BBExecute(NULL, NULL, szTemp, PI->rcpath, NULL, SW_SHOWNORMAL, false);
	}

	if (!stricmp(temp, "LoadDocs"))
	{
		char docspath[MAX_PATH];				
		locate_file(PI->hInstance, docspath, PI->class_name, (char *)"html");
		BBExecute(NULL, "open", docspath, NULL, NULL, SW_SHOWNORMAL, false);
	}

	static const char Orientation_id[] = "Orientation.";
	if (!memicmp(temp, Orientation_id, sizeof Orientation_id - 1))
	{
		temp += sizeof Orientation_id - 1;
		if (!stricmp(temp, "vertical"))
			PI->orient_vertical = true;
		else
		if (!stricmp(temp, "horizontal"))
			PI->orient_vertical = false;
		else
			PI->orient_vertical = false == PI->orient_vertical;

		write_rc(PI, &PI->orient_vertical);
		set_place(PI);
		return 2;
	}
	return 0;
}

void BBP_set_visible(plugin_info *PI, bool visible)
{
    if (PI->visible != visible)
    {
        PI->visible = visible;
        BBP_set_window_modes(PI);
    }
}

void BBP_reconfigure(struct plugin_info *PI)
{
	if (false == PI->inSlit)
		UpdateMonitorInfo(PI);

	InvalidateRect(PI->hwnd, NULL, FALSE);
	BBP_set_window_modes(PI);
}

bool BBP_broam_bool(struct plugin_info *PI, const char *temp, const char *key, bool *ip)
{
    int n = strlen(key);
    const char *s;
    if (memicmp(temp, key, n))
        return false;
    s = temp + n;
    while (' ' == *s) ++s;
    if (0 == *s || 0 == stricmp(s, "toggle"))
        *ip = false == *ip;
    else
    if (0 == stricmp(s, "false"))
        *ip = false;
    else
    if (0 == stricmp(s, "true"))
        *ip = true;
    else
        return false;
    if (PI) BBP_write_bool(PI, key, *ip);
    return true;
}

bool BBP_broam_string(struct plugin_info *PI, const char *temp, const char *key, const char **ps)
{
    int n = strlen(key);
    const char *s;
    if (memicmp(temp, key, n))
        return false;
    s = temp + n;
    if (' ' != *s)
        return false;
    while (' ' == *s)
        ++s;
    if (0 == *s)
        return false;
    *ps = s;
    if (PI) BBP_write_string(PI, key, s);
    return true;
}

bool BBP_broam_int(struct plugin_info *PI, const char *temp, const char *key, int *ip)
{
    int n = strlen(key);
    const char *s;
    if (memicmp(temp, key, n))
        return false;
    s = temp + n;
    if (' ' != *s)
        return false;
    while (' ' == *s)
        ++s;
    if (0 == *s)
        return false;
    *ip = atoi(s);
    if (PI) BBP_write_int(PI, key, *ip);
    return true;
}

//===========================================================================
struct _menuitem;
struct n_menu;

enum _menuitem_modes
{
	i_nop = 1,
	i_sub ,
	i_cmd ,
	i_bol ,
	i_int ,
	i_str
};

struct n_menu
{
	char *title;
	_menuitem *items;
	_menuitem **pitems;
	_menuitem *lastitem;

	const char *id_string;
	char **broam_key;
	bool popup;

	n_menu(const char *_title)
	{
		title = new_str(_title);
		items = lastitem = NULL;
		pitems = &items;
	}

	~n_menu()
	{
		free_str(&title);
		delitems();
	}

	void additem(_menuitem *mi);
	void delitems(void);
	const char *addid(const char *cmd);
	Menu *convert(char **broam_key, const char *id_string, bool popup);
};

//-----------------------------------------------------
struct _menuitem
{
	_menuitem *next;
	n_menu *menu;
	char *text;
	int mode;
	bool disabled;

	_menuitem(n_menu *m, const char *_text, int _mode)
	{
		mode = _mode;
		text = new_str(_text);
		next = NULL;
		disabled = false;
		m->additem(this);
	}

	virtual ~_menuitem()
	{
		free_str(&text);
	}

	virtual MenuItem* _make_item(Menu *pMenu)
	{
		return NULL;
	}

};

//-----------------------------------------------------
struct _menuitemnop : _menuitem
{
	_menuitemnop(n_menu *m, const char *_text)
	: _menuitem(m, _text, i_nop)
	{
	}
	MenuItem* _make_item(Menu *pMenu)
	{
		return MakeMenuNOP(pMenu, text);
	}
};

//-----------------------------------------------------
struct _menuitemsub : _menuitem
{
	struct n_menu *sub;
	_menuitemsub(n_menu *m, const char *_text, n_menu* _sub)
	: _menuitem(m, _text, i_sub)
	{
		sub = _sub;
	}

	~_menuitemsub()
	{
		delete sub;
	}

	MenuItem* _make_item(Menu *pMenu)
	{
		char buffer[200];
		sprintf(buffer, "%s:%s", menu->id_string, sub->title);
		Menu *s = sub->convert(menu->broam_key, buffer, menu->popup);
		return MakeSubmenu(pMenu, s, text);
	}
};

//-----------------------------------------------------
struct _menuitemcmd : _menuitem
{
	char *cmd;
	_menuitemcmd(n_menu *m, const char *_text, const char *_cmd)
	: _menuitem(m, _text, i_cmd)
	{
		cmd = new_str(_cmd);
	}
	~_menuitemcmd()
	{
		free_str(&cmd);
	}

	MenuItem* _make_item(Menu *pMenu)
	{
		return MakeMenuItem(pMenu, text, menu->addid(cmd), false);
	}
};

//-----------------------------------------------------
struct _menuitembol : _menuitemcmd
{
	bool checked;
	_menuitembol(n_menu *m, const char *_text, const char *_cmd, bool _checked)
	: _menuitemcmd(m, _text, _cmd)
	{
		checked = _checked;
		mode = i_bol;
	}
	MenuItem* _make_item(Menu *pMenu)
	{
		return MakeMenuItem(pMenu, text, menu->addid(cmd), checked);
	}
};

//-----------------------------------------------------
struct _menuitemstr : _menuitem
{
	char *cmd;
	char *init;
	_menuitemstr(n_menu *m, const char *_text, const char *_cmd, const char *_init)
	: _menuitem(m, _text, i_str)
	{
		cmd = new_str(_cmd);
		init = new_str(_init);
	}
	~_menuitemstr()
	{
		free_str(&cmd);
		free_str(&init);
	}
	MenuItem* _make_item(Menu *pMenu)
	{
		return MakeMenuItemString(pMenu, text, menu->addid(cmd), init);
	}
};

//-----------------------------------------------------
struct _menuitemint : _menuitem
{
	char *cmd;
	int initval;
	int minval;
	int maxval;
	_menuitemint(n_menu *m, const char *_text, const char *_cmd, int _initval, int _minval, int _maxval)
	: _menuitem(m, _text, i_int)
	{
		cmd = new_str(_cmd);
		initval = _initval;
		minval = _minval;
		maxval = _maxval;
	}
	~_menuitemint()
	{
		free_str(&cmd);
	}
	MenuItem* _make_item(Menu *pMenu)
	{
		if (BB4WIN) // bb4win
		{
			char buffer[20]; sprintf(buffer, "%d", initval);
			return MakeMenuItemString(pMenu, text, menu->addid(cmd), buffer);
		}
		else
		{
			return MakeMenuItemInt(pMenu, text, menu->addid(cmd), initval, minval, maxval);
		}
	}
};

//-----------------------------------------------------
void n_menu::additem(_menuitem *mi)
{
	*pitems = mi;
	pitems = &mi->next;
	mi->menu = this;
	lastitem = mi;
}

void n_menu::delitems(void)
{
	_menuitem *mi = items;
	while (mi)
	{
		_menuitem *n = mi->next;
		delete mi;
		mi = n;
	}
}

const char *n_menu::addid(const char *cmd)
{
	if ('@' == *cmd) return cmd;
	strcpy(this->broam_key[1], cmd);
	return this->broam_key[0];
}

Menu *n_menu::convert(char **broam_key, const char *_id_string, bool _popup)
{
	this->id_string = _id_string;
	this->popup = _popup;
	this->broam_key = broam_key;
	//dbg_printf("<%s>", id_string);
	Menu *pMenu = MakeNamedMenu(title, id_string, popup);
	_menuitem *mi = items; while (mi)
	{
		mi->_make_item(pMenu);
		/*if (mi->disabled) DisableLastItem(pMenu);*/
		mi = mi->next;
	}
	return pMenu;
}

//-----------------------------------------------------
n_menu *n_makemenu(const char *title)
{
	return new n_menu(title);
}

n_menu *n_submenu(n_menu *m, const char *text)
{
	n_menu *s = n_makemenu(text);
	new _menuitemsub(m, text, s);
	return s;
}

void n_menuitem_nop(n_menu *m, const char *text)
{
	new _menuitemnop(m, text);
}

void n_menuitem_cmd(n_menu *m, const char *text, const char *cmd)
{
	new _menuitemcmd(m, text, cmd);
}

void n_menuitem_bol(n_menu *m, const char *text, const char *cmd, bool check)
{
	new _menuitembol(m, text, cmd, check);
}

void n_menuitem_int(n_menu *m, const char *text, const char *cmd, int val, int vmin, int vmax)
{
	new _menuitemint(m, text, cmd, val, vmin, vmax);
}

void n_menuitem_str(n_menu *m, const char *text, const char *cmd, const char *init)
{
	new _menuitemstr(m, text, cmd, init);
}

void n_disable_lastitem(n_menu *m)
{
	if (m->lastitem) m->lastitem->disabled = true;
}

//===========================================================================

//===========================================================================

void n_showmenu(n_menu *m, const char *broam_key, bool popup)
{
	char broam[200];
	int x = sprintf(broam, "@%s.", broam_key);
	char *b[2] = { broam, broam+x };

	Menu *pMenu = m->convert(b, broam_key, popup);
	delete m;
	ShowMenu(pMenu);
}

//===========================================================================

//===========================================================================

void BBP_n_placementmenu(struct plugin_info *PI, n_menu *m)
{
	n_menu *P = n_submenu(m, "Placement");
	int n = 1, o = PI->is_bar ? POS_TopRight : POS_Center;
	for (; n <= o; n++)
	{
		if (POS_TopLeft == n || POS_CenterLeft == n)
		{
			n_menuitem_nop(P, NULL);
			if (PI->is_bar && POS_CenterLeft == n) 
				n = n + 1;
		}
		if (POS_AutoHide == n)
		{
			n_menuitem_bol(P, menu_placement_strings[n], "autoHide", PI->autoHide);
			if (PI->is_bar) 
				n = n + 1;
		}
		else
		{
			char b2[80];
			sprintf(b2, "Placement.%s", placement_strings[n]);
			n_menuitem_bol(P, menu_placement_strings[n], b2, PI->place == n);
		}
	}

	if (PI->monitorCount > 1)
	{
		n_menuitem_nop(P, NULL);
		n_menuitem_bol(P, "Use Full Screen", "fullScreen", PI->fullScreen);
	}
}

void BBP_n_orientmenu(struct plugin_info *PI, n_menu *m)
{
    n_menu *o = n_submenu(m, "Orientation");
    n_menuitem_bol(o, "Vertical", "Orientation. vertical",  false != PI->orient_vertical);
    n_menuitem_bol(o, "Horizontal", "Orientation. horizontal",  false == PI->orient_vertical);
}

void BBP_n_insertmenu(struct plugin_info *PI, n_menu *m)
{
	if (PI->hSlit)
	{
		n_menuitem_bol(m, "Use Slit", "useSlit", PI->useSlit);
		n_menuitem_nop(m, NULL);
	}

	if (false == PI->no_icons)
	{
		n_menuitem_int(m, "Icon Saturation", "icon.saturation",  eightScale_down(PI->saturation), 0, 8);
		n_menuitem_int(m, "Icon Hue", "icon.hue",  eightScale_down(PI->hue), 0, 8);
	}
}

void BBP_n_windowmenu(struct plugin_info *PI, n_menu *m)
{
	n_menu *R = n_submenu(m, "Window");

	n_menuitem_bol(R, "Always On Top", "onTop",  PI->alwaysOnTop);
	if (false == PI->alwaysOnTop)
		n_menuitem_bol(R, "Click Raise", "clickRaise", PI->clickRaise);
	n_menuitem_bol(R, "Toggle With Plugins", "pluginToggle",  PI->pluginToggle);
	n_menuitem_nop(R, NULL);
	n_menuitem_int(R, "Snap To Edge", "snapToEdge",  PI->snapWindow, 0, 50);
	if (PI->usingWin2kPlus)
	{
		n_menuitem_int(R, "Alpha Value", "alphaValue",  eightScale_down(PI->alpha), 0, 8);
		n_menuitem_bol(R, "Transparent Background", "transparent",  PI->transparent);
	}
}

//===========================================================================

//===========================================================================
/*
	// handled messages

	WM_NCCREATE:
	BB_BROADCAST:

	WM_ENTERSIZEMOVE:
	WM_EXITSIZEMOVE:
	WM_WINDOWPOSCHANGING:

	BB_AUTORAISE:
	WM_MOUSEMOVE:
	WM_NCLBUTTONDOWN:
	WM_NCHITTEST:

	WM_TIMER:   // handle autohide
	WM_CLOSE:   // return 0;
*/

//===========================================================================

LRESULT CALLBACK BBP_WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	static UINT msgs[] = { BB_RECONFIGURE, BB_BROADCAST, BB_DESKCLICK, 0};

	LRESULT Result = 0;
	struct plugin_info *PI  = (struct plugin_info *)GetWindowLong(hwnd, 0);

	//dbg_printf("message %x", message);

	if (NULL == PI)
	{
		if (WM_NCCREATE == message)
		{
			// bind the window to the structure
			PI = (plugin_info *)((CREATESTRUCT*)lParam)->lpCreateParams;
			PI->hwnd = hwnd;
			SetWindowLong(hwnd, 0, (LONG)PI);
		}
		return DefWindowProc(hwnd, message, wParam, lParam);
	}

	switch (message)
	{
		case WM_CREATE:
			SendMessage(GetBBWnd(), BB_REGISTERMESSAGE, (WPARAM)hwnd, (LPARAM)msgs);
			MakeSticky(hwnd);
			goto pass_nothing;

		case WM_DESTROY:
			SendMessage(GetBBWnd(), BB_UNREGISTERMESSAGE, (WPARAM)hwnd, (LPARAM)msgs);
			RemoveSticky(hwnd);
			goto pass_nothing;

		// ==========
		case BB_BROADCAST:
		{
			if (!stricmp((LPCSTR)lParam, "@BBShowPlugins"))
			{
                PI->toggled_hidden = false;
                BBP_set_window_modes(PI);
				goto pass_result;
			}

			if (!stricmp((LPCSTR)lParam, "@BBHidePlugins"))
			{
                if (PI->pluginToggle) {
                    PI->toggled_hidden = true;
                    BBP_set_window_modes(PI);
                }
				goto pass_result;
			}

			const char *temp = (LPCSTR)lParam;
			if ('@' == *temp
				&& 0 == memicmp(++temp, PI->broam_key, PI->broam_key_len)
				&& '.' == temp[PI->broam_key_len]
				)
			{
				temp += PI->broam_key_len+1;
				PI->process_broam(temp, BBP_handle_broam(PI, temp));
				goto pass_result;
			}

			goto pass_nothing;
		}

		// ==========

		case BB_DESKCLICK:
			if (lParam == 0
			 && PI->clickRaise
			 && false == PI->alwaysOnTop
			 && false == PI->inSlit)
				SetWindowPos(hwnd, HWND_TOP, 0,0,0,0, SWP_NOACTIVATE|SWP_NOMOVE|SWP_NOSIZE);
			goto pass_result;

		// ==========
		// snap to edge if onScreen
		case WM_WINDOWPOSCHANGING:
			if (PI->is_moving
			 && false == PI->inSlit
			 && 0 == (0x8000 & GetAsyncKeyState(VK_SHIFT)))
				SnapWindowToEdge((WINDOWPOS*)lParam, PI->snapWindow, true);
			goto pass_result;

		// snap to edge if offScreen
		case WM_WINDOWPOSCHANGED:
			SnapWindowToEdge((WINDOWPOS*)lParam, PI->snapWindow, true);
			goto pass_result;

		case WM_ENTERSIZEMOVE:
			PI->is_moving = true;
			goto pass_result;

		case WM_EXITSIZEMOVE:
			BBP_exit_moving(PI);
			BBP_set_autoHide(PI, PI->autoHide);
			if (false == PI->auto_hidden)
				PI->pos_changed();
			PI->show_menu(false);
			if (PI->inSlit) SendMessage(PI->hSlit, SLIT_UPDATE, 0, (LPARAM)PI->hwnd);
			goto pass_result;

		// ==========
		case WM_LBUTTONDOWN:
			if (false == PI->inSlit && (MK_CONTROL & wParam))
			{
				// start moving, when control-key is held down
				SetActiveWindow(hwnd);
				UpdateWindow(hwnd);
				PostMessage(hwnd, WM_SYSCOMMAND, 0xf012, 0);
				goto pass_result;
			}
			goto pass_nothing;

		case WM_KEYUP:
			{
				if (wParam == VK_NUMPAD7) 
					BBP_set_place(PI, 7);
				else if (wParam == VK_NUMPAD8) 
					BBP_set_place(PI, 8);
				else if (wParam == VK_NUMPAD9) 
					BBP_set_place(PI, 9);
				else if (wParam == VK_NUMPAD1) 
					BBP_set_place(PI, 1);
				else if (wParam == VK_NUMPAD2) 
					BBP_set_place(PI, 2);
				else if (wParam == VK_NUMPAD3) 
					BBP_set_place(PI, 3);
				else if (wParam == VK_NUMPAD5)
					BBP_set_autoHide(PI, false == PI->autoHide);
				else if (wParam == VK_RETURN)
					BBP_set_place(PI, 10);
				else if (wParam == VK_SUBTRACT)
					BBP_handle_broam(PI, "EditRC");
				else if (wParam == VK_ADD)
					BBP_handle_broam(PI, "onTop");
				else if (false == PI->is_bar) 
				{
					if (wParam == VK_NUMPAD4) 
						BBP_set_place(PI, 4);
					else if (wParam == VK_NUMPAD6) 
						BBP_set_place(PI, 6);
					else if (wParam == VK_ESCAPE)	
						PI->orient_vertical = false == PI->orient_vertical;
				}
				BBP_reconfigure(PI);
			}
			goto pass_nothing;

		case WM_NCHITTEST:
			Result = HTCLIENT;
			if (PI->inSlit)
			{
				if (0x8000 & GetAsyncKeyState(VK_SHIFT))
					Result = HTTRANSPARENT;
			}
			goto pass_result;

		case WM_TIMER:
            if (AUTOHIDE_TIMER != wParam)
                goto pass_nothing;

            if (check_mouse(hwnd))
                goto pass_result;
#if 0
            {
                POINT pt;
                GetCursorPos(&pt);
                if (PI->hMon != MonitorFromPoint(*(POINT*)&PI->xpos, MONITOR_DEFAULTTONEAREST)
                    goto pass_result;
            }
#endif
            if (PI->mouse_over) {
                POINT pt;
                GetCursorPos(&pt);
                ScreenToClient(hwnd, &pt);
                PostMessage(hwnd, WM_MOUSELEAVE, 0, MAKELPARAM(pt.x, pt.y));
                PI->mouse_over = false;
            }

            if (PI->auto_shown) {
                if ((PI->suspend_autohide) && (NOT_XOBLITE))
                    goto pass_result;
                PI->auto_shown = false;
                BBP_set_window_modes(PI);
            }

            set_autohide_timer(PI, false);
            goto pass_result;

		case WM_MOUSEMOVE:
            if (false == PI->mouse_over)
            {
                PI->mouse_over = true;
                set_autohide_timer(PI, true);
            }

            if (PI->auto_hidden)
            {
                PI->auto_shown = true;
                BBP_set_window_modes(PI);
                goto pass_result;
            }

			goto pass_nothing;

		case WM_CLOSE:
			goto pass_result;

		case WM_ERASEBKGND:
			Result = TRUE;
			goto pass_result;

		default:
		pass_nothing:
			return PI->wnd_proc(hwnd, message, wParam, lParam, NULL);
	}
pass_result:
	return PI->wnd_proc(hwnd, message, wParam, lParam, &Result);
}

//===========================================================================

//===========================================================================
struct class_info
{
	struct class_info *next;
	char name[48];
	HINSTANCE hInstance;
	int refc;
};


ST struct class_info *CI;

ST struct class_info **find_class(const char *name)
{
	struct class_info **pp;
	for (pp = &CI; *pp; pp = &(*pp)->next)
		if (0 == stricmp((*pp)->name, name)) break;
	return pp;
}

ST int class_info_register(const char *class_name, HINSTANCE hInstance)
{
	struct class_info *p = *find_class(class_name);
	if (NULL == p)
	{
		WNDCLASS wc;
		ZeroMemory(&wc,sizeof(wc));

		wc.lpfnWndProc  = BBP_WndProc;  // our window procedure
		wc.hInstance    = hInstance;    // hInstance of .dll
		wc.lpszClassName = class_name;  // our window class name
		wc.style = CS_DBLCLKS | CS_VREDRAW | CS_HREDRAW;
		wc.hCursor = LoadCursor(NULL, IDC_ARROW);
		wc.cbWndExtra = sizeof (void*);

		if (FALSE == RegisterClass(&wc))
		{
			//dbg_printf("failed to register %s", wc.lpszClassName);
			return 0;
		}

		p = new struct class_info;
		p->next = CI;
		CI = p;
		p->refc = 0;
		strcpy(p->name, class_name);
		p->hInstance = hInstance;
		//dbg_printf("registered class <%s> %x", wc.lpszClassName, wc.hInstance);
	}

	p->refc ++;
	return 1;
}

ST void class_info_decref(const char *name)
{
	struct class_info *p, **pp = find_class(name);
	if (NULL != (p = *pp) && --p->refc <= 0)
	{
		UnregisterClass(p->name, p->hInstance);
		//dbg_printf("unregistered class <%s> %x", p->name, p->hInstance);
		*pp = p->next;
		delete p;
	}
}

int BBP_Init_Plugin(struct plugin_info *PI)
{
	if (NULL == CI)
		BBVersion = (char*)BBP_bbVersion();

	PI->broam_key_len = strlen(PI->broam_key);

	if (0 == class_info_register(PI->class_name, PI->hInstance))
		return 0;

	//dbg_printf("creating window <%s>", PI->class_name);
	PI->hwnd = CreateWindowEx(
		WS_EX_LAYERED | WS_EX_TOOLWINDOW,
		PI->class_name,
		NULL,
		WS_POPUP | WS_CLIPCHILDREN | WS_CLIPSIBLINGS,
		PI->xpos,
		PI->ypos,
		PI->width,
		PI->height,
		NULL,           // parent window
		NULL,           // no menu
		PI->hInstance,  // hInstance of .dll
		PI              // init_data
		);

	if (NULL == PI->hwnd)
	{
		class_info_decref(PI->class_name);
		return 0;
	}

	// Transparency is only supported under Windows 2000/XP...
	PI->usingWin2kPlus = GetOSVersion() >= 50;
	PI->has_alpha = *(BYTE *)GetSettingPtr(SN_MENUALPHA);
    PI->visible = true;

	BBP_set_window_modes(PI);
	return 1;
}

void BBP_Exit_Plugin(struct plugin_info *PI)
{
	//dbg_printf("window destroying <%s>", PI->class_name);
	if (PI->hwnd)
	{
		if (PI->inSlit) SendMessage(PI->hSlit, SLIT_REMOVE, 0, (LPARAM)PI->hwnd);
		DestroyWindow(PI->hwnd);
		class_info_decref(PI->class_name);
	}
}

static DWORD WINAPI QuitThread (void *pv)
{
    FreeLibraryAndExitThread((HMODULE)pv, 0);
#if _MSC_VER < 1400
    return 0; // never returns
#endif
}

int BBP_messagebox(
    plugin_info *PI,
    int flags,
    const char *fmt, ...)
{
    va_list args;
    char buffer[4000];
    DWORD threadId;
    HMODULE hLib;

    va_start(args, fmt);
    GetModuleFileName(PI->hInstance, buffer, sizeof buffer);
    hLib = LoadLibrary(buffer);
    vsprintf(buffer, fmt, args);
    flags = MessageBox(NULL, buffer, PI->class_name, flags|MB_TOPMOST|MB_SETFOREGROUND);
    CloseHandle(CreateThread(NULL, 0, QuitThread, hLib, 0, &threadId));

    return flags;
}

//===========================================================================
