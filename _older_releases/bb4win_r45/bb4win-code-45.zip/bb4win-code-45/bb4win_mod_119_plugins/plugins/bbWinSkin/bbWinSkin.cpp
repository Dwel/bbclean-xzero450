/*
 ============================================================================
 This file is part of the bbWinSkin source code.
 Copyright © 2003-2009 grischka (grischka@users.sourceforge.net)
 Copyright © 2003-2004|2006-2009 The Blackbox for Windows Development Team

 bbWinSkin is a plugin for Blackbox for Windows

 http://bb4win.sourceforge.net/ - http://bb4win.sourceforge.net/bblean/
 ============================================================================
 Partly based on ShellWM © 2002 ShellWM Development Team
 Partly based on CustomEyes © 1999-2001 Didier Abderrahmane
 ============================================================================

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  http://www.fsf.org/licenses/gpl.html

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

 ============================================================================
*/

#include "BBApi.h"
#include "engine\hookinfo.h"
#include "../bbPlugin/moreutils.cpp"

//#define TRANSPARENCY

// bbLean BBAPI.h proprietary defines (if not already defined)
#ifndef BB_REDRAWGUI
  #define BB_REDRAWGUI            10881

  #define BBRG_TOOLBAR (1<<0)
  #define BBRG_MENU    (1<<1)
  #define BBRG_WINDOW  (1<<2)
  #define BBRG_DESK    (1<<3)
  #define BBRG_FOCUS   (1<<4)
  #define BBRG_PRESSED (1<<5)
  #define BBRG_STICKY  (1<<6)
  #define BBRG_FOLDER  (1<<7)
  #define BBRG_SLIT    (1<<8)

  #define VALID_MARGIN        (1<<9)
#endif

//============================================================================
// info

const char szAppName     [] = "bbWinSkin";
const char szVersion     [] = "bbWinSkin 1.21";
const char szInfoVersion [] = "1.21";
const char szInfoAuthor  [] = "grischka|TheDevTeam";
const char szInfoRelDate [] = "2009-06-01";
const char szInfoLink    [] = "http://bb4win.sourceforge.net/";
const char szInfoEmail   [] = "irc://irc.freenode.net/bb4win";

void about_box(void)
{
    char buff[512];
    sprintf(buff, "%s \n\n© %s \n\n%s \n%s", szVersion, szInfoAuthor, szInfoLink, szInfoEmail);
    MessageBox(NULL, buff, szAppName, MB_OK|MB_TOPMOST|MB_SETFOREGROUND);
}

//============================================================================

	// blackbox and logwindow stuff
    HINSTANCE hInstance;
    HWND BBhwnd;
    static int BBVersion;
    static int bbLeanVersion;
    HWND m_hwnd;
    HWND hwndLog;
    bool is_plugin;
    bool enableLog;

	// settings
    bool adjustCaptionHeight;
    char rcpath[MAX_PATH];
	static int checkfont (char *face);

	// additional windows options
    char windows_menu_fontFace[120];
    int windows_menu_fontHeight;
    int ScrollbarSize;
    int MenuHeight;
    int iconSize;
    bool setTTColor;
    bool safeMetrics;
    bool fontShadows;
    bool shadowsQwilk;

	// skin info passed via shared mem
    UINT bbSkinMsg;
    SkinStruct mSkin;

	// for the shared memory
    HANDLE hMapObject;
    SkinStruct *lpvMem;

	// skinner dll
    bool engine_running;

	//====================

	// forward declaration

	BOOL CreateSharedMem(int size);
	void DestroySharedMem();

    void refreshStyle(void);

    void startEngine();
    void stopEngine();
    void reconfigureEngine(void);
    const char* engineInfo(int field);
    void setEngineOption(UINT id);

    void free_dll(void);
    bool load_dll(void);

	// parsing
	void ReadGradientItem(const char * style, GradientItem *gi, const char *rckey);
	void ReadFont(LPSTR styleFile);
	static int CALLBACK EnumFontFamProc(ENUMLOGFONT *lpelf, NEWTEXTMETRIC *lpntm, int FontType, LPARAM lParam);
    struct window_font
    {
        int  Height;
        int  Weight;
        int  Justify;   // DT_LEFT, DT_CENTER, DT_RIGHT
        char Face[128];

    } windowFont;

//============================================================================
// plugin interface

#ifndef INCLUDE_STYLEREADER
int beginPlugin(HINSTANCE hMainInstance)
{
    if (is_plugin || engine_running)
    {
       MessageBox(NULL, "Dont load me twice!", szAppName, MB_OK|MB_TOPMOST|MB_SETFOREGROUND);
       return 1;
    }
    is_plugin = true;
    startEngine();
    return 0;
}

//====================

void endPlugin(HINSTANCE hMainInstance)
{
    stopEngine();
    is_plugin = false;
}

//====================

LPCSTR pluginInfo(int field)
{
	switch (field)
	{
		case PLUGIN_NAME:
			return szAppName;
		case PLUGIN_VERSION:
			return szInfoVersion;
		case PLUGIN_AUTHOR:
			return szInfoAuthor;
		case PLUGIN_RELEASEDATE:
			return szInfoRelDate;
		case PLUGIN_LINK:
			return szInfoLink;
		case PLUGIN_EMAIL:
			return szInfoEmail;
		case PLUGIN_BROAMS:
		{
			return
			"@bbWinSkin.About"
			"@bbWinSkin.toggleOverride"
			"@bbWinSkin.toggleShadows"
			"@bbWinSkin.toggleLog"
			"@bbWinSkin.toggleSkin";
		}

		//====================

		default:
			return szVersion;
	}
}
#endif

//====================

LPCSTR engineInfo(int field)
{
    return pluginInfo(field);
}

//============================================================================
// shared mem

BOOL CreateSharedMem(int size)
{
    // handle to file mapping
    hMapObject = CreateFileMapping(
        (HANDLE)DWORD_PTR(0xFFFFFFFF),     // use paging file
        NULL,                   // no security attributes
        PAGE_READWRITE,         // read/write access
        0,                      // size: high 32-bits
        size,                   // size: low 32-bits
        BBWINSKIN_SHMEMID      // name of map object
        );

    if (hMapObject && GetLastError() != ERROR_ALREADY_EXISTS)
    {
        // Get a pointer to the file-mapped shared memory.
        lpvMem = (SkinStruct *)MapViewOfFile(
            hMapObject,     // object to map view of
            FILE_MAP_WRITE, // read/write access
            0,              // high offset:  map from
            0,              // low offset:   beginning
            0);             // default: map entire file
        if (lpvMem)
        {
            ZeroMemory(lpvMem, size);
            return TRUE;
        }
    }
    DestroySharedMem();
    return FALSE;
}

//====================

void DestroySharedMem()
{
    if (hMapObject)
    {
        if (lpvMem)
        {
            // Unmap shared memory from the process's address space.
            UnmapViewOfFile(lpvMem);
            lpvMem = NULL;
        }
        // Close the process's handle to the file-mapping object.
        CloseHandle(hMapObject);
        hMapObject = NULL;
    }
}

//============================================================================
// exclusion chaos, just assume it works...
// reads in the exclusions.rc, and puts it into the global shared mem, which
// is created here also, because it's size depends on the exclusion strings.

bool make_exclusion_list(void)
{
    struct elist
    {
        struct elist *next;
        int flen;
        int option;
        char buff[1];
    } *p0 = NULL, **pp = &p0, *p;

    int t_len   = 0;
    int t_count = 0;
    char exclusionspath[MAX_PATH];

    // first read all strings into a list and calculate the size...
    FILE *fp = FileOpen(set_my_path(hInstance, exclusionspath, "exclusions.rc"));
    if (fp) for (;;)
    {
        char *line, line_buffer[256];
        if (false == ReadNextCommand(fp, line_buffer, sizeof line_buffer))
        {
            FileClose(fp);
            break;
        }
        strlwr(line = line_buffer);
        int option = 0;
        if (0 == memicmp (line, "hook-early:", 11))
        {
            option = 1; line += 10; while (' ' == *++line);
        }

        int line_len = strlen(line);

        char *cp = strchr(line, ':');
        if (cp) *cp++ = 0;
        else *(cp = line + line_len++) = 0;
        p = (struct elist *)malloc(line_len + sizeof(struct elist));
        memcpy(p->buff, line, ++line_len);
        p->flen = cp - line;
        p->option = option;
        *(pp = &(*pp = p)->next) = NULL;
        t_len += line_len-2;
        t_count++;
    }

    t_len += sizeof(struct exclusion_info) + (t_count-1) * sizeof(struct exclusion_item);

    // ... then create the shared mem, which is supposed to succeed,...
    if (FALSE == CreateSharedMem(offset_exInfo + t_len))
        return false;

    // ... and finally copy the list into it, free items by the way.
    struct exclusion_info *pExclInfo = &lpvMem->exInfo;
    pExclInfo->size = t_len;
    pExclInfo->count = t_count;
    struct exclusion_item *ei = pExclInfo->ei;
    while (p0)
    {
        p = p0; p0 = p0->next; char *cp = ei->buff;
        ei->flen = 1+strlen(strcpy(cp, p->buff));
        ei->clen = 1+strlen(strcpy(cp+ei->flen, p->buff+p->flen));
        ei->option = p->option;
        free(p);
        ei = (struct exclusion_item *)(ei->buff + ei->flen + ei->clen);
    }
    return true;
}

//====================

void free_exclusion_list(void)
{
    DestroySharedMem();
}

//===========================================================================
// edit control, readonly
void make_log_window(void)
{
    RECT r;
	GetClientRect(m_hwnd, &r);

	hwndLog = CreateWindow(
        "EDIT", NULL,
        WS_CHILD
        | WS_HSCROLL
        | WS_VSCROLL
        | WS_VISIBLE
        | ES_MULTILINE
        | ES_READONLY
        | ES_AUTOHSCROLL
        | ES_AUTOVSCROLL
        ,
        0, 0, r.right, r.bottom,
        m_hwnd,
        NULL,
        hInstance,
        NULL
        );

    SendMessage(hwndLog, WM_SETFONT, (WPARAM)GetStockObject(ANSI_FIXED_FONT), 0);
    ShowWindow(m_hwnd, SW_SHOW);
}

//====================

void delete_log_window(void)
{
    ShowWindow(m_hwnd, SW_HIDE);
    DestroyWindow(hwndLog);
    hwndLog = NULL;
}

//====================

void set_log_window(void)
{
    if (enableLog && NULL == hwndLog)
        make_log_window();

    if (false == enableLog && hwndLog)
        delete_log_window();
}

//====================

void write_log(const char *s)
{
    char buffer[4096];
    sprintf(buffer, "%s\r\n", s);
    int l1 = GetWindowTextLength(hwndLog);
    SendMessage(hwndLog, EM_SETSEL, l1, l1);
    SendMessage(hwndLog, EM_REPLACESEL, false, (LPARAM)buffer);
}

//============================================================================
// the log window, usually hidden, but when shown it contains the edit control

LRESULT CALLBACK WndProc (HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    static UINT msgs[] = {BB_RECONFIGURE, BB_REDRAWGUI, BB_BROADCAST, 0};

    switch (message)
    {

    default:
        return DefWindowProc (hwnd, message, wParam, lParam);

    case WM_CREATE:
        m_hwnd = hwnd;
        SendMessage(BBhwnd, BB_REGISTERMESSAGE, (WPARAM)hwnd, (LPARAM)msgs);
        break;

    case WM_DESTROY:
        SendMessage(BBhwnd, BB_UNREGISTERMESSAGE, (WPARAM)hwnd, (LPARAM)msgs);
        break;

    case BB_BROADCAST:
        if (0 == memicmp((LPCSTR)lParam, "@bbWinSkin.", 11))
        {
            const char *msg = (LPCSTR)lParam + 11;
            if (0 == stricmp(msg, "About"))
                about_box();
            else
            if (0 == stricmp(msg, "toggleLog"))
                goto toggle_log;
            else
            if (0 == stricmp(msg, "toggleSkin"))
            {
                if (engine_running)
                {
                    write_log("\r\n\t---- stopping engine ----\r\n");
                    PostMessage(hwnd, bbSkinMsg, MSGID_UNLOAD, 0);
                    PostMessage(hwnd, BB_QUIT, 0, 0);
                }
                else
                {
                    write_log("\r\n\t---- starting engine ----\r\n");
                    startEngine();
                }
            }
        }
        break;

    case BB_QUIT:
        stopEngine();
        break;

    case BB_RECONFIGURE:
        if (is_plugin) // i.e. not loaded by BBWinSkin
            reconfigureEngine();
        break;

    toggle_log:
        WriteBool(rcpath, "bbWinSkin.option.enableLog:", false == enableLog);
        reconfigureEngine();
        break;

	//====================
    // used in combination with bbstylemaker to update the skin info
    // and optionally force active or button pressed state.

    case BB_REDRAWGUI:
        if (BBRG_WINDOW & wParam)
        {
            if (wParam & BBRG_STICKY)
            {   // and to transfer the is_sticky info from bb.
                PostMessage((HWND)lParam, bbSkinMsg, MSGID_BB_SETSTICKY, 0 != (wParam & BBRG_FOCUS));
                break;
            }

            static bool prev_opt;
            int opt = 0;
            if (prev_opt)               opt = MSGID_BBSM_RESET;
            if (wParam & BBRG_FOCUS)    opt = MSGID_BBSM_SETACTIVE;
            if (wParam & BBRG_PRESSED)  opt = MSGID_BBSM_SETPRESSED;
            prev_opt = opt >= MSGID_BBSM_SETACTIVE;

            if (opt) setEngineOption(opt);
            refreshStyle();
        }
        break;

	//====================
    // Log string sent by the engine dll

    case WM_COPYDATA:
    {
        if (201 == ((PCOPYDATASTRUCT)lParam)->dwData)
        {
            write_log((char*)((COPYDATASTRUCT*)lParam)->lpData);
            return TRUE;
        }
        break;
    }

	//====================
    // things for the Log EDIT control

    case WM_SETFOCUS:
        if (hwndLog) SetFocus(hwndLog);
        break;

    case WM_SIZE:
        if (hwndLog) MoveWindow(hwndLog, 0, 0, LOWORD(lParam), HIWORD(lParam), TRUE);
        break;

    case WM_CLOSE:
        if (hwndLog) goto toggle_log;
        break;
    }
    return 0 ;
}

//============================================================================

extern "C" BOOL WINAPI DllMain(HINSTANCE hi, DWORD reason, LPVOID reserved)
{
    if (reason==DLL_PROCESS_ATTACH)
    {
        hInstance = hi; WNDCLASS wc; RECT dt;
    int a, b, c;

        if (BBhwnd)
        {
            MessageBox(BBhwnd, "Dont load me twice!", szAppName, MB_OK|MB_SETFOREGROUND);
            return FALSE;
        }

		// Testing for is only ever done for non-bbLean shells
        const char *bbv = GetBBVersion();
        if (0 == memicmp(bbv, "bblean", 6)) BBVersion = 2;
        else
        if (0 == memicmp(bbv, "bb", 2)) BBVersion = 1;
        else BBVersion = 0;

		/*c = 0;
		bbLeanVersion = sscanf(bbv, "bbLean %d.%d.%d", &a, &b, &c) >= 2 ? 
			a*1000+b*10+c : 0;*/

        BBhwnd = GetBBWnd();
        set_my_path(hInstance, rcpath, "bbWinSkin.rc");

        ZeroMemory(&wc, sizeof(wc));
        wc.lpszClassName = szAppName;
        wc.hInstance = hInstance;
        wc.lpfnWndProc = WndProc;

        if (FindWindow(wc.lpszClassName, NULL) || FALSE == RegisterClass(&wc))
            return FALSE;

        // center the window
        SystemParametersInfo(SPI_GETWORKAREA, 0, &dt, 0);
        int width = 480;
        int height = 300;
        int xleft = (dt.left+dt.right-width)/2;
        int ytop = (dt.top+dt.bottom-height)/2;

        CreateWindow(
            wc.lpszClassName,
            "bbWinSkin Log",
            //WS_OVERLAPPEDWINDOW,
            WS_POPUP|WS_CAPTION|WS_SIZEBOX|WS_SYSMENU|WS_MAXIMIZEBOX|WS_MINIMIZEBOX,
            xleft, ytop, width, height,
            NULL,
            NULL,
            wc.hInstance,
            NULL
            );
    }
    else
    if (reason==DLL_PROCESS_DETACH)
    {
        stopEngine();
        DestroyWindow(m_hwnd);
        UnregisterClass(szAppName, hInstance);
    }
    return TRUE;
}

//===========================================================================

void read_buttons(void)
{
    char path[MAX_PATH];
    HBITMAP hbmp = (HBITMAP)LoadImage(
        NULL, set_my_path(hInstance, path, "buttons.bmp"),
        IMAGE_BITMAP,
        0,
        0,
        LR_LOADFROMFILE// | LR_CREATEDIBSECTION
        );

    if (NULL == hbmp)
    {
        static unsigned char default_buttons[6*2][BUTTON_MAP_SIZE] = {
        { 0x00, 0x8C, 0xB9, 0xE3, 0x83, 0x83, 0x8F, 0x3B, 0x63, 0x00, 0x00 },
        { 0x00, 0x8C, 0xB9, 0xE3, 0x83, 0x83, 0x8F, 0x3B, 0x63, 0x00, 0x00 },
        { 0x00, 0xFC, 0xF9, 0x13, 0x24, 0x48, 0x90, 0x20, 0x7F, 0x00, 0x00 },
        { 0xF8, 0xF1, 0x23, 0xFC, 0xF9, 0x33, 0x7C, 0x88, 0x10, 0x3F, 0x00 },
        { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x80, 0x3F, 0x7F, 0x00, 0x00 },
        { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x80, 0x3F, 0x7F, 0x00, 0x00 },
        { 0x00, 0x1C, 0x38, 0x70, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 },
        { 0x00, 0x1C, 0x38, 0x70, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 },
        { 0x00, 0x20, 0xE0, 0xE0, 0xE3, 0x0F, 0x07, 0x0E, 0x1C, 0x00, 0x00 },
        { 0x00, 0x70, 0xE0, 0xC0, 0xE1, 0x8F, 0x0F, 0x0E, 0x08, 0x00, 0x00 },
        { 0x00, 0x0C, 0x18, 0x30, 0xE0, 0xC7, 0x80, 0x01, 0x03, 0x00, 0x00 },
        { 0x00, 0xFC, 0xF9, 0xF3, 0x07, 0x01, 0x02, 0x04, 0x08, 0x00, 0x00 },
        };
        memcpy(&mSkin.button_bmp, default_buttons, sizeof default_buttons);
        return;
    }

    HDC hdc = CreateCompatibleDC(NULL);
    HGDIOBJ other = SelectObject(hdc, hbmp);
    struct button_bmp *bp = mSkin.button_bmp;
    int b, state, y, x, n;
    for (b = 0; b < 6; ++b, ++bp)
        for (state = 0; state < 2; ++state)
        {
            for (n = y = 0; y < BUTTON_SIZE; ++y)
                for (x = 0; x < BUTTON_SIZE; ++x, ++n)
                {
                    COLORREF c = GetPixel(hdc, b*(1+BUTTON_SIZE)+1+x, state*(1+BUTTON_SIZE)+1+y);
                    if (0 == c) bp->data[state][n/8] |= 1 << n%8;
                }
#if 0
            unsigned char *u = (unsigned char*)bp->data[state];
            dbg_printf("       { "
                "0x%02X, 0x%02X, 0x%02X, 0x%02X, 0x%02X, 0x%02X, 0x%02X, 0x%02X, 0x%02X, 0x%02X, 0x%02X },",
                u[0], u[1], u[2], u[3], u[4], u[5], u[6], u[7], u[8], u[9], u[10]);
#endif
        }
    DeleteObject(SelectObject(hdc, other));
    DeleteDC(hdc);
}

//===========================================================================
// get settings
void readSettings(void)
{
    int i;

    ZeroMemory(&mSkin, offset_hooks);

	//====================
    // titlebar click actions
    for (i = 0; i < 12; i++)
    {
        static const char *modifiers[] = { "", "Shift", "Ctrl" };
        static const char *buttons[]  = { "Dbl", "Right", "Mid", "Left" };
        static const char *button_ids[] = {
            /* same order as subclass.h: enum button_types */
            "Close", "Maximize", "Minimize",
            "Rollup", "AlwaysOnTop", "Pin",
            "Icon", "MaxHeight", "MaxWidth",
            "MinimizeToTray", "Lower",
            "MoveRight", "MoveLeft", NULL
        };

        char rcstring[80];
        sprintf(rcstring, "bbWinSkin.titlebar.%s%sClick:", modifiers[i%3], buttons[i/3]);
        const char *p = ReadString(rcpath, rcstring, "");
        mSkin.captionClicks.Dbl[i] = get_string_index(p, button_ids);
    }

    strncpy(mSkin.button_string, ReadString(rcpath, "bbWinSkin.titlebar.buttons:", "7654321"), 7);

    // button pics
    read_buttons();

	iconSize = ReadInt(rcpath, "bbWinSkin.titlebar.icon.size:", -1);
	mSkin.iconSat = ReadInt(rcpath, "bbWinSkin.titlebar.icon.saturation:", 95);
	mSkin.iconHue = ReadInt(rcpath, "bbWinSkin.titlebar.icon.hue:", 63);

	//====================
    // other settings

	mSkin.nixShadeStyle = ReadBool(rcpath, "bbWinSkin.option.nixShadeStyle:", false);
	mSkin.snapWindows = ReadInt(rcpath, "bbWinSkin.option.snapWindows:", 0);
    mSkin.labelBarrier = ReadInt(rcpath, "bbWinSkin.option.labelBarrier:", -1);
	adjustCaptionHeight = ReadBool(rcpath, "bbWinSkin.option.adjustCaptionHeight:", true);
	enableLog = ReadBool(rcpath, "bbWinSkin.option.enableLog:", false);

	//====================
    // windows appearance settings
    MenuHeight = ReadInt(rcpath, "bbWinSkin.windows.menu.height:", -1);
    strcpy(windows_menu_fontFace, ReadString(rcpath, "bbWinSkin.windows.menu.Font:", ""));
    windows_menu_fontHeight = ReadInt(rcpath, "bbWinSkin.windows.menu.fontHeight:", 12);
    ScrollbarSize = ReadInt(rcpath, "bbWinSkin.windows.scrollbarsize:", -1);
    setTTColor = ReadBool(rcpath, "bbWinSkin.windows.setToolTipColor:", false);
    safeMetrics = ReadBool(rcpath, "bbWinSkin.windows.safeMetrics:", false);
    mSkin.imageDither = ReadInt(bbrcPath(), "session.imageDither:", ReadInt(rcpath, "bbWinSkin.windows.imageDither:", 0));

    fontShadows = ReadBool(extensionsrcPath(), "xoblite.force.font.shadows:", ReadBool(bbrcPath(), "session.force.font.shadows:", false));
    shadowsQwilk = BBVersion != 2;

#ifdef TRANSPARENCY
	mSkin.focusTransparency = ReadInt(rcpath, "bbWinSkin.windows.focusTransparency:", 255);
	mSkin.unfocusTransparency = ReadInt(rcpath, "bbWinSkin.windows.unfocusTransparency:", 255);
	mSkin.backTransparency = ReadColor(rcpath, "bbWinSkin.windows.backTransparency:", "#c3ff11");
	// avoid backTransparency NULL strings
	if (strlen(ReadString(rcpath, "bbWinSkin.windows.backTransparency:", "no")) != 7)
		mSkin.backTransparency = 0x0011ff3c;
	// (un)focusTransparency & backTransparency mutually exclusive
	if ((switch_rgb(mSkin.backTransparency) - 12844817) != 0)
	{
		mSkin.focusTransparency = mSkin.unfocusTransparency = 255;
		mSkin.isBackTrans = true;
	}
	mSkin.Win2kXP = GetOSVersion() > 49;
#endif

	//====================

    mSkin.BBhwnd = BBhwnd;

    if (BBVersion != 2)
	    mSkin.BBVersion = 0;
	else
		mSkin.BBVersion = 2;
    mSkin.loghwnd = m_hwnd;
    mSkin.enableLog = enableLog;
}

//===========================================================================
// copy style into Skin

char param[64], temp1[64], temp2[64];
int borderWidth;
COLORREF borderColor;

void readStyle(void)
{
	char style[MAX_PATH];
	borderWidth = *(int*)GetSettingPtr(SN_BORDERWIDTH);
	borderColor = *(COLORREF*)GetSettingPtr(SN_BORDERCOLOR);
	strcpy(style, stylePath());

	mSkin.frameWidth = *(int*)GetSettingPtr(SN_FRAMEWIDTH);
   // enable adjustment via bbStylemaker for frameWidth
	if (!FindWindow("BBPluginDlg", "BBStylemaker"))
	{
		mSkin.frameWidth = ReadInt(style, "window.frame.borderWidth:", mSkin.frameWidth);
		mSkin.frameWidth = ReadInt(style, "frameWidth:", mSkin.frameWidth);
		mSkin.frameWidth = ReadInt(style, "window.client.padding.width:", mSkin.frameWidth);
		mSkin.frameWidth = ReadInt(style, "window.frameWidth:", mSkin.frameWidth);
	}

	strcpy(temp1, ReadString(style, "menu.frame.appearance:", "no"));
    mSkin.is_style070 = strlen(temp1) != 2;

	if (mSkin.BBVersion == 2 && (bbLeanVersion < 1170))
	{
		static const char settings_id_array[] =
		{
			SN_WINFOCUS_TITLE         ,
			SN_WINFOCUS_LABEL         ,
			SN_WINFOCUS_HANDLE        ,
			SN_WINFOCUS_GRIP          ,
			SN_WINFOCUS_BUTTON        ,
			SN_WINFOCUS_BUTTONP
			,
			SN_WINUNFOCUS_TITLE       ,
			SN_WINUNFOCUS_LABEL       ,
			SN_WINUNFOCUS_HANDLE      ,
			SN_WINUNFOCUS_GRIP        ,
			SN_WINUNFOCUS_BUTTON      ,
		};

		GradientItem * pG; const char *s = settings_id_array;
		for (pG = &mSkin.windowTitleFocus; pG <= &mSkin.windowButtonUnfocus; ++pG, ++s)
		{
			StyleItem *pSI = (StyleItem*)GetSettingPtr(*s);
			if (NULL == pSI) continue;
			copy_GradientItem(pG, pSI);
		}

		mSkin.windowLabelFocus.marginWidth = 2;
		mSkin.windowButtonFocus.marginWidth = 1;

		// non-blurring of FontShadows
		if (fontShadows && ((strlen(ReadString(style, "window.label.focus.ShadowColor:", "no"))) + (strlen(ReadString(style, "window.label.focus.ShadowColor:", "no"))) == 4))
		{
			bool match = FuzzyMatch(mSkin.windowLabelFocus.TextColor, mSkin.windowLabelUnfocus.TextColor);
			if (!match)
			{
				mSkin.windowLabelFocus.ShadowColor = mSkin.windowLabelUnfocus.TextColor;
				mSkin.windowLabelUnfocus.ShadowColor = mSkin.windowLabelFocus.TextColor;
			}
			else
			{
				mSkin.windowLabelFocus.ShadowColor = Settings_CreateShadowColor(mSkin.windowLabelFocus.TextColor);
				mSkin.windowLabelUnfocus.ShadowColor = Settings_CreateShadowColor(mSkin.windowLabelUnfocus.TextColor);
			}
		}
	}
	else
	{
		ReadGradientItem(style, &mSkin.windowTitleFocus, "window.title.focus");
		ReadGradientItem(style, &mSkin.windowLabelFocus, "window.label.focus");
		ReadGradientItem(style, &mSkin.windowHandleFocus, "window.handle.focus");
		ReadGradientItem(style, &mSkin.windowGripFocus, "window.grip.focus");
		ReadGradientItem(style, &mSkin.windowButtonFocus, "window.button.focus");
		ReadGradientItem(style, &mSkin.windowButtonPressed, "window.button.pressed");

		ReadGradientItem(style, &mSkin.windowTitleUnfocus, "window.title.unfocus");
		ReadGradientItem(style, &mSkin.windowLabelUnfocus, "window.label.unfocus");
		ReadGradientItem(style, &mSkin.windowHandleUnfocus, "window.handle.unfocus");
		ReadGradientItem(style, &mSkin.windowGripUnfocus, "window.grip.unfocus");
		ReadGradientItem(style, &mSkin.windowButtonUnfocus, "window.button.unfocus");
	}


	strcpy(temp1, ReadString(style, "window.frame.focus.borderColor:", "0x000000"));
	strcpy(temp2, ReadString(style, "window.frame.focus.color:", temp1));
	strcpy(temp1, ReadString(style, "window.frame.focusColor:", temp2));
	mSkin.focus_borderColor = !stricmp(temp1, "0x000000") ? borderColor : ReadColor(style, "window.frame.focusColor:", temp2);

	strcpy(temp1, ReadString(style, "window.frame.unfocus.borderColor:", "0x000000"));
	strcpy(temp2, ReadString(style, "window.frame.unfocus.color:", temp1));
	strcpy(temp1, ReadString(style, "window.frame.unfocusColor:", temp2));
	mSkin.unfocus_borderColor =  !stricmp(temp1, "0x000000") ? borderColor : ReadColor(style, "window.frame.unfocusColor:", temp2);
	// naming of GetSettingPtr(16) changes depending on the bb4win flavour
	mSkin.handleHeight = ReadInt(style, "window.handleHeight:", *(int*)GetSettingPtr(16));
	mSkin.handleHeight = ReadInt(style, "handleWidth:", mSkin.handleHeight);
	mSkin.handleHeight = ReadInt(style, "handleHeight:", mSkin.handleHeight);

	// remove NULL FontShadows
	if (!fontShadows)
	{
		mSkin.windowLabelFocus.ShadowX = mSkin.windowLabelUnfocus.ShadowX =
			mSkin.windowLabelUnfocus.ShadowY = mSkin.windowLabelFocus.ShadowY = 0;
	}

	//====================
	// enable resizeability
	if (safeMetrics)
	{
		if (mSkin.is_style070)
			mSkin.frameWidth = imax(mSkin.frameWidth, 1);
		else
			mSkin.windowTitleFocus.borderWidth = imax(mSkin.windowTitleFocus.borderWidth, 1);
	}

	//====================
    // calculate dependent sizes

	int lfh;
	HFONT hf;

	// NOTE: CreateStyleFont is not supported by all branches
	if (BBVersion == 2)
		hf = CreateStyleFont((StyleItem*)GetSettingPtr(SN_WINFOCUS_LABEL));
	else
	{
		ReadFont(style);
		hf =  CreateFont(windowFont.Height, 0, 0, 0, windowFont.Weight, 
			false, false, false, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, 
			CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH|FF_DONTCARE, 
			windowFont.Face
			);
	}

	lfh = get_fontheight(hf);
	GetObject(hf, sizeof mSkin.Font, &mSkin.Font);
	DeleteObject(hf);
	// damned, GetObject fills in random crap after the fontname,
	// which again makes the SystemParametersInfo below trigger
	strncpy(
		mSkin.Font.lfFaceName,
		mSkin.Font.lfFaceName,
		sizeof mSkin.Font.lfFaceName
		);

	bool safeTitle = (safeMetrics && (mSkin.Font.lfHeight > 16));
	int fontCollar = mSkin.Font.lfHeight;
	if (safeTitle)
	{
		mSkin.windowTitleFocus.marginWidth = iminmax(mSkin.windowTitleFocus.marginWidth, mSkin.windowLabelFocus.marginWidth, 1);
		mSkin.windowTitleUnfocus.marginWidth = iminmax(mSkin.windowTitleUnfocus.marginWidth, mSkin.windowLabelUnfocus.marginWidth, 1);
		mSkin.windowLabelFocus.marginWidth = iminmax(mSkin.windowLabelFocus.marginWidth, mSkin.windowTitleFocus.marginWidth, 2);
		mSkin.windowLabelUnfocus.marginWidth = iminmax(mSkin.windowLabelUnfocus.marginWidth, mSkin.windowTitleUnfocus.marginWidth, 2);
		fontCollar = 24 - mSkin.windowTitleFocus.marginWidth - mSkin.windowLabelFocus.marginWidth;
		mSkin.handleHeight = mSkin.handleHeight > 7 ? 7 : mSkin.handleHeight;
	}

	mSkin.Font.lfHeight = safeTitle ? imin(mSkin.Font.lfHeight, fontCollar) : mSkin.Font.lfHeight;
	mSkin.Justify = mSkin.labelBarrier !=-1 ? DT_CENTER : windowFont.Justify;

    // titlebar metrics are similar to the toolbar
    int labelH, buttonH;

    int bottom_border = imax(mSkin.windowHandleFocus.borderWidth, mSkin.windowGripFocus.borderWidth);
    int top_border = imax(mSkin.windowTitleFocus.borderWidth, mSkin.windowTitleUnfocus.borderWidth);
    int lbl_border = imax(mSkin.windowLabelFocus.borderWidth, mSkin.windowLabelUnfocus.borderWidth);
    int button_border = imax(mSkin.windowButtonFocus.borderWidth, mSkin.windowButtonUnfocus.borderWidth);

	if (-1 == iconSize) iconSize = lfh + 2;
	if (iconSize > 24) iconSize = 24;

    labelH = (imax((iconSize+2), lfh)|1) + 2*mSkin.windowLabelFocus.marginWidth;
    labelH |= 1;
	labelH = safeTitle ? imin(labelH, fontCollar) : labelH;
    buttonH = labelH + 2*(mSkin.windowButtonFocus.marginWidth-mSkin.windowLabelFocus.marginWidth);

    mSkin.buttonSize = imax(buttonH, iconSize);
    mSkin.labelHeight = labelH;
    mSkin.labelIndent = imax(2+lbl_border,(labelH-lfh)/2);

    mSkin.ncTop = imax(labelH, buttonH) + 2*(top_border + mSkin.windowTitleFocus.marginWidth);

    mSkin.ncBottom =
        mSkin.handleHeight // with no handle, there is only one border
        ? mSkin.handleHeight + 2 * bottom_border
        : mSkin.frameWidth
        ;

    mSkin.rollupHeight = mSkin.ncTop;
    if (false == mSkin.nixShadeStyle && mSkin.handleHeight)
        mSkin.rollupHeight += mSkin.ncBottom - imin(top_border, bottom_border);

    mSkin.gripWidth = 2*mSkin.buttonSize + mSkin.frameWidth;

    mSkin.labelMargin = (mSkin.ncTop - mSkin.labelHeight) / 2;
    mSkin.buttonMargin = (mSkin.ncTop - mSkin.buttonSize) / 2;
    mSkin.buttonSpace = imax(0, mSkin.buttonMargin - bottom_border);
    if (mSkin.buttonSpace == 0)
        mSkin.buttonSpace -= button_border;

}

//===========================================================================
// adjust the global window metrics

static NONCLIENTMETRICS ncm_save;
static NONCLIENTMETRICS ncm_prev;
static LOGFONT font_save;
static LOGFONT font_prev;

void setmetrics(void)
{
	//====================
    // copy default settings

    NONCLIENTMETRICS ncm_now = ncm_save;
	LOGFONT font_now = font_save;

	//====================
    // set the sizing border to at least the style border.
    ncm_now.iBorderWidth = imax(1, mSkin.frameWidth - 3);

    //---------------------------
    // set the caption heights. If this is more than "mSkin.ncTop",
    // it will be hidden by the region setting.

    if (adjustCaptionHeight)
    {
        int n = mSkin.ncTop - ncm_now.iBorderWidth - 3;
        ncm_now.iCaptionHeight = ncm_now.iSmCaptionHeight = n;
        ncm_now.lfCaptionFont = mSkin.Font;
        ncm_now.lfSmCaptionFont = mSkin.Font;
    }

	//====================
    // other settings
    if (-1 != MenuHeight)
        ncm_now.iMenuHeight = MenuHeight;

    if (-1 != ScrollbarSize)
        ncm_now.iScrollWidth = ncm_now.iScrollHeight = ScrollbarSize;

	//====================
    // set menu/status/message font

	if (windows_menu_fontFace[0]) 
	{
		LOGFONT F;
        ZeroMemory(&F, sizeof F);
        F.lfHeight = -windows_menu_fontHeight;
        F.lfWeight = FW_NORMAL;
        F.lfCharSet = DEFAULT_CHARSET;
        F.lfOutPrecision = OUT_DEFAULT_PRECIS;
        F.lfClipPrecision = CLIP_DEFAULT_PRECIS;
        F.lfQuality = DEFAULT_QUALITY;
        F.lfPitchAndFamily = DEFAULT_PITCH|FF_DONTCARE;

		strcpy(F.lfFaceName, windowFont.Face);

        ncm_now.lfMenuFont = F;
        ncm_now.lfStatusFont = F;
        ncm_now.lfMessageFont = F;
		ncm_now.lfCaptionFont = F;
		ncm_now.lfSmCaptionFont = F;
		font_now = F;
    }

	//====================
    // set system parameters on changes
    if (memcmp (&ncm_now, &ncm_prev, sizeof(NONCLIENTMETRICS)))
    {
        ncm_prev = ncm_now;
        SystemParametersInfo(
            SPI_SETNONCLIENTMETRICS,
            sizeof(NONCLIENTMETRICS),
            &ncm_now,
            SPIF_SENDCHANGE
            );
        font_prev = font_now;
        SystemParametersInfo(
            SPI_SETICONTITLELOGFONT,
            sizeof(LOGFONT),
            &font_now,
            SPIF_SENDCHANGE
            );
    }

    mSkin.cxSizeFrame = GetSystemMetrics(SM_CYSIZEFRAME);
    mSkin.cxFixedFrame = GetSystemMetrics(SM_CYFIXEDFRAME);
    mSkin.cyCaption = GetSystemMetrics(SM_CYCAPTION);
    mSkin.cySmCaption = GetSystemMetrics(SM_CYSMCAPTION);

	//====================
    // set skin info in shared memory
    memcpy(lpvMem, &mSkin, offset_hooks);
}

//===========================================================================
// SysColor Stuff

enum { SAVE_3DC, RESTORE_3DC, APPLY_3DC };

void setTTC(int f)
{
    const int NCOLORS = 11;
    static int C_ID[NCOLORS] =
    {
        // colors for active non-skinned windows
		COLOR_ACTIVECAPTION,
		COLOR_GRADIENTACTIVECAPTION,
		COLOR_CAPTIONTEXT,
		COLOR_ACTIVEBORDER,
		// tooltips border
		COLOR_WINDOWFRAME,
        // colors for inactive non-skinned windows
		COLOR_INACTIVECAPTION,
		COLOR_GRADIENTINACTIVECAPTION,
		COLOR_INACTIVECAPTIONTEXT,
		COLOR_INACTIVEBORDER,
        // tooltips bk + txt
        COLOR_INFOBK,
        COLOR_INFOTEXT
    };
    static COLORREF C_SAVE[NCOLORS];
    static bool changed;

    if (SAVE_3DC == f)
    {
        int n = 0;
        do C_SAVE[n] = GetSysColor(C_ID[n]); while (++n<NCOLORS);
        changed = false;
        return;
    }

    if (RESTORE_3DC == f || false == setTTColor)
    {
        if (changed)
        {
            SetSysColors(NCOLORS, C_ID, C_SAVE);
            changed = false;
        }
        return;
    }

    if (APPLY_3DC == f)
    {
        COLORREF C_CR[NCOLORS];
        GradientItem *S1, *S2, *S3, *S4, *S5, *S6;
        S1 = S2 = &mSkin.windowLabelFocus;
        S3 = S4 = &mSkin.windowLabelUnfocus;
        S5 = S6 = &mSkin.windowButtonFocus;

        if (S1->parentRelative)
            S1 = &mSkin.windowTitleFocus;
        if (S3->parentRelative)
            S3 = &mSkin.windowTitleUnfocus;
        if (S5->parentRelative)
            S5 = &mSkin.windowTitleFocus;

        C_CR[0] = S1->Color;
        if (B_SOLID == S1->type)
            C_CR[1] = C_CR[0];
        else
            C_CR[1] = S1->ColorTo;
        C_CR[2] = S2->TextColor;

        C_CR[3] = mSkin.focus_borderColor;

        if (setTTColor)
			C_CR[4] = mSkin.focus_borderColor;

        C_CR[5] = S3->Color;
        if (B_SOLID == S3->type)
            C_CR[6] = C_CR[6];
        else
            C_CR[6] = S3->ColorTo;
        C_CR[7] = S4->TextColor;

        C_CR[8] = mSkin.unfocus_borderColor;;

        if (setTTColor)
		{
			if (B_SOLID == S5->type)
				C_CR[9] = S5->Color;
			else
				C_CR[9] = mixcolors(S5->Color, S5->ColorTo, 192);

			C_CR[10] = FuzzyMatch(C_CR[9], S6->TextColor) ? Settings_CreateShadowColor(S6->TextColor) : S6->TextColor;
		}

        SetSysColors(NCOLORS, C_ID, C_CR);
        changed = true;
    }
}

//===========================================================================
// load the engine

HINSTANCE hEngineInst;
int (*EntryFunc)(int mode, SkinStruct *pS);

//====================

bool load_dll(void)
{
    if (NULL == hEngineInst)
    {
        char engine_path[MAX_PATH];
        const char *error = NULL;

        hEngineInst = LoadLibrary(set_my_path(hInstance, engine_path, BBWINSKIN_ENGINEDLL));
        *(FARPROC*)&EntryFunc = GetProcAddress(hEngineInst, "EntryFunc");

        if (NULL == EntryFunc)
            error = "Could not load: " BBWINSKIN_ENGINEDLL;
        else
        if (ENGINE_THISVERSION != EntryFunc(ENGINE_GETVERSION, NULL))
            error = "Wrong version: " BBWINSKIN_ENGINEDLL;

        if (error)
        {
            free_dll();
            MessageBox(NULL, error, szAppName,
                MB_OK | MB_ICONERROR | MB_SETFOREGROUND | MB_TOPMOST);
            return false;
        }
    }
    return true;
}

//====================

void free_dll(void)
{
    if (hEngineInst)
        FreeLibrary(hEngineInst), hEngineInst = NULL;
}

//===========================================================================
// pass messages to windows

static BOOL CALLBACK SkinEnumProc(HWND hwnd, LPARAM lParam)
{
    void *pInfo = GetProp(hwnd, BBWINSKIN_INFOPROP);

    if (MSGID_LOAD == lParam)
    {
        if (NULL == pInfo
            && WS_CAPTION == (WS_CAPTION & GetWindowLong(hwnd, GWL_STYLE)))
        {
            PostMessage(hwnd, bbSkinMsg, lParam, 0);
        }
    }
    else if (pInfo)
    {
        SendMessage(hwnd, bbSkinMsg, lParam, 0);
    }

	return TRUE;
}

//====================

static BOOL CALLBACK EnumWindowsProc(HWND hwnd, LPARAM lParam)
{
	if (lParam == MSGID_UNLOAD)
		SetWindowLong(hwnd, GWL_EXSTYLE,	GetWindowLong(hwnd, GWL_EXSTYLE));
    EnumChildWindows(hwnd, (WNDENUMPROC)SkinEnumProc, lParam);
    SkinEnumProc(hwnd, lParam);
    return TRUE;
}

//====================

static void sendToAll(UINT msg_id)
{
    EnumWindows((WNDENUMPROC)EnumWindowsProc, msg_id);
}

//===========================================================================
// engine interface

void startEngine(void)
{
    readSettings();
    set_log_window();

    if (engine_running)
        return;
    if (false == make_exclusion_list())
        return;

    if (false == load_dll())
    {
        free_exclusion_list();
        return;
    }

    bbSkinMsg = RegisterWindowMessage(BBWINSKIN_WINDOWMSG);

    // save sys-colors
    setTTC(SAVE_3DC);

    // save the normal SystemParameter settings, window metrics, etc.
    ncm_save.cbSize = sizeof(NONCLIENTMETRICS);
    SystemParametersInfo(SPI_GETNONCLIENTMETRICS, sizeof ncm_save, &ncm_save, 0);
    SystemParametersInfo(SPI_GETICONTITLELOGFONT, sizeof font_save, &font_save, 0);
    ZeroMemory(&ncm_prev, sizeof(NONCLIENTMETRICS));
    ZeroMemory(&font_prev, sizeof(LOGFONT));

    // read styles for skin
    readStyle();
    // possibly set sys-colors
    setTTC(APPLY_3DC);
    // set the system wide window metrics according to style metrics
    setmetrics();
    // set the hook
    EntryFunc(ENGINE_SETHOOKS, lpvMem);
    engine_running = true;

    // now apply to open windows
    /*if (applyToOpen) */sendToAll(MSGID_LOAD);

    //write_bin();
}

//====================

void refreshStyle(void)
{
    if (false == engine_running) return;
    readStyle();
    setmetrics();
    sendToAll(MSGID_REFRESH);
}

//====================

void reconfigureEngine(void)
{
    readSettings();
    set_log_window();
    if (false == engine_running) return;
    refreshStyle();
    setTTC(APPLY_3DC);
}

//====================

void stopEngine(void)
{
    if (false == engine_running) return;
    sendToAll(MSGID_UNLOAD);
    EntryFunc(ENGINE_UNSETHOOKS, lpvMem);
    free_exclusion_list();
    free_dll();
    // restore the normal SystemParameter settings, window metrics, etc.
    SystemParametersInfo(SPI_SETNONCLIENTMETRICS, sizeof(NONCLIENTMETRICS), &ncm_save, SPIF_SENDCHANGE);
    SystemParametersInfo(SPI_SETICONTITLELOGFONT, sizeof(LOGFONT), &font_save, SPIF_SENDCHANGE);
   // restore sys-colors
    setTTC(RESTORE_3DC);
    engine_running = false;
}

//====================

void setEngineOption(UINT id)
{
    if (engine_running) sendToAll(id);
}

//====================

//qwilk's FontShadows in xoblite bb3
COLORREF CreateShadowColor(GradientItem* si, COLORREF color, COLORREF colorTo)
{
        BYTE r = GetRValue(color);
        BYTE g = GetGValue(color);
        BYTE b = GetBValue(color);
        BYTE rto = GetRValue(colorTo);
        BYTE gto = GetGValue(colorTo);
        BYTE bto = GetBValue(colorTo);

        int rav, gav, bav;

        if (colorTo != 0)
        {
                rav = (r+rto) / 2;
                gav = (g+gto) / 2;
                bav = (b+bto) / 2;
        }
        else
        {
                rav = r;
                gav = g;
                bav = b;
        }

        if (rav < 0x10) rav = 0;
        else rav -= 0x10;
        if (gav < 0x10) gav = 0;
        else gav -= 0x10;
        if (bav < 0x10) bav = 0;
        else bav -= 0x10;

        return RGB((BYTE)rav, (BYTE)gav, (BYTE)bav);
}

//===========================================================================
// Function: ParseGradient
// Purpose: parses a given string and assigns settings to a GradientItem class
// In: LPCSTR = item to parse out
// In: GradientItem* = class to assign values to
// Out: void = None
//===========================================================================
struct styleprop { char *key; int  val; };

static struct styleprop styleprop_1[] = {
    {(char *)"flat"        ,BEVEL_FLAT           },
    {(char *)"raised"      ,BEVEL_RAISED         },
    {(char *)"sunken"      ,BEVEL_SUNKEN         },
    {NULL          ,BEVEL_RAISED         }
    };

static struct styleprop styleprop_2[] = {
    {(char *)"bevel1"      ,BEVEL1         },
    {(char *)"bevel2"      ,BEVEL2         },
    {(char *)"bevel3"      ,BEVEL3         },
    {NULL          ,BEVEL1         }
    };

static struct styleprop styleprop_3[] = {
    {(char *)"solid"        ,B_SOLID           },
 	{(char *)"splithorizontal",B_SPLITHORIZONTAL   },
 	{(char *)"blockhorizontal",B_BLOCKHORIZONTAL   },
 	{(char *)"mirrorhorizontal",B_MIRRORHORIZONTAL   },
 	{(char *)"wavehorizontal",B_WAVEHORIZONTAL   },
    {(char *)"horizontal"   ,B_HORIZONTAL      },
  	{(char *)"splitvertical",B_SPLITVERTICAL   },
 	{(char *)"blockvertical",B_BLOCKVERTICAL   },
 	{(char *)"mirrorvertical",B_MIRRORVERTICAL   },
 	{(char *)"wavevertical",B_WAVEVERTICAL   },
    {(char *)"vertical"     ,B_VERTICAL        },
    {(char *)"crossdiagonal",B_CROSSDIAGONAL   },
    {(char *)"diagonal"     ,B_DIAGONAL        },
    {(char *)"pipecross"    ,B_PIPECROSS       },
    {(char *)"elliptic"     ,B_ELLIPTIC        },
    {(char *)"rectangle"    ,B_RECTANGLE       },
    {(char *)"pyramid"      ,B_PYRAMID         },
    {NULL           ,-1                }
    };

static int check_item(const char *p, struct styleprop *s)
{
    do if (strstr(p, s->key)) break; while ((++s)->key);
    return s->val;
}

int ParseType(char *buf)
{
    return check_item(buf, styleprop_3);
}

void ParseGradient(LPCSTR szItem, GradientItem *item)
{
    char buf[64]; int t;
    strlwr(strcpy(buf, szItem));
    item->bevelstyle = check_item(buf, styleprop_1);
    item->bevelposition = BEVEL_FLAT == item->bevelstyle ? 0 : check_item(buf, styleprop_2);
    t = check_item(buf, styleprop_3);
    item->type = (-1 != t) ? t : B_SOLID;
    item->interlaced = NULL!=strstr(buf, "interlaced");
    item->parentRelative = NULL!=strstr(buf, "parentrelative");
}

void ReadGradientItem(const char * style, GradientItem *gi, const char *rckey)
{
	const char *p = "0x000000";
    char *subkey = param + strlen(strcpy(param, rckey));
	bool splitGradient = false; 
	bool reset = false; //qwilk's system for splitGradients

    ZeroMemory(gi, sizeof *gi);

	strcpy(subkey, mSkin.is_style070 ? ".appearance:" : ":");
	strcpy(temp1, ReadString(style, param, ""));
    if (strlen(temp1) > 5) ParseGradient(temp1, gi);
	{
		if (stristr(temp1, "split"))
			splitGradient = true; 
		if (!stricmp(GetBBVersion(), "bb4")) 
			reset = true; 
	}

	if (!IsInString(rckey, "handle") || !IsInString(rckey, "grip") || !IsInString(rckey, "title")) 
	{
		strcpy(temp2, ReadString(style, "*foregroundColor:", p));
		strcpy(temp1, ReadString(style, "*.foregroundColor:", temp2));
		strcpy(temp2, ReadString(style, "*picColor:", temp1));
		strcpy(temp1, ReadString(style, "*.picColor:", temp2));
		strcpy(temp2, ReadString(style, "*textColor:", temp1));
		strcpy(temp1, ReadString(style, "*.textColor:", temp2));
		strcpy(subkey, ".foregroundColor:");
		strcpy(temp2, ReadString(style, param, temp1));
		strcpy(subkey, ".picColor:");
		strcpy(temp1, ReadString(style, param, temp2));
		strcpy(subkey, ".textColor:"  );
		gi->TextColor   = ReadColor(style, param, temp1);
	}

	if (gi->parentRelative) 
		IsInString(rckey, "title") ? param + strlen(strcpy(param, "toolbar")) : (IsInString(rckey, "focus") ? param + strlen(strcpy(param, "window.title.focus")) : param + strlen(strcpy(param, "window.title.unfocus")));

	if (gi->type == B_SOLID) 
	{
		if (!mSkin.is_style070)	
		{
			strcpy(temp2, ReadString(style, "*Color:", p));
			strcpy(temp1, ReadString(style, "*.Color:", temp2));
			strcpy(subkey, ".color:"      );
			gi->Color       = ReadColor(style, param, temp1);
		}
		else
		{
			strcpy(temp2, ReadString(style, "*backgroundColor:", p));
			strcpy(temp1, ReadString(style, "*.backgroundColor:", temp2));
			strcpy(subkey, ".backgroundColor:");
			gi->Color       = ReadColor(style, param, temp1);
		}
		gi->ColorSplitTo = gi->ColorToSplitTo = gi->ColorTo = gi->Color; 
	}
	else
	{
		if (!mSkin.is_style070)	
		{
			strcpy(temp2, ReadString(style, "*Color:", p));
			strcpy(temp1, ReadString(style, "*.Color:", temp2));
			strcpy(subkey, ".color:"      );
			gi->Color       = ReadColor(style, param, temp1);

			strcpy(temp2, ReadString(style, "*ColorTo:", p));
			strcpy(temp1, ReadString(style, "*.ColorTo:", temp2));
			strcpy(subkey, ".colorTo:"    );
			gi->ColorTo     = ReadColor(style, param, temp1);
		}
		else
		{
			strcpy(temp2, ReadString(style, "*Color1:", p));
			strcpy(temp1, ReadString(style, "*.Color1:", temp2));
			strcpy(subkey, (reset && splitGradient) ? ".color2:" : ".color1:");
			gi->Color       = ReadColor(style, param, temp1);

			strcpy(temp2, ReadString(style, "*Color2:", p));
			strcpy(temp1, ReadString(style, "*.Color2:", temp2));
			strcpy(subkey, (reset && splitGradient) ? ".color3:" : ".color2:");
			gi->ColorTo     = ReadColor(style, param, temp1);
		}
	}

	if (IsInString(rckey, "label") && fontShadows) 
	{
		gi->ShadowColor =  CreateShadowColor(gi, gi->Color,  gi->ColorTo);
		gi->ShadowX = gi->ShadowY =  1;
	}

	if (splitGradient) 
	{
		if (!mSkin.is_style070)	
		{
			strcpy(subkey, ".color.splitTo:");
			strcpy(temp2, ReadString(style, param, "0xffffff"));
			strcpy(subkey, ".ColorSplitTo:");
			strcpy(temp1, ReadString(style, param, temp2));
			if (!stricmp(temp1, "0xffffff"))
				gi->ColorSplitTo = split(gi->Color, false);
			else
				gi->ColorSplitTo = ReadColor(style, param, temp1);

			strcpy(subkey, ".colorTo.splitTo:");
			strcpy(temp2, ReadString(style, param, "0xdddddd"));
			strcpy(subkey, ".ColorToSplitTo:");
			strcpy(temp1, ReadString(style, param, temp2));
			if (!stricmp(temp1, "0xdddddd"))
				gi->ColorToSplitTo = split(gi->ColorTo, true);
			else
				gi->ColorToSplitTo = ReadColor(style, param, temp1);
		}
		else
		{
			strcpy(subkey, reset ? ".color1:" : ".color0:");
			strcpy(temp1, ReadString(style, param, "0xffffff"));
			strcpy(subkey, ".color1.splitTo:"  );
			strcpy(temp2, ReadString(style, param, temp1));
			if (!stricmp(temp2, "0xffffff"))
				gi->ColorSplitTo = split(gi->Color, false);
			else
				gi->ColorSplitTo = ReadColor(style, param, temp2);

			strcpy(subkey, reset ? ".color4:" : ".color3:");
			strcpy(temp1, ReadString(style, param, "0xdddddd"));
			strcpy(subkey, ".color2.splitTo:"  );
			strcpy(temp2, ReadString(style, param, temp1));
			if (!stricmp(temp1, "0xdddddd"))
				gi->ColorToSplitTo = split(gi->ColorTo, true);
			else
				gi->ColorToSplitTo = ReadColor(style, param, temp2);
		}
	}
	else 
	{
		gi->ColorSplitTo = gi->Color;
		gi->ColorToSplitTo = gi->ColorTo;
	}

	if ((!mSkin.is_style070 && !IsInString(rckey, "label") && !IsInString(rckey, "button"))) 
	{
		strcpy(subkey, ".borderWidth:");
		gi->borderWidth = ReadInt(style, param, borderWidth);

		strcpy(subkey, ".borderColor:");
		strcpy(temp1, ReadString(style, param, "0x000000"));
		gi->borderColor = !stricmp(temp1, "0x000000") ? borderColor : ReadColor(style, param, temp1);
	}

	if (IsInString(rckey, "title") || IsInString(rckey, "label") || IsInString(rckey, "button")) 
	{
		strcpy(subkey, ".marginWidth:");
		gi->marginWidth = ReadInt(style, "bevelWidth:", 2);
		gi->marginWidth = ReadInt(style, "marginWidth:", gi->marginWidth);
		gi->marginWidth = ReadInt(style, "*marginWidth:", gi->marginWidth);
		gi->marginWidth = ReadInt(style, "*.marginWidth:", gi->marginWidth);
	}
}

/*
 ============================================================================
 The code below was partly based on the xoblite font parsing implementation
 Copyright © 2002-2006 Karl-Henrik Henriksson [qwilk]
 Copyright © 2001-2004 The Blackbox for Windows Development Team
 http://xoblite.net/ - #bb4win on irc.freenode.net
 ============================================================================
*/

void ReadFont(LPSTR style)
{
	strcpy(temp1, ReadString(style, "*font:", font_save.lfFaceName));
	strcpy(temp2, ReadString(style, "*.font:", temp1));
	strcpy(temp1, ReadString(style, "window.font:", temp2));
	strcpy(windowFont.Face, ReadString(style, "window.label.focus.font:", temp1));

	// font may be stated several times
	if (0 == checkfont(windowFont.Face))
		strcpy(windowFont.Face, font_save.lfFaceName);

	if (strchr(windowFont.Face, '/')) // xoblite font name/size/weight format
	{
		strcpy(temp1, windowFont.Face);

		strcpy(temp1, Tokenize(temp1, windowFont.Face, "/"));

		if (strlen(temp1))
		{
			char height[MAX_PATH];
			strcpy(temp1, Tokenize(temp1, height, "/"));
			windowFont.Height = atoi(height);

			if (IsInString(temp1, "Bold")) windowFont.Weight = FW_BOLD;
			else windowFont.Weight = FW_NORMAL;
		}
		else
		{
			windowFont.Height = 12;
			windowFont.Weight = FW_BOLD;
		}
	}
	else
	{
		windowFont.Height = ReadInt(style, "*fontHeight:", 12);
		windowFont.Height = ReadInt(style, "*.fontHeight:", windowFont.Height);
		windowFont.Height = ReadInt(style, "window.fontHeight:", windowFont.Height);
		windowFont.Height = ReadInt(style, "window.label.focus.fontHeight:", windowFont.Height);

		strcpy(temp1, ReadString(style, "window.fontWeight:", "Normal"));
		strcpy(temp2, ReadString(style, "window.label.focus.fontWeight:", "Normal"));
		if (IsInString(temp2, "Bold")) windowFont.Weight = FW_BOLD;
		else windowFont.Weight = FW_NORMAL;
	}

	strcpy(temp1, ReadString(style, "window.alignment:", "Center"));
	strcpy(temp2, ReadString(style, "window.justify:", temp1));
	strcpy(temp1, ReadString(style, "window.label.focus.alignment:", temp2));
	strcpy(temp2, ReadString(style, "window.label.focus.justify:", temp1));
	if (IsInString(temp2, "Left")) windowFont.Justify = DT_LEFT;
	else if (IsInString(temp2, "Right")) windowFont.Justify = DT_RIGHT;
	else windowFont.Justify = DT_CENTER;
}

//===========================================================================

static int CALLBACK EnumFontFamProc(
	ENUMLOGFONT *lpelf,     // Pointer to logical font data
	NEWTEXTMETRIC *lpntm,   // Pointer to physical font data
	int FontType,           // Type of font
	LPARAM lParam           // Address of application defined data
   )
{
	(*(int*)lParam)++;
	return 0;
}

static int checkfont (char *face)
{
    int data = 0;
    HDC hdc = CreateCompatibleDC(NULL);
    EnumFontFamilies(hdc, face, (FONTENUMPROC)EnumFontFamProc, (LPARAM)&data);
    DeleteDC(hdc);
    return data;
}

//===========================================================================
