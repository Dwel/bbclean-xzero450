/*
 ============================================================================
 This file is part of the bbWinSkin source code.
 Copyright © 2003-2009 grischka (grischka@users.sourceforge.net)
 Copyright © 2003-2004|2006-2009 The Blackbox for Windows Development Team

 bbWinSkin is a plugin for Blackbox for Windows

 http://bb4win.sourceforge.net/ - http://bb4win.sourceforge.net/bblean/
 ============================================================================
 Partly based on ShellWM © 2002 ShellWM Development Team
 Partly based on CustomEyes © 1999-2001 Didier Abderrahmane
 ============================================================================

  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.

  http://www.fsf.org/licenses/gpl.html

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

 ============================================================================
*/ // hookinfo.h

// This file contains information common to both the loader and the skinner

// strings
#define BBWINSKIN_ENGINEDLL    "BBWINSKINENG.DLL"
#define BBWINSKIN_INFOPROP     "BBWINSKIN_INFOPROP"
#define BBWINSKIN_WINDOWMSG    "BBWINSKIN_WINDOWMSG"
#define BBWINSKIN_SHMEMID      "BBWINSKIN_SHMEMID"
#define BBSHADE_PROP            "BBNormalHeight"

// branch versions - not needed (all bbLean testing is for !bbLean)
#define BBVERSION_LEAN 2
#define BBVERSION_XOB 1
#define BBVERSION_09X 0

// options for 'int EntryFunc(int option, SkinStruct *pSkin);'
#define ENGINE_SETHOOKS 0
#define ENGINE_UNSETHOOKS 1
#define ENGINE_SKINWINDOW 2
#define ENGINE_GETVERSION 3
#define ENGINE_THISVERSION 1150

//#define TRANSPARENCY

// wParams for the registered 'BBWINSKIN_WINDOWMSG'
enum
{
    MSGID_GETSHADEHEIGHT   = 1,
    MSGID_LOAD              ,
    MSGID_UNLOAD            ,
    MSGID_REDRAW            ,
    MSGID_REFRESH           ,
    MSGID_BB_SETSTICKY      ,
    MSGID_BBSM_RESET        ,
    MSGID_BBSM_SETACTIVE    ,
    MSGID_BBSM_SETPRESSED   ,
};

// ---------------------------------------------
struct GradientItem
{
    int bevelstyle;
    int bevelposition;
    int type;
    bool parentRelative;
    bool interlaced;
    COLORREF Color;
    COLORREF ColorTo;
    COLORREF TextColor;
    int marginWidth;
    int borderWidth;
    COLORREF borderColor;
    COLORREF ColorSplitTo;
    COLORREF ColorToSplitTo;
    union{
        struct{
            char ShadowX;
            char ShadowY;
        };
        unsigned short ShadowXY;
    COLORREF ShadowColor;
    };
};

#define copy_GradientItem(p1,p2) \
    do { \
        (p1)->bevelstyle = (p2)->bevelstyle; \
        (p1)->bevelposition = (p2)->bevelposition; \
        (p1)->type = (p2)->type; \
        (p1)->parentRelative = (p2)->parentRelative; \
        (p1)->interlaced = (p2)->interlaced; \
        (p1)->Color = (p2)->Color; \
        (p1)->ColorTo = (p2)->ColorTo; \
        (p1)->TextColor = (p2)->TextColor; \
        (p1)->marginWidth = (p2)->marginWidth; \
        (p1)->borderWidth = (p2)->borderWidth; \
        (p1)->borderColor = (p2)->borderColor; \
        (p1)->ColorSplitTo = (p2)->ColorSplitTo; \
        (p1)->ColorToSplitTo = (p2)->ColorToSplitTo; \
        (p1)->ShadowX = (p2)->ShadowX; \
        (p1)->ShadowY = (p2)->ShadowY; \
        (p1)->ShadowColor = (p2)->ShadowColor; \
    } while (0)

// ---------------------------------------------
struct exclusion_item
{
    unsigned char flen, clen, option;
    char buff[2];
};

struct exclusion_info
{
    int size;
    int count;
    struct exclusion_item ei[1];
};

#define BUTTON_SIZE 9
#define BUTTON_MAP_SIZE ((BUTTON_SIZE*BUTTON_SIZE-1)/8+1)
struct button_bmp
{
    unsigned char data[2][BUTTON_MAP_SIZE];
};

// ---------------------------------------------
struct SkinStruct
{
    GradientItem windowTitleFocus;
    GradientItem windowLabelFocus;

    GradientItem windowHandleFocus;
    GradientItem windowGripFocus;
    GradientItem windowButtonFocus;
    GradientItem windowButtonPressed;

    GradientItem windowTitleUnfocus;
    GradientItem windowLabelUnfocus;

    GradientItem windowHandleUnfocus;
    GradientItem windowGripUnfocus;
    GradientItem windowButtonUnfocus;

    LOGFONT Font;
	int  Justify;   // DT_LEFT, DT_CENTER, DT_RIGHT

    COLORREF focus_borderColor;
    COLORREF unfocus_borderColor;
    int frameWidth;
    int handleHeight;

    int gripWidth;
    int labelBarrier;
    int buttonSize;
    int labelHeight;
    int labelIndent;
    int rollupHeight;
	int iconSat;
	int iconHue;

    int buttonSpace;
    int buttonMargin;
    int labelMargin;
    int ncTop;
    int ncBottom;

    struct button_bmp button_bmp[6];
    char button_string[7];

    struct {
        char Dbl[3];
        char Right[3];
        char Mid[3];
        char Left[3];
    } captionClicks;

    int snapWindows;
    bool enableLog;
    int imageDither;
    bool is_style070;
    bool nixShadeStyle;

#ifdef TRANSPARENCY
    bool Win2kXP;
	bool isBackTrans;
 	int focusTransparency;
 	int unfocusTransparency;
	COLORREF backTransparency;
#endif

    int cxSizeFrame;
    int cxFixedFrame;
    int cyCaption;
    int cySmCaption;

    HWND BBhwnd;
    HWND loghwnd;
    HWND skinwnd;
    int BBVersion;

    HHOOK hCallWndHook;
    HHOOK hGetMsgHook;
    struct exclusion_info exInfo;
};

#define offset_exInfo ((INT_PTR)&((SkinStruct*)NULL)->exInfo)
#define offset_hooks ((INT_PTR)&((SkinStruct*)NULL)->hCallWndHook)

// ---------------------------------------------




