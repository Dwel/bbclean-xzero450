/*
 ============================================================================

  This file is part of the Blackbox for Windows source code
  Copyright � 2001-2009 The Blackbox for Windows Development Team

  http://bb4win.sourceforge.net
  http://sourceforge.net/projects/bb4win

 ============================================================================

  Blackbox for Windows is free software, released under the GNU General
  Public License (GPL version 2 or later), with an extension that allows
  linking of proprietary modules under a controlled interface. This means
  that plugins etc. are allowed to be released under any license the author
  wishes. Please note, however, that the original Blackbox gradient math
  code used in Blackbox for Windows is available under the BSD license.

  http://www.fsf.org/licenses/gpl.html
  http://www.fsf.org/licenses/gpl-faq.html#LinkingOverControlledInterface
  http://www.xfree86.org/3.3.6/COPYRIGHT2.html#5

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
  or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
  for more details.

 ============================================================================
*/

#include "BBApi.h"
#include "bblib.h"

const char szVersion     [] = "bbKeys 1.16";
const char szAppName     [] = "bbKeys";
const char szInfoVersion [] = "1.16";
const char szInfoAuthor  [] = "grischka";
const char szInfoRelDate [] = "2009-06-01";
const char szInfoLink    [] = "http://bb4win.sourceforge.net/bblean";
const char szInfoEmail   [] = "grischka@users.sourceforge.net";
const char szInfoUpdateURL [] = "http://www.lostinthebox.com/viewforum.php?t=2928";

//===========================================================================
extern "C"
{
	DLL_EXPORT int beginPlugin(HINSTANCE hMainInstance);
	DLL_EXPORT void endPlugin(HINSTANCE hMainInstance);
	DLL_EXPORT LPCSTR pluginInfo(int field);
}

LPCSTR pluginInfo(int field)
{
	switch (field)
	{
		default:
		case 0: return szVersion;
		case 1: return szAppName;
		case 2: return szInfoVersion;
		case 3: return szInfoAuthor;
		case 4: return szInfoRelDate;
		case 5: return szInfoLink;
		case 6: return szInfoEmail;
		case 8: return szInfoUpdateURL;
	}
}

//===========================================================================

HWND hKeysWnd;
HWND BBhwnd;
HINSTANCE m_hMainInstance;
bool nolabel;
bool usingNT;
bool hook_is_set;

struct HotkeyType
{
	struct HotkeyType *next;
	unsigned ch, sub, is_ExecCommand;
	char *szAction;

} *m_hotKeys;

//===========================================================================

void set_kbdhook(bool set)
{
	static HINSTANCE hdll;
	bool (*SetKbdHook)(bool set);

	if (hook_is_set == set) return;
	hook_is_set = set;

	if (false == usingNT) return;

	if (set && NULL == hdll)
	{
		char path[MAX_PATH]; int nLen;
		GetModuleFileName(m_hMainInstance, path, sizeof(path));
		nLen = strlen(path);
		while (nLen && path[nLen-1] != '\\') nLen--;
		strcpy(path+nLen, "winkeyhook.dll");
		hdll = LoadLibrary(path);
	}

	if (hdll)
	{
		*(FARPROC*)&SetKbdHook = GetProcAddress(hdll, "SetKbdHook");

		if (SetKbdHook && SetKbdHook(set) && set)
			return;

		FreeLibrary(hdll);
		hdll = NULL;
	}
}

//===========================================================================

int getvalue(char *from, char *token, char *to, bool from_right)
{
	const char *p, *q; int l=0;
	if (NULL!=(p=stristr(from, token)))
	{
		p += strlen(token);
		while (' ' == *p) ++p;
		if ('(' == *p && NULL != (q = (from_right?strrchr:strchr)(++p,')')))
			memcpy(to, p, l = q-p);
	}
	to[l]=0;
	return l;
}

void BBKeys_LoadHotkeys(HWND hwnd)
{
	char rcpath[MAX_PATH]; 
	locate_file(m_hMainInstance, rcpath, szAppName, (char*)"rc");

	char buffer[1024], keytograb[120], modifier[120], action[1024];

	nolabel = false;
	int ID  = 0;
	FILE *fp = FileOpen(rcpath);

	HotkeyType **ppHk = &m_hotKeys;

	// KeyToGrab(), WithModifier(), WithAction(), DoThis()
	while (ReadNextCommand(fp, buffer, sizeof (buffer)))
	{
		if (0==getvalue(buffer, (char*)"KEYTOGRAB", keytograb, false))
		{
			if (0==stricmp("NOLABEL", buffer))
				nolabel = true;
			continue;
		}
		getvalue(buffer, (char*)"WITHMODIFIER", modifier, false);
		if (0==getvalue(buffer, (char*)"WITHACTION", action, false))
			continue;

		strupr(keytograb);

		unsigned ch = (unsigned char)keytograb[0];
		unsigned sub = 0;
		bool is_ExecCommand = false;

		if (0 == stricmp(action, "ExecCommand"))
		{
			is_ExecCommand = true;
			getvalue(buffer, (char*)"DOTHIS", action, true);
		}

		//dbg_printf(buffer, "<%s>\n<%s>\n<%s>\n", keytograb, modifier, action);

		if (keytograb[1])
		{
			static const struct vkTable { char* key; int vKey; } vkTable[] =
			{
				{(char*)"F1", VK_F1},
				{(char*)"F2", VK_F2},
				{(char*)"F3", VK_F3},
				{(char*)"F4", VK_F4},
				{(char*)"F5", VK_F5},
				{(char*)"F6", VK_F6},
				{(char*)"F7", VK_F7},
				{(char*)"F8", VK_F8},
				{(char*)"F9", VK_F9},
				{(char*)"F10", VK_F10},
				{(char*)"F11", VK_F11},
				{(char*)"F12", VK_F12},
				{(char*)"PRTSCN", VK_SNAPSHOT},
				{(char*)"PAUSE", VK_PAUSE},
				{(char*)"INSERT", VK_INSERT},
				{(char*)"DELETE", VK_DELETE},
				{(char*)"HOME", VK_HOME},
				{(char*)"END", VK_END},
				{(char*)"PAGEUP", VK_PRIOR},
				{(char*)"PAGEDOWN", VK_NEXT},
				{(char*)"LEFT", VK_LEFT},
				{(char*)"RIGHT", VK_RIGHT},
				{(char*)"DOWN", VK_DOWN},
				{(char*)"UP", VK_UP},
				{(char*)"TAB", VK_TAB},
				{(char*)"BACKSPACE", VK_BACK},
				{(char*)"SPACEBAR", VK_SPACE},
				{(char*)"APPS", VK_APPS},
				{(char*)"ENTER", VK_RETURN},
				{(char*)"NUM0", VK_NUMPAD0},
				{(char*)"NUM1", VK_NUMPAD1},
				{(char*)"NUM2", VK_NUMPAD2},
				{(char*)"NUM3", VK_NUMPAD3},
				{(char*)"NUM4", VK_NUMPAD4},
				{(char*)"NUM5", VK_NUMPAD5},
				{(char*)"NUM6", VK_NUMPAD6},
				{(char*)"NUM7", VK_NUMPAD7},
				{(char*)"NUM8", VK_NUMPAD8},
				{(char*)"NUM9", VK_NUMPAD9},
				{(char*)"MUL", VK_MULTIPLY},
				{(char*)"DIV", VK_DIVIDE},
				{(char*)"ADD", VK_ADD},
				{(char*)"SUB", VK_SUBTRACT},
				{(char*)"DEC", VK_DECIMAL},
				{(char*)"ESCAPE", VK_ESCAPE},
				{(char*)"LWIN", VK_LWIN},
				{(char*)"RWIN", VK_RWIN},
				{(char*)"VK_OEM_3", VK_OEM_3},
				{(char*)"VK_OEM_5", VK_OEM_5},
				{(char*)"VK_OEM_PLUS", VK_OEM_PLUS},
				{(char*)"VK_OEM_MINUS", VK_OEM_MINUS},
				{(char*)"VK_OEM_COMMA", VK_OEM_COMMA},
				{(char*)"VK_OEM_PERIOD", VK_OEM_PERIOD},
				{(char*)"NUMLOCK", VK_NUMLOCK},
				{(char*)"SCROLLOCK", VK_SCROLL},
				{(char*)"VOLUMEUP", VK_VOLUME_UP},
				{(char*)"VOLUMEDOWN", VK_VOLUME_DOWN},
				{ NULL, 0 }

			};
			const struct vkTable *v = vkTable;
			do if (!strcmp(v->key, keytograb))
			{
				ch = v->vKey;
				goto found;
			}
			while ((++v)->key);
			if (keytograb[0] == 'V' && keytograb[1] == 'K'
			  && keytograb[2] >= '0' && keytograb[2] <= '9')
			{
				ch = atoi(keytograb+2);
				goto found;
			}
			continue;
		}

found:
		if (stristr(modifier, "WIN"))   sub |= MOD_WIN;
		if (stristr(modifier, "ALT"))   sub |= MOD_ALT;
		if (stristr(modifier, "CTRL"))  sub |= MOD_CONTROL;
		if (stristr(modifier, "SHIFT")) sub |= MOD_SHIFT;

		if (VK_LWIN == ch || VK_RWIN == ch)
			set_kbdhook(true);
		else
		if (0==RegisterHotKey(hwnd, ID, sub, ch))
			continue;

		//dbg_printf("registered: %02X %02X %s", ch, sub, action);

		HotkeyType *h = (HotkeyType *)m_alloc(sizeof (HotkeyType));
		h->sub      = sub;
		h->ch       = ch;
		h->is_ExecCommand = is_ExecCommand;
		h->szAction = new_str(action);

		*(ppHk=&(*ppHk=h)->next)=NULL;
		ID++;
	}
	FileClose(fp);
}

//===========================================================================
void BBKeys_FreeHotkeys(HWND hwnd)
{
	HotkeyType * h; int ID = 0;
	dolist (h, m_hotKeys)
	{
		UnregisterHotKey(hwnd, ID++);
		free_str(&h->szAction);
	}
	freeall(&m_hotKeys);
}

//===========================================================================
void send_command(HotkeyType *h)
{
	char buffer[1024];
	const char *action = h->szAction;

	if (false == nolabel)
	{
		sprintf(buffer, "BBKeys -> %s", action);
		SendMessage(BBhwnd, BB_SETTOOLBARLABEL, 0, (LPARAM)buffer);
	}

	if (h->is_ExecCommand)
	{
		//replace "@BBCore.ShowMenu ..." by "@BBCore.ShowMenuKBD ..."
		static const char show_menu[] = "@BBCore.ShowMenu";
		if (0 == memicmp(h->szAction, show_menu, sizeof show_menu - 1)
		 && (0 == h->szAction[sizeof show_menu - 1]
			 || ' ' == h->szAction[sizeof show_menu - 1]
			 ))
		{
			sprintf(buffer, "%sKBD%s", show_menu, action + sizeof show_menu - 1);
			action = buffer;
		}
	}
	else
	{
		sprintf(buffer, "@BBCore.%s", action);
		action = buffer;
	}

	SendMessage(BBhwnd, BB_EXECUTEASYNC, 0, (LPARAM)action);
}

//===========================================================================

LRESULT CALLBACK HotkeyProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	static int msgs[] = {BB_RECONFIGURE, BB_WINKEY, 0};
	HotkeyType *h; unsigned sub;

	switch (message)
	{
		case WM_CREATE:
			SendMessage(BBhwnd, BB_REGISTERMESSAGE, (WPARAM)hwnd, (LPARAM)msgs);
			BBKeys_LoadHotkeys(hwnd);
			break;

		case WM_DESTROY:
			SendMessage(BBhwnd, BB_UNREGISTERMESSAGE, (WPARAM)hwnd, (LPARAM)msgs);
			BBKeys_FreeHotkeys(hwnd);
			break;

		case BB_RECONFIGURE:
			BBKeys_FreeHotkeys(hwnd);
			BBKeys_LoadHotkeys(hwnd);
			break;

		default:
			return DefWindowProc(hwnd, message, wParam, lParam);

		case BB_WINKEY:
			sub = 0;
			if (0x8000 & GetAsyncKeyState(VK_SHIFT))    sub |=MOD_SHIFT;
			if (0x8000 & GetAsyncKeyState(VK_CONTROL))  sub |=MOD_CONTROL;
			if (0x8000 & GetAsyncKeyState(VK_MENU))     sub |=MOD_ALT;
			dolist (h, m_hotKeys)
				if (wParam == h->ch && sub == h->sub)
				{
					send_command(h);
					break;
				}
			break;

		case WM_HOTKEY:
			h = (HotkeyType*)nth_node(m_hotKeys, wParam);
			if (h) send_command(h);
			break;
	}
	return 0;
}

//===========================================================================
int beginPlugin(HINSTANCE hPluginInstance)
{
	if (BBhwnd)
	{
		MessageBox(NULL, "Dont load me twice!", szAppName, MB_OK|MB_TOPMOST|MB_SETFOREGROUND);
		return 1;
	}

	BBhwnd = GetBBWnd();

	if (0 != memicmp(GetBBVersion(), "bbLean", 6))
	{
		MessageBox(NULL, "This bbKeys requires bbLean.", szVersion, MB_OK|MB_TOPMOST|MB_SETFOREGROUND);
		return 1;
	}

	m_hMainInstance = hPluginInstance;

	OSVERSIONINFO osInfo;
	ZeroMemory(&osInfo, sizeof(osInfo));
	osInfo.dwOSVersionInfoSize = sizeof(osInfo);
	GetVersionEx(&osInfo);
	usingNT = osInfo.dwPlatformId == VER_PLATFORM_WIN32_NT;

	WNDCLASS wc;
	ZeroMemory(&wc, sizeof(wc));
	wc.lpfnWndProc = HotkeyProc;            // our window procedure
	wc.hInstance = m_hMainInstance;     
	wc.lpszClassName = szAppName;          // our window class name

	if (!RegisterClass(&wc)) return 1;

	hKeysWnd = CreateWindowEx(
		WS_EX_TOOLWINDOW,       // exstyles
		wc.lpszClassName,       // our window class name
		NULL,                   // use description for a window title
		WS_POPUP,
		0, 0,                   // position
		0, 0,                   // width & height of window
		NULL,                   // parent window
		NULL,                   // no menu
		m_hMainInstance,        // hInstance of DLL
		NULL
		);

	return 0;
}


void endPlugin(HINSTANCE hPluginInstance)
{
	DestroyWindow(hKeysWnd);
	UnregisterClass(szAppName, m_hMainInstance);
	set_kbdhook(false);
}

//===========================================================================
