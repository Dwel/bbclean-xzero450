
    -----------------------------------------------------------------

    bbWorkspaceWheel 0.1.0

    copyright � 2005-2009 grischka@users.sourceforge.net
    http://bb4win.sourceforge.net/bblean


    bbWorkspaceWheel is a plugin for Blackbox for Windows.
    It does workspace switching with the mousewheel.


    bbWorkspaceWheel is free software, released under the
    GNU General Public License (GPL version 2):

            http://www.fsf.org/licenses/gpl.html

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for details.

    -----------------------------------------------------------------

