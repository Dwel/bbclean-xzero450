/*============================================================================

  bbColor_3dc2 is a plugin for Blackbox for Windows
  Copyright � 2002-2009 The Blackbox for Windows Development Team
  Copyright � 2004-2009 grischka

  http://bb4win.sourceforge.net/
  grischka@users.sourceforge.net

  bbColor_3dc2 is free software, released under the GNU General Public License
  (GPL version 2) For details see:

    http://www.fsf.org/licenses/gpl.html

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
  or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
  for more details.

*/

#include "BBApi.h"
#include "../bbPlugin/moreutils.cpp"

//============================================================================
// info

char szVersion     [] = "bbColor_3dc2 2.2";
char szAppName     [] = "bbColor_3dc2";
char szInfoVersion [] = "2.2";
char szInfoAuthor  [] = "TheDevTeam|grischka";
char szInfoRelDate [] = "2009-05-22";
char szInfoLink    [] = "http://bb4win.sourceforge.net/";
char szInfoEmail   [] = "irc://irc.freenode.net/bb4win";
char szInfoUpdateURL [] = "http://www.lostinthebox.com/viewforum.php?t=2968";

//===========================================================================
// global variables

HWND hPluginWnd;
HWND BBhwnd;
HINSTANCE hInstance;
char rcpath[MAX_PATH];
char filename_3dc[MAX_PATH];
char fullkey[64], temp1[64], temp2[64];
char* BBVersion = (char*)bbVersion();

// ----------------------------------
// Plugin window properties
struct dc_properties
{
	// rc.file settings
	int Menus;
	int prMenus;
	int MenuSelect;
	int prMenuSelect;
	int SelectedItem;
	int prSelectedItem;
	int Tooltip;
	int prTooltip;
	bool SetMenus;
	bool SetMenuSelect;
	bool SetSelectedItem;
	bool SetTitles;
	bool SetTooltip;
	// other settings
	bool Append;
} dc;

// declarations
#define COLOR_3DFACEALT 25 //?? the only missing index ...
#define COLOR_MENUBAR 30  /* missing index */
#define COLOR_MENUHILIGHT 29  /* missing index */

// Styles always in use
StyleItem WindowFocusTitle;
StyleItem WindowFocusLabel;
StyleItem WindowUnfocusTitle;
StyleItem WindowUnfocusLabel;
StyleItem WindowFocusGrip;
StyleItem WindowUnfocusGrip;
StyleItem WindowFocusButton;
StyleItem WindowUnfocusButton;
StyleItem Menus;
StyleItem MenuSelect;
StyleItem SelectedItem;
StyleItem Tooltip;
COLORREF BorderColor;
COLORREF WindowFrameFocusColor;
COLORREF WindowFrameUnfocusColor;

bool in_colors_changing;

void syscolor_apply(void);
void syscolor_restore(void);
void syscolor_backup(void);

void syscolor_setcolor(const char * colorspec);
void syscolor_getcolor(const char * colorspec);
void syscolor_write(const char *filename);
void syscolor_read(const char *filename);

LRESULT CALLBACK MsgWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);

//============================================================================
// plugin interface

extern "C"
{
	DLL_EXPORT int beginPlugin(HINSTANCE h_instance)
	{

		hInstance = h_instance;
		BBhwnd = GetBBWnd();

		WNDCLASS wc;
		ZeroMemory(&wc, sizeof(wc));
		wc.lpfnWndProc = MsgWndProc;
		wc.hInstance = h_instance;
		wc.lpszClassName = szAppName;

		ZeroMemory(&dc, sizeof(dc));

		if (FALSE == RegisterClass(&wc) || NULL == CreateWindowEx(
			WS_EX_TOOLWINDOW,
			szAppName,
			NULL,
			WS_POPUP,
			0, 0, 0, 0,
			NULL, //HWND_MESSAGE,
			NULL,
			h_instance,
			NULL
			))
			return 1;

		return 0;
	}

	DLL_EXPORT void endPlugin(HINSTANCE h_instance)
	{
		DestroyWindow(hPluginWnd);
		UnregisterClass(szAppName, hInstance);
	}

	DLL_EXPORT LPCSTR pluginInfo(int field)
	{
		static char *infostr[9] =
		{
			szVersion       , // Fallback: Plugin name + version, e.g. "MyPlugin 1.0"
			szAppName       , // Plugin name
			szInfoVersion   , // Plugin version
			szInfoAuthor    , // Author
			szInfoRelDate   , // Release date, preferably in yyyy-mm-dd format
			szInfoLink      , // Link to author's website
			szInfoEmail     , // Author's email
			(char *)("@bbColor3dc.GetColor <item> <######>"
			"@bbColor3dc.SetColor <item> <######>"
			"@bbColor3dc.Write <path\name>"
			"@bbColor3dc.Read <filename>"
			"@bbColor3dc.SetTooltip"
			"@bbColor3dc.SetTitles"
			"@bbColor3dc.SetSelectedItem"
			"@bbColor3dc.SetMenuSelect"
			"@bbColor3dc.SetMenus"
			"@bbColor3dc.Append"
			"@bbColor3dc.Clear"
			"@bbColor3dc.Keep"),
			szInfoUpdateURL  // Link to update page
		};
		return (field >= 0 && field < 9) ? infostr[field] : infostr[0];
	}
};

//===========================================================================

int set_param(WPARAM wParam, LPARAM lParam, const char *p, const char *arg)
{
    int l = p - (LPCSTR)lParam;
    memcpy((char *)wParam, (LPCSTR)lParam, l);
    strcpy((char *)wParam + l, arg);
    return 0;
}

//===========================================================================
LRESULT CALLBACK MsgWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    static int bb_msgs[] = { BB_RECONFIGURE, BB_EXITTYPE, BB_BROADCAST, 0 };

    switch(msg)
    {
        case WM_CREATE:
            hPluginWnd = hwnd;
            SendMessage(BBhwnd, BB_REGISTERMESSAGE, (WPARAM)hwnd, (LPARAM)bb_msgs);
            syscolor_backup();
            syscolor_apply();
            break;

        case BB_RECONFIGURE:
            syscolor_apply();
            break;

        case WM_DESTROY:
            SendMessage(BBhwnd, BB_UNREGISTERMESSAGE, (WPARAM)hwnd, (LPARAM)bb_msgs);
            syscolor_restore();
            break;

        case BB_EXITTYPE:
            if (B_SHUTDOWN == wParam)
                syscolor_restore();
            break;

        case BB_GETBOOL:
            if (0 == memicmp((LPCSTR)lParam, "@bbColor3dc.", 12))
            {
                const char *msg_string = (LPCSTR)lParam + 12;
                if (0 == n_stricmp(&msg_string, "Read"))
                {
                    set_param(wParam, lParam, msg_string, filename_3dc);
                    return 1;
                }
            }
            break;

        case BB_BROADCAST:
            if (0 == memicmp((LPCSTR)lParam, "@bbColor3dc.", 12))
            {
                const char *msg_string = (LPCSTR)lParam + 12;
                if (0 == n_stricmp(&msg_string, "Read"))
                {
                    syscolor_read(msg_string);
                    break;
                }
                if (0 == n_stricmp(&msg_string, "Keep"))
                {
                    syscolor_backup();
                    break;
                }
                if (0 == n_stricmp(&msg_string, "Write"))
                {
                    syscolor_write(msg_string);
                    break;
                }
				if (0 == n_stricmp(&msg_string, "Append"))
				{
					dc.Append = true;
					syscolor_write(stylePath());
					dc.Append = false;
					break;
				}
                if (0 == stricmp(msg_string, "Clear"))
                {
                    syscolor_restore();
                    break;
                }
                if (0 == n_stricmp(&msg_string, "SetColor"))
                {
                    syscolor_setcolor(msg_string);
                    break;
                }
                if (0 == n_stricmp(&msg_string, "GetColor"))
                {
                    syscolor_getcolor(msg_string);
                    break;
                }
				if (0 == n_stricmp(&msg_string, "SetMenus"))
                {
					WriteBool(rcpath, "bbColor3dc.SetMenus:", dc.SetMenus ? false : true);
					SendMessage(BBhwnd, BB_RECONFIGURE, 0, 0);
                    break;
                }
				if (0 == n_stricmp(&msg_string, "SetMenuSelect"))
                {
					WriteBool(rcpath, "bbColor3dc.SetMenuSelect:", dc.SetMenuSelect ? false : true);
					SendMessage(BBhwnd, BB_RECONFIGURE, 0, 0);
                    break;
                }
				if (0 == n_stricmp(&msg_string, "SetSelectedItem"))
                {
					WriteBool(rcpath, "bbColor3dc.SetSelectedItem:", dc.SetMenuSelect ? false : true);
					SendMessage(BBhwnd, BB_RECONFIGURE, 0, 0);
                    break;
                }
				if (0 == n_stricmp(&msg_string, "SetTitles"))
                {
					WriteBool(rcpath, "bbColor3dc.SetTitles:", dc.SetTitles ? false : true);
					SendMessage(BBhwnd, BB_RECONFIGURE, 0, 0);
                    break;
                }
				if (0 == n_stricmp(&msg_string, "SetTooltip"))
                {
					WriteBool(rcpath, "bbColor3dc.SetTooltip:", dc.SetTooltip ? false : true);
					SendMessage(BBhwnd, BB_RECONFIGURE, 0, 0);
                    break;
                }
            }
            break;

        default:
            return DefWindowProc(hwnd, msg, wParam, lParam);
    }
    return 0;
}

//===========================================================================
void *xGetSettingPtr(int id)
{
	const char *style = stylePath();
    static StyleItem SI;
	if ((id < 22) || (strlen(BBVersion) != 7))
	{
		SI = *(StyleItem *)GetSettingPtr(id);
		ParseItem(style, &SI);
		if (!SI.parentRelative)
			return GetSettingPtr(id);
		else
		{
			if (id < 8)
				return GetSettingPtr(1);
			if (id < 10)
				return GetSettingPtr(8);
			if (id == 22 || id == 28)
				return GetSettingPtr(1);
			if (id < 27)
				return GetSettingPtr(22);
			if (id < 33)
				return GetSettingPtr(28);
		}
	}

    const char *key;
	char focusColorAsString[32], unfocusColorAsString[32];    
    static DWORD dw_result;
    switch (id)
    {
		case SN_WINFOCUS_TITLE      : key = "window.title.focus"; break;
		case SN_WINFOCUS_LABEL      : key = "window.label.focus"; break;
		case SN_WINFOCUS_HANDLE     : key = "window.handle.focus"; break;
		case SN_WINFOCUS_GRIP       : key = "window.grip.focus"; break;
		case SN_WINFOCUS_BUTTON     : key = "window.button.focus"; break;
		case SN_WINFOCUS_BUTTONP    : key = "window.button.pressed.focus"; break;
		case SN_WINUNFOCUS_TITLE    : key = "window.title.unfocus"; break;
		case SN_WINUNFOCUS_LABEL    : key = "window.label.unfocus"; break;
		case SN_WINUNFOCUS_HANDLE   : key = "window.handle.unfocus"; break;
		case SN_WINUNFOCUS_GRIP     : key = "window.grip.unfocus"; break;
		case SN_WINUNFOCUS_BUTTON   : key = "window.button.unfocus"; break;
		case SN_WINFOCUS_FRAME_COLOR : 
			strcpy(temp1, ReadString(style, "window.frame.focus.borderColor:", "0x000000"));
			strcpy(temp2, ReadString(style, "window.frame.focus.color:", temp1));
			strcpy(focusColorAsString, ReadString(style, "window.frame.focusColor:", temp2));
			dw_result = ReadColor(style, fullkey, focusColorAsString);
			return &dw_result;
		case SN_WINUNFOCUS_FRAME_COLOR : 
			strcpy(temp1, ReadString(style, "window.frame.unfocus.borderColor:", "0x000000"));
			strcpy(temp2, ReadString(style, "window.frame.unfocus.color:", temp1));
			strcpy(unfocusColorAsString, ReadString(style, "window.frame.unfocusColor:", temp2));
			dw_result = ReadColor(style, fullkey, unfocusColorAsString);
			return &dw_result;

        default: return NULL;
    }
    get_style(style, &SI, key);
    return &SI;
}

///===========================================================================
struct colors_style { int id; COLORREF cr; };

void set_gradient_colors(struct colors_style *cs, StyleItem *si)
{
	cs[0].cr = si->Color;
	cs[1].cr = si->type == B_SOLID ? si->Color : si->ColorTo;
	cs[2].cr = si->TextColor;
}

void set_flat_colors(struct colors_style *cs, StyleItem *si)
{
	cs[0].cr = si->borderColor;
	cs[1].cr = si->TextColor;
}

void check_colours(StyleItem *si, bool noText)
{
	si->borderColor = si->type == B_SOLID ? si->Color : mixcolors(si->Color, si->ColorTo, 192);
	if (!noText)
		si->TextColor = FuzzyMatch(si->borderColor, si->TextColor) ? Settings_CreateShadowColor(si ->TextColor) : si->TextColor;
}

struct styleprop { const char *key; int val; int pr;};

		static struct styleprop validStyles[] = {
			{ "ToolbarButtonPressed"    ,  3 ,  1 },
			{ "ToolbarButton"			,  2 ,  1 },
			{ "ToolbarWindowLabel"		,  5 ,  1 },
			{ "ToolbarLabel"			,  4 ,  1 },
			{ "ToolbarClock"			,  6 ,  1 },
			{ "Toolbar"					,  1 ,  8 },
			{ "MenuTitle"				,  7 ,  8 },
			{ "MenuFrame"				,  8 ,  8 },
			{ "MenuHilite"				,  9 ,  8 },
			{ "WindowFocusTitle"		, 22 ,  1 },
			{ "WindowFocusLabel"		, 23 , 22 },
			{ "WindowFocusHandle"		, 24 , 22 },
			{ "WindowFocusGrip"			, 25 , 22 },
			{ "WindowFocusButtonPressed", 27 , 22 },
			{ "WindowFocusButton"		, 26 , 22 },
			{ "WindowUnfocusTitle"		, 28 ,  1 },
			{ "WindowUnfocusLabel"		, 29 , 28 },
			{ "WindowUnfocusHandle"		, 30 , 28 },
			{ "WindowUnfocusGrip"		, 31 , 28 },
			{ "WindowUnfocusButton"		, 32 , 28 },
			{NULL						,  8 ,  8 }
		};

static int check_item(const char *p, struct styleprop *s, bool pr)
{
    do if (stristr(p, s->key)) break; while ((++s)->key);
	if (!pr)
		return s->val;
	else
		return s->pr;
}

void get_style_colors (COLORREF *cr_buffer)
{

	locate_file(hInstance, rcpath, szAppName, "rc");

	dc.SetMenus			= ReadBool(rcpath, "bbColor3dc.SetMenus:", true);
	dc.SetMenuSelect	= ReadBool(rcpath, "bbColor3dc.SetMenuSelect:", true);
	dc.SetSelectedItem	= ReadBool(rcpath, "bbColor3dc.SetSelectedItem:", true);
	dc.SetTitles		= ReadBool(rcpath, "bbColor3dc.SetTitles:", false);
	dc.SetTooltip		= ReadBool(rcpath, "bbColor3dc.SetTooltip:", true);


	if (dc.SetMenus)
	{
		dc.Menus			= check_item(ReadString(rcpath, "bbColor3dc.Menus:", "MenuFrame"), validStyles, false);
		Menus				= *(StyleItem*)xGetSettingPtr(dc.Menus);
		check_colours(&Menus, false);
	}
	if (dc.SetMenuSelect)
	{
		dc.MenuSelect		= check_item(ReadString(rcpath, "bbColor3dc.MenuSelect:", "MenuTitle"), validStyles, false);
		MenuSelect			= *(StyleItem*)xGetSettingPtr(dc.MenuSelect);
		check_colours(&MenuSelect, false);
		if (FuzzyMatch(MenuSelect.borderColor, Menus.borderColor))
		{
			MenuSelect.borderColor = MenuSelect.TextColor;
			MenuSelect.TextColor = Menus.borderColor;
		}
	}
	if (dc.SetSelectedItem)
	{
		dc.SelectedItem		= check_item(ReadString(rcpath, "bbColor3dc.SelectedItem:", "MenuHilite"), validStyles, false);
		SelectedItem		= *(StyleItem*)xGetSettingPtr(dc.SelectedItem);
		check_colours(&SelectedItem, false);
		if (FuzzyMatch(SelectedItem.borderColor, Menus.borderColor))
		{
			SelectedItem.borderColor = SelectedItem.TextColor;
			SelectedItem.TextColor = Menus.borderColor;
		}
	}
	if (dc.SetTitles)
	{
		WindowFocusTitle		= *(StyleItem*)xGetSettingPtr(SN_WINFOCUS_TITLE);  
		check_colours(&WindowFocusTitle, true);
		WindowFocusLabel		= *(StyleItem*)xGetSettingPtr(SN_WINFOCUS_LABEL);  
		check_colours(&WindowFocusLabel, false);
		WindowUnfocusTitle		= *(StyleItem*)xGetSettingPtr(SN_WINUNFOCUS_TITLE);  
		WindowUnfocusLabel		= *(StyleItem*)xGetSettingPtr(SN_WINUNFOCUS_LABEL);  
		check_colours(&WindowUnfocusLabel, false);
		WindowFocusGrip			= *(StyleItem*)xGetSettingPtr(SN_WINFOCUS_GRIP);  
		check_colours(&WindowFocusGrip, true);
		WindowUnfocusGrip		= *(StyleItem*)xGetSettingPtr(SN_WINUNFOCUS_GRIP);  
		check_colours(&WindowUnfocusGrip, true);
		WindowFocusButton		= *(StyleItem*)xGetSettingPtr(SN_WINFOCUS_BUTTON);  
		check_colours(&WindowFocusButton, false);
		WindowUnfocusButton		= *(StyleItem*)xGetSettingPtr(SN_WINUNFOCUS_BUTTON);  
		check_colours(&WindowUnfocusButton, false);
		WindowFrameFocusColor	= *(COLORREF*) xGetSettingPtr(SN_WINFOCUS_FRAME_COLOR);
		WindowFrameUnfocusColor	= *(COLORREF*) xGetSettingPtr(SN_WINUNFOCUS_FRAME_COLOR);
	}
	if (dc.SetTooltip)
	{
		dc.Tooltip			= check_item(ReadString(rcpath, "bbColor3dc.Tooltip:", "WindowFocusButton"), validStyles, false);
		Tooltip				= *(StyleItem*)xGetSettingPtr(dc.Tooltip);
		check_colours(&Tooltip, false);
		BorderColor			= *(COLORREF*) GetSettingPtr(SN_BORDERCOLOR);
	}

    static struct colors_style colors_style [] =
    {
			{ COLOR_3DDKSHADOW		        , 0 },  // 0
			{ COLOR_3DSHADOW			    , 0 },
			{ COLOR_3DFACE					, 0 }, 
			{ COLOR_3DLIGHT					, 0 },  
			{ COLOR_3DHIGHLIGHT			    , 0 },

			{ COLOR_ACTIVECAPTION           , 0 },  // 5
			{ COLOR_GRADIENTACTIVECAPTION   , 0 },  
			{ COLOR_CAPTIONTEXT             , 0 },  
			{ COLOR_ACTIVEBORDER            , 0 },  // 8

			{ COLOR_BTNTEXT					, 0 },  // 9
			{ COLOR_WINDOWFRAME             , 0 }, 
			{ COLOR_GRAYTEXT				, 0 },  

			{ COLOR_INACTIVECAPTION         , 0 },  // 12
			{ COLOR_GRADIENTINACTIVECAPTION , 0 },  
			{ COLOR_INACTIVECAPTIONTEXT     , 0 },  
			{ COLOR_INACTIVEBORDER          , 0 },  // 15

			{ COLOR_MENU                    , 0 },  // 16
			{ COLOR_MENUTEXT                , 0 },  

			{ COLOR_HOTLIGHT			    , 0 },  // 18

			{ COLOR_HIGHLIGHT               , 0 },  // 19
			{ COLOR_HIGHLIGHTTEXT           , 0 },

			{ COLOR_INFOBK                  , 0 },  // 21
			{ COLOR_INFOTEXT                , 0 },

			{ COLOR_WINDOW					, 0 },  // 23
			{ COLOR_WINDOWTEXT				, 0 },

			{ COLOR_MENUBAR			        , 0 },  // 25
			{ COLOR_MENUHILIGHT             , 0 }
    };

    const int NSTYLES = array_count(colors_style);

    // -----------------------------------
    int i;
    for (i = 0; i < NSTYLES; i++)
        colors_style[i].cr = (COLORREF)-1;

	if (dc.SetMenus)
	{
		colors_style[0].cr = WindowFocusButton.borderColor;
		colors_style[1].cr = WindowUnfocusGrip.borderColor;

		colors_style[2].cr = Menus.borderColor;

		colors_style[3].cr = WindowUnfocusButton.borderColor;
		colors_style[4].cr = WindowFocusGrip.borderColor;
	}

	if (dc.SetTitles)
	{
		set_gradient_colors(colors_style+5, &WindowFocusLabel);

		colors_style[8].cr = WindowFrameFocusColor;
	}

	if (dc.SetMenus)
		colors_style[9].cr = Menus.TextColor;

	if (dc.SetTooltip)
		colors_style[10].cr = BorderColor;

	if (dc.SetMenuSelect)
		colors_style[11].cr = MenuSelect.borderColor;

	if (dc.SetTitles)
	{
		set_gradient_colors(colors_style+12, &WindowUnfocusLabel);

		colors_style[15].cr = WindowFrameUnfocusColor;
	}

	if (dc.SetMenus)
		set_flat_colors(colors_style+16, &Menus);
	if (dc.SetMenuSelect)
		colors_style[18].cr = MenuSelect.borderColor;
	if (dc.SetSelectedItem)
		set_flat_colors(colors_style+19, &SelectedItem);
	if (dc.SetTooltip)
		set_flat_colors(colors_style+21, &Tooltip);
	if (dc.SetMenus)
		set_flat_colors(colors_style+23, &Menus);
	if (dc.SetMenuSelect)
		set_flat_colors(colors_style+25, &MenuSelect);

    // -----------------------------------
    for (i = 0; i < NSTYLES; i++)
        if ((COLORREF)-1 != colors_style[i].cr)
            cr_buffer[colors_style[i].id] = colors_style[i].cr;
}

//===========================================================================
static char color_trans_3dcc [] =
{
    COLOR_3DDKSHADOW                , // 21
    COLOR_3DSHADOW                  , // 16
    COLOR_3DFACE                    , // 15     nonclient surfaces
    COLOR_3DFACEALT                 , // 25     ??
    COLOR_3DLIGHT                   , // 22
    COLOR_3DHIGHLIGHT               , // 20

    COLOR_ACTIVECAPTION             , //  2     active caption
    COLOR_GRADIENTACTIVECAPTION     , // 27
    COLOR_CAPTIONTEXT               , //  9
    COLOR_ACTIVEBORDER              , // 10

    COLOR_APPWORKSPACE              , // 12
    COLOR_BTNTEXT                   , // 18
    COLOR_DESKTOP                   , //  1
    COLOR_WINDOWFRAME               , //  6     tooltip border
    COLOR_GRAYTEXT                  , // 17

    COLOR_INACTIVECAPTION           , //  3     in-active caption
    COLOR_GRADIENTINACTIVECAPTION   , // 28
    COLOR_INACTIVECAPTIONTEXT       , // 19
    COLOR_INACTIVEBORDER            , // 11

    COLOR_MENU                      , //  4     menu
    COLOR_MENUTEXT                  , //  7

    COLOR_HOTLIGHT                  , // 26
    COLOR_SCROLLBAR                 , //  0

    COLOR_HIGHLIGHT                 , // 13     hilited items (menu, list control etc...)
    COLOR_HIGHLIGHTTEXT             , // 14

    COLOR_INFOBK                    , // 24     tooltip
    COLOR_INFOTEXT                  , // 23

    COLOR_WINDOW                    , //  5
    COLOR_WINDOWTEXT                , //  8

	COLOR_MENUBAR					, // 30		(per MSDN)
	COLOR_MENUHILIGHT				  // 29		(per MSDN)
};

const int NCOLORS = array_count(color_trans_3dcc);

//===========================================================================

bool parse_3dc(FILE *fp, COLORREF *cr_buffer)
{
    char *trans = color_trans_3dcc; int i = 0; char line[256];
    while (fgets(line, sizeof line, fp))
    {
        // trim trailing stuff
        char *se = strchr(line, '\0');
        while (se > line && (unsigned char)se[-1] <= 32) se--;
        *se = 0;

        if (false == (line[0]>='0' && line[0]<='9'))
            break;

		switch (i)
		{
			case  0: if (!dc.SetMenus) break;
			case  1: if (!dc.SetMenus) break;
			case  2: if (!dc.SetMenus) break;
			case  4: if (!dc.SetMenus) break;
			case  5: if (!dc.SetMenus) break;
			case  6: if (!dc.SetTitles) break;
			case  7: if (!dc.SetTitles) break;
			case  8: if (!dc.SetTitles) break;
			case  9: if (!dc.SetTitles) break;
			case 11: if (!dc.SetTitles) break;
			case 13: if (!dc.SetTooltip) break;
			case 14: if (!dc.SetMenuSelect) break;
			case 15: if (!dc.SetTitles) break;
			case 16: if (!dc.SetTitles) break;
			case 17: if (!dc.SetTitles) break;
			case 18: if (!dc.SetTitles) break;
			case 19: if (!dc.SetMenus) break;
			case 20: if (!dc.SetMenus) break;
			case 21: if (!dc.SetMenuSelect) break;
			case 23: if (!dc.SetSelectedItem) break;
			case 24: if (!dc.SetSelectedItem) break;
			case 25: if (!dc.SetTooltip) break;
			case 26: if (!dc.SetTooltip) break;
			case 27: if (!dc.SetMenus) break;
			case 28: if (!dc.SetMenus) break;
			case 29: if (!dc.SetMenuSelect) break;
			case 30: if (!dc.SetMenuSelect) break;
			default: cr_buffer[(unsigned char)*trans] = atoi(line);
	    }

        if (++i == NCOLORS)
            break;

        ++trans;
    }
    fclose(fp);
    return i >= NCOLORS-5;
}

//===========================================================================
// try to read it from the style itself;
// search for a commentline containing "3dc" and "start" or the stylename
// example: "! --- file.3dc - start ---"

bool read_from_style(const char *filename_3dc, COLORREF *cr_buffer)
{
    bool result = false;
    FILE *fp = fopen(stylePath(), "rb");
    if (fp)
    {
        char line[1000];
        while (fgets(line, sizeof line, fp))
        {
            if (('!' == *line || '#' == *line)
                && strstr(strlwr(line), "3dc")
                && (strstr(line, filename_3dc) || strstr(line, "start"))
                && !strstr(line, "rootcommand:")

                && parse_3dc(fp, cr_buffer)
                )
            {
                //dbg_printf("found 3dc in style %s", stylePath());
                result = true;
                break;
            }
        }
        fclose(fp);
    }
    return result;
}

//===========================================================================
// read from separate .3DC file

bool read_from_file(const char *path, const char *filename_3dc, COLORREF *cr_buffer)
{
    char buffer[MAX_PATH];
    buffer[0] = 0;
    if (path && *path) strcat(strcpy(buffer, path), "\\");
    strcat(buffer, filename_3dc);

    bool result = false;

    char full_path[MAX_PATH];
    FILE *fp = fopen(make_full_path(NULL, full_path, buffer), "rb");
    //dbg_printf("open %s %s", fp?"success":"failed", full_path);
    if (fp) { result = parse_3dc(fp, cr_buffer); fclose(fp); }
    return result;
}

//===========================================================================

bool read_3dc(COLORREF *cr_buffer)
{
    char style_path[MAX_PATH];
    char filename_3dc[MAX_PATH];

    strlwr(strcpy(style_path, stylePath()));

    char *dot = strrchr(style_path, '.');
    char *bsl = strrchr(style_path, '\\');
    char *fsl = strrchr(style_path, '/');
    char *eos = strchr(style_path, '\0');
    // use '/' when found and more to the right
    if (fsl > bsl) bsl = fsl;
    // when no extension was specified...
    if (dot <= bsl) dot = eos;

    // replace/add extension
    strcpy(dot, ".3dc");

    if (bsl)
    {
        strcpy(filename_3dc, bsl+1);
        *bsl = 0;
    }
    else
    {
        strcpy(filename_3dc, style_path);
        style_path[0] = 0;
    }

    if (read_from_style(filename_3dc, cr_buffer))
        return true;

    if (read_from_file(style_path, filename_3dc, cr_buffer))
        return true;

    strcat(style_path, "\\3dc");

    if (read_from_file(style_path, filename_3dc, cr_buffer))
        return true;

    if (read_from_file("3dc", filename_3dc, cr_buffer))
        return true;


    return false;
}

//===========================================================================
static COLORREF cr_original[NCOLORS];
static int cr_ids[NCOLORS];
static int colors_changed;

void syscolor_backup(void)
{
    int n = 0;
    do cr_original[cr_ids[n] = n] = GetSysColor(n); while (++n<NCOLORS);
    colors_changed = 0;
}

void syscolor_restore(void)
{
    if (0 == colors_changed) return;

    COLORREF cr_buffer[NCOLORS];
    memmove(cr_buffer, cr_original, sizeof cr_buffer);
    in_colors_changing = true;
    SetSysColors(NCOLORS, cr_ids, cr_buffer);
    in_colors_changing = false;
    colors_changed = 0;
}

void syscolor_apply(void)
{
    if (3 == colors_changed) return;

    COLORREF cr_buffer[NCOLORS];

    memmove(cr_buffer, cr_original, sizeof cr_buffer);
    if (read_3dc(cr_buffer)) // set colors from 3DCC file
    {
        colors_changed = 2;
    }
    else
    {
        memmove(cr_buffer, cr_original, sizeof cr_buffer);
        get_style_colors(cr_buffer);  // set colors from style
        colors_changed = 1;
    }
    in_colors_changing = true;
    SetSysColors(NCOLORS, cr_ids, cr_buffer);
    in_colors_changing = false;
}

//===========================================================================

const char *color_item_strings[] =
{
    "3DDKSHADOW",
    "3DSHADOW",
    "3DFACE",
    "3DFACEALT",
    "3DLIGHT",
    "3DHIGHLIGHT",

    "ACTIVECAPTION",
    "GRADIENTACTIVECAPTION",
    "CAPTIONTEXT",
    "ACTIVEBORDER",

    "APPWORKSPACE",
    "BTNTEXT",
    "DESKTOP",
    "WINDOWFRAME",
    "GRAYTEXT",

    "INACTIVECAPTION",
    "GRADIENTINACTIVECAPTION",
    "INACTIVECAPTIONTEXT",
    "INACTIVEBORDER",

    "MENU",
    "MENUTEXT",

    "HOTLIGHT",
    "SCROLLBAR",

    "HIGHLIGHT",
    "HIGHLIGHTTEXT",

    "INFOBK",
    "INFOTEXT",

    "WINDOW",
    "WINDOWTEXT",

    "MENUBAR",
    "MENUHILIGHT",

    NULL
};


//===========================================================================
void syscolor_getcolor(const char * p)
{
    const char **cs = color_item_strings; int n = 0;
    do { if (0 == n_stricmp(&p, *cs)) break; ++n; } while (*++cs);

    if (NULL == *cs || '@' != *p) return;

    char color[40];
    sprintf(color, "#%06x", (int)switch_rgb(GetSysColor(color_trans_3dcc[n])));

    char buffer[256];
    sprintf(buffer, p, color);

    SendMessage(BBhwnd, BB_BROADCAST, 0, (LPARAM)&buffer);
}

void syscolor_write(const char *filename)
{
	char path_to_3dc[MAX_PATH], temp[64];
	FILE *fp; 
	if (!dc.Append) 
		fp = fopen(make_full_path(NULL, path_to_3dc, (const char *)strcat((char *)filename, ".3dc")), "wt");
	else
	{
		fp = fopen(make_full_path(NULL, path_to_3dc, filename), "a+t");
		strcpy(temp, ReadString(rcpath, "bbColor_3dc2.dcAuthor:", "bbColor"));
		if (!IsInString(temp, "bbColor"))
			strcat(temp, " ");
		fprintf(fp, "\n!--- %s3dc settings start ---\n", temp);
	}
	if (fp)
	{
		int n = 0;
		do {
            COLORREF c = GetSysColor(color_trans_3dcc[n]);
        #if 1
            fprintf(fp, "%lu\n", (unsigned long) c);
        #else
            fprintf(fp, "%-12u ;#%06X ;%s\n",
                c, switch_rgb(c), color_item_strings[n]);
        #endif
		} while (++n<NCOLORS);
		fclose(fp);
	}
}

void syscolor_read(const char *filename_3dc)
{
    COLORREF cr_buffer[NCOLORS];
    memmove(cr_buffer, cr_original, sizeof cr_buffer);

    if (false == read_from_file(NULL, filename_3dc, cr_buffer))
        return;

    colors_changed = 3;

    SetSysColors(NCOLORS-1, cr_ids, cr_buffer);
}


void syscolor_setcolor(const char * p)
{
    const char **cs = color_item_strings;
    int n = 0;
    COLORREF c;
    int id;

    do { if (0 == n_stricmp(&p, *cs)) break; ++n; } while (*++cs);
    if (NULL == *cs) return;
    if (0 == sscanf(p, "#%lx", &c)) return;
    c = switch_rgb(c);
    id = color_trans_3dcc[n];
    SetSysColors(1, &id, &c);
    colors_changed = 2;
}

//===========================================================================
void set_bbi_slider1 (const char *color, unsigned val)
{
    char buffer[100];
    sprintf(buffer,
        "@BBInterface Control SetControlProperty "
        "3DCSlider_%s Value %d.%03d", color, val/255, val%255*1000/255);
    SendMessage(BBhwnd, BB_BROADCAST, 0, (LPARAM)buffer);
}

void set_bbi_sliders(COLORREF c)
{
    set_bbi_slider1("Red", GetRValue(c));
    set_bbi_slider1("Green", GetGValue(c));
    set_bbi_slider1("Blue", GetBValue(c));
}

void set_bbi_label (int item, COLORREF c)
{
    char buffer[100];
    sprintf(buffer,
        "@BBInterface Control SetAgent 3DC_Label Caption StaticText "
        "\"#%06lX %s\"",
        switch_rgb(c),
        item < 0 ? "" : color_item_strings[item]
        );
    SendMessage(BBhwnd, BB_BROADCAST, 0, (LPARAM)buffer);
}

int syscolor_handle_bbi_message(const char * p)
{
    static int item_set;
    static COLORREF item_color;
    static COLORREF mem_color;

    COLORREF c; int n, id;

    if (0 == n_stricmp(&p, "SetRed")) {
        n = 0;
        goto setrgb;
    }
    else
    if (0 == n_stricmp(&p, "SetGreen")) {
        n = 8;
        goto setrgb;
    }
    else
    if (0 == n_stricmp(&p, "SetBlue")) {
        n = 16;
        goto setrgb;
    }
    else
    if (0 == n_stricmp(&p, "SetItem")) {
        item_set = 0;

        const char **cs = color_item_strings;
        n = 0;
        do {
            ++n;
            if (0 == stricmp(p, *cs)) {
                item_set = n;
                break;
            }
        } while (*++cs);

        if (item_set > 0)
        {
            item_color = c = GetSysColor(color_trans_3dcc[item_set-1]);
            set_bbi_sliders(c);
            set_bbi_label(item_set-1, c);
        }
        return 1;
    }
    else
    if (0 == n_stricmp(&p, "MSto")) {
        mem_color = item_color;
        return 1;
    }
    else
    if (0 == n_stricmp(&p, "MGet")) {
        item_color = mem_color;
        set_bbi_sliders(item_color);
        goto setrgb_2;
    }
    else
    if (0 == n_stricmp(&p, "Load")) {
        syscolor_read(p);
        colors_changed = 2;
        if (item_set > 0)
        {
            item_color = c = GetSysColor(color_trans_3dcc[item_set-1]);
            set_bbi_sliders(c);
            set_bbi_label(item_set-1, c);
        }
        return 1;
    }
    else
        return 0;


setrgb:
    c = atoi(p);
    c = (item_color & ~(255<<n)) | c<<n;
    if (item_color == c)
        return 1;
    item_color = c;

setrgb_2:
    if (item_set > 0) {
        id = color_trans_3dcc[item_set-1];
        SetSysColors(1, &id, &item_color);
        colors_changed = 2;
    }
    set_bbi_label(item_set-1, item_color);

    return 1;
}

//===========================================================================
