#define HIST_SIZE 500
#define ALI_SIZE 250
#define N_REGEXS 400
#pragma warning(disable : 4996)
#pragma comment (lib, "blackbox.lib")
#include "BBApi.h"
#include "pcre.h"
#include "pcrs.h"

#ifdef __BORLANDC__
#define _stricmp stricmp
#endif

#ifdef MAX_LINE_LENGTH
    #undef MAX_LINE_LENGTH
#endif
#define MAX_LINE_LENGTH 4096

class trie
{
public:
  trie (void)
  {
    for (int i = 0; i < 128; i++)
      this->ptrs[i] = NULL;
    this->val = NULL;
    this->n = 0;
  }

  int GetN (void)
  {
    return n;
  }

  void ReturnJoinedString (char *str, char *init)
  {
    char tmp[400];
	if (strlen(init) >= sizeof tmp)
		return;
    strcpy (tmp, init);

    if (val != NULL)
      {
        strcat (str, init);
        strcat (str, ": ");
        strcat (str, val);
        strcat (str, "\r\n");
      }
    for (int i = 0; i < 128; i++)
      {
        strcpy (tmp, init);
        char t[5];
        sprintf (t, "%c", i);
        strcat (tmp, t);

        if (ptrs[i] != NULL)
          ptrs[i]->ReturnJoinedString (str, tmp);
      }
  }

  char *GetString (char *str)
  {
    strlwr (str);
    return RecGetString (str);
  }

  char *RecGetString (char *str)
  {
    strlwr (str);
    if (*str)
      {
        if (*str >= 0 && *str < 128)
          if (this->ptrs[*str])
            return this->ptrs[*str]->GetString (str + 1);
          else
            return NULL;
        else
          return NULL;
      }
    else
      return this->val;
  }

  void AddString (char *str, char *val)
  {
    strlwr (str);
    RecAddString (str, val);
  }

  void RecAddString (char *str, char *val)
  {
    char c = *str;
    if (c)
      {
        if (c >= 0 && c < 128)
          {
           

            if (this->ptrs[c] == NULL)
              this->ptrs[c] = new trie;

            ptrs[c]->AddString (str + 1, val);
          }
      }
    else
      {
	//	  if (this->val != NULL)
     //     LocalFree (this->val);
        this->val = strdup (val);
        this->n++;
      }
  }

private:
  class trie * ptrs[128];
  char *val;
  int n;
};

class StrList;

class StrList
{
public:
  char *str;
  StrList *next;
  StrList *head;

  StrList(char *str)
  {
	this->str = str;
	next = NULL;
	this->head = this;
  }

  void AddElement(char *str)
  {
	    if(strlen(str)>1 && str[strlen(str)-1]=='\n')
			str[strlen(str)-1] = 0;
		StrList *nxt = new StrList(str);
		nxt->next = this;
		this->head = nxt;
  }
};

class Broambox
{
public:
  HWND hEditWnd;
  HWND hSlit;
  bool shown;
  int x, y, width, height;
  WNDPROC wpEditProc;
  void AddAlias (char *alias, char *expands);
  COLORREF textColor;
  bool useAutoHide;
  HANDLE LastACHandle;
  void AutoCompletePath (char *path);
  void SaveSettings(void);
  void ShowAliases();
  void ShowRegexs();
  void ShowVariables();
  Broambox (HINSTANCE, HWND);
  bool CreateBroambox ();
  void DestroyBroambox ();
  void PaintBroambox (HDC, LPRECT);
  void ReadSettings ();
  void ReplaceFont ();

  void ShowWindow ();
  void ShowWindowAt (int x, int y);
  void HideWindow ();
  void SizeBroambox ()
  {
	  MoveWindow (hEditWnd, x, y, width, height, TRUE);
	  ShowWindow ();
  }

  void EnterSlit ();
  void UpdateSlit ();
  bool InSlit ()
  {
	  return (inSlit && (hSlit != NULL));
  }
  void ToggleSlitAutoHide (bool getSetting)
  {
	  getSetting; //Avoid warning
	  return;
  }
  void ToggleInSlit ()
  {
	  if (hSlit == NULL)
		  return;
	  if (InSlit ())
		  ShowWindowAt(x, y);
	  else
		  EnterSlit ();
  }
  void Execute ();
  void HistoryPrev ();
  void HistoryNext ();

  LRESULT LButtonDown (HWND, UINT, WPARAM, LPARAM);
  LRESULT RButtonDown (HWND, UINT, WPARAM, LPARAM);

  HINSTANCE hMainInst;
  void AutoCompleteNext (char *str, int istab);
  void AutoCompletePrev (char *str);
  void AutoCompleteReset ();
  void GetVarValue (char *varname, char *varvalue);
  void WriteAlias (char *name);
  char localDir[MAX_PATH];
  HWND hBB4Win;
  int stylePtr;
  bool sameBorder;
  int bevelStyle;
  int alpha;
  char location[8];
  
  bool use_regexs;
  bool regex_debug;
  bool inSlit;
  bool is_xoblite;
private:
  trie *AliasTrie;
  trie *VarTrie;
  StrList *RegexList;
  pcre *var_match;
  pcre_extra *var_extra;
  pcre *urlre;
  pcre_extra *urlre_extra;
  pcrs_job *regexs[N_REGEXS];

  int nAli;
  char alias_names[ALI_SIZE][200];
  char alias_vals[ALI_SIZE][600];
  int n_regex;
  void ShowString(char *str);
  void ShowTrie(trie *tr);
  void SetupVariables(void);
  void ReadAliases(void);
  void ReadAliasesEx(void);
  void ReadHistory(void);
  void ExpandAlias (char *ret_val, char *alias_val, char *remaining,
		    char *args);
  void ExpandAliases (char *buf, char *args);
  void ExpandVariable (char *str, int len);
  void ExpandVariables (char *buf, char *args);
  int ParseVariable (char *varstr);
  void ParseEnvironmentVariables ();
  void AddVariable (char *var, char *expands);
  void ExpandRegexs (char *buf, char **out);
  void FindRegexs (char *regex);
  
  void AutoComplete (char *text);
  void reverseHistory ();
  int lastTabCompleteIndex;

  void SetWinFont (HWND win, HFONT font);
  HFONT aliasFont;
  HFONT hEditFont;

  bool tempSlit;
  bool isSlitAutoHide;

  StyleItem *mainStyle;
  StyleItem *editStyle;
  void DisplayMenu(bool popup);

  int bevelWidth, borderWidth;
  int fontHeight;
  int historyIndex;
  int historyCount;
  char history[HIST_SIZE][500];
};
