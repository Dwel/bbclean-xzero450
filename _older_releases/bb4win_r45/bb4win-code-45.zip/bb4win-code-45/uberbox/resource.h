//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by alias.rc
//
#define IDCANCEL2                       3
#define AliasDlg                        101
#define AliasEdit                       1001
#define StaticText                      1002
#define AliasEdit2                      1003
#define StaticText2                     1004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
