BBAnalogExMod is a analog clock plugin for Blackbox for Windows.

This plugin is a modified version of BBAnalogEx 1.3(Copyright 2004 Theo).
BBAnalogEx 1.0 made from BBAnalog 1.7(Copyright 2003 Mortar).


Right Click:                   Configuration Menu
Left Click & Drag:             Move
Alt + Left Click & Drag:       Resize
Double Left Click:             Time Control Panel
Drop on BBAnalogExMod:         Set as Background Image


Revision History:
0.0.7	2009-01-01 /unkamunka
 - removed buffer overflow on parsing.
 - enabled default bbEditor.
 - 0.70 syntax & other updates.

0.0.6	2005-12-15 /ysuke
 - fixed GDI resource leak on Win9x.
 - fixed the Sticky function.

0.0.5	2005-12-12 /ysuke
 - added transparent background option.

0.0.4	2005-11-03 /John
 - added an option for smooth-sweeping hands (second and minute).

0.0.3	2005-10-12 /ysuke
 - fixed "Plugin Toggle" option.

0.0.2	2005-09-24 /ysuke
 - fixed pluginInfo for xoblite.

0.0.1	2005-08-05 /ysuke
 - first release
 - added support for PNG/JPG/GIF/BMP...(GDI+ supported format) files as background image.
