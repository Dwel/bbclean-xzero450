The files in this directory are from CxImage version 5.11.

CxImage is available at:

    http://www.codeproject.com/bitmap/cximage.asp

