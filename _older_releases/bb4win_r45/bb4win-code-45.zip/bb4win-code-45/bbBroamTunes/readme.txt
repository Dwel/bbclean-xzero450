Usage:
  @bbBroamTunes Command

  Command:
    FastForward(*)
    Next
    Play
    Prev
    Quit
    Rewind(*)
    Stop (also Loads iTunes)
    ToggleFullScreen(*)
    ToggleMini(*)
    ToggleMute(*)
    TogglePlayPause(*)
    ToggleShuffle(*)
    ToggleTray(*)
    ToggleVisuals(*)
    UpdateIPod
    VolumeDown
    VolumeUp
  
  (* Toggle command)

    When running an @string, makes sure that @bbBroamTunes [Command] is placed last:
      	@string [@someBroam | @someotherBroam | @bbBroamTunes [Command]]
      	