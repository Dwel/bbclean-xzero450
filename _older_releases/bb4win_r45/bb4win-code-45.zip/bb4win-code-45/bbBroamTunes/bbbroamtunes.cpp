/*---------------------------------------------------------------------------------
 ============================================================================
 Blackbox for Windows: bbBroamTunes
 ============================================================================
 Copyright � 2006-2008  The Blackbox for Windows Development Team
 http://bb4win.sourceforge.net/ - #bb4win on irc.freenode.net
 ============================================================================

  Blackbox for Windows is free software, released under the
  GNU General Public License (GPL version 2 or later), with an extension
  that allows linking of proprietary modules under a controlled interface.
  What this means is that plugins etc. are allowed to be released
  under any license the author wishes. Please note, however, that the
  original Blackbox gradient math code used in Blackbox for Windows
  is available under the BSD license.

  http://www.fsf.org/licenses/gpl.html
  http://www.fsf.org/licenses/gpl-faq.html#LinkingOverControlledInterface
  http://www.xfree86.org/3.3.6/COPYRIGHT2.html#5

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU General Public License for more details.

  For additional license information, please read the included license.html

 ============================================================================

  In the case of bbBroamTunes, "The Blackbox for Windows Development Team"
  primarily means (in alphabetical order): kazmix, unkamunka.

 --------------------------------------------------------------------------------*/

#ifndef _WIN32_WINNT
    #define _WIN32_WINNT 0x0500
#endif

#ifndef _ATL_CSTRING_EXPLICIT_CONSTRUCTORS
#define _ATL_CSTRING_EXPLICIT_CONSTRUCTORS
#endif
#include <atlbase.h>
#include <atlstr.h>
#include <atlcom.h>
#include "BBApi.h"
#include "iTunesCOMInterface.h"
#include "iTunesCOMInterface_i.h" //rename of iTunesCOMInterface_i.c
#pragma comment (lib, "blackbox.lib")
//---------------------------------------------------------------------------------

extern "C"
{
	int DLL_EXPORT; int beginPlugin(HINSTANCE hMainInstance);
	 void endPlugin(HINSTANCE hMainInstance);
	 LPCSTR pluginInfo(int x);
}

//---------------------------------------------------------------------------------

static HWND     hPluginWnd = NULL;
static int      bb_messages[] = {BB_BROADCAST, 0};
const char broam[] = "@bbBroamTunes";
const char szAppName[] = "bbBroamTunes";
CComPtr<IiTunes> iTunes;
IITBrowserWindow *iTunesBrowser;
IITPlaylist *iTunesPlaylist;
IITVisual *iTunesVisual;

//---------------------------------------------------------------------------------

LRESULT CALLBACK PluginProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    if (message == BB_BROADCAST)
    {
        if (!strnicmp(broam, (char*)(lParam), strlen(broam))){
		char *param;
		param = ((char*)(lParam)) + strlen(broam);
		while(*param==' ' || *param=='\t')
			param ++;
		
    		if(FAILED(iTunes.CoCreateInstance(CLSID_iTunesApp))){
           		MessageBox(NULL,"iTunes create error",szAppName,MB_OK);
            		return 1;
   		}
		VARIANT_BOOL vbool;
		ITPlayerState state;
		long volume;	
		if(!stricmp("Play",param)){
			iTunes->Play();
		}else if(!stricmp("Next",param)){
			iTunes->NextTrack();
		}else if(!stricmp("Prev",param)){
			iTunes->PreviousTrack();
		}else if(!stricmp("TogglePlayPause",param)){
			iTunes->PlayPause();
		}else if(!stricmp("Stop",param)){
			iTunes->Stop();
		}else if(!stricmp("UpdateIPod",param)){
			iTunes->UpdateIPod();
		}else if(!stricmp("Quit",param)){
			iTunes->Quit();
		}else if(!stricmp("ToggleMute",param)){
			iTunes->get_Mute(&vbool);
			iTunes->put_Mute((vbool == VARIANT_TRUE)?VARIANT_FALSE:VARIANT_TRUE);
		}else if(!stricmp("ToggleVisuals",param)){
			iTunes->get_VisualsEnabled(&vbool);
			iTunes->put_VisualsEnabled((vbool == VARIANT_TRUE)?VARIANT_FALSE:VARIANT_TRUE);
		}else if(!stricmp("ToggleFullScreen",param)){
			iTunes->get_FullScreenVisuals(&vbool);
			iTunes->put_FullScreenVisuals((vbool == VARIANT_TRUE)?VARIANT_FALSE:VARIANT_TRUE);
		}else if(!stricmp("ToggleShuffle",param)){
			if(iTunes->get_CurrentPlaylist(&iTunesPlaylist)==S_OK){
				iTunesPlaylist->get_Shuffle(&vbool);
				iTunesPlaylist->put_Shuffle((vbool == VARIANT_TRUE)?VARIANT_FALSE:VARIANT_TRUE);
			}
		}else if(!stricmp("ToggleMini",param)){
			if(iTunes->get_BrowserWindow(&iTunesBrowser)==S_OK){
				iTunesBrowser->get_MiniPlayer(&vbool);
				iTunesBrowser->put_MiniPlayer((vbool == VARIANT_TRUE)?VARIANT_FALSE:VARIANT_TRUE);
				iTunesBrowser->Release();
			}
		}else if(!stricmp("ToggleTray",param)){
			if(iTunes->get_BrowserWindow(&iTunesBrowser)==S_OK){
				iTunesBrowser->get_Minimized(&vbool);
				iTunesBrowser->put_Minimized((vbool == VARIANT_TRUE)?VARIANT_FALSE:VARIANT_TRUE);
				iTunesBrowser->Release();
			}
		}else if(!stricmp("FastForward",param)){
			iTunes->get_PlayerState(&state);
			if(state==ITPlayerStateFastForward){
				iTunes->Resume();
			}else{
				iTunes->FastForward();
			}
		}else if(!stricmp("Rewind",param)){
			iTunes->get_PlayerState(&state);
			if(state==ITPlayerStateRewind){
				iTunes->Resume();
			}else{
				iTunes->Rewind();
			}
		}else if(!stricmp("VolumeUp",param)){
			iTunes->get_SoundVolume(&volume);
			iTunes->put_SoundVolume(volume+5);
		}else if(!stricmp("VolumeDown",param)){
			iTunes->get_SoundVolume(&volume);
			iTunes->put_SoundVolume(volume-5);
		}
		iTunes.Release();
	}
        return 0;
    }
    return DefWindowProc(hwnd, message, wParam, lParam);
}

//---------------------------------------------------------------------------------

int beginPlugin(HINSTANCE h_instance)
{

    if(FAILED(::CoInitialize(NULL))){
	    MessageBox(NULL,"Initializing COM Error",szAppName,MB_OK);
	    return 1;
    }
	
    WNDCLASS wc;
    ZeroMemory(&wc, sizeof(wc));
    wc.lpfnWndProc = PluginProc;
    wc.hInstance = h_instance;
    wc.lpszClassName = szAppName;
    RegisterClass(&wc);

    hPluginWnd = CreateWindowEx(
        WS_EX_TOOLWINDOW,
        szAppName,
        NULL,
        WS_POPUP|WS_ICONIC,
        -4, -4, 0, 0,
        HWND_MESSAGE,
        NULL,
        h_instance,
        NULL
    );

    SendMessage(GetBBWnd(), BB_REGISTERMESSAGE, (WPARAM)hPluginWnd, (LPARAM)bb_messages);
    return 0;
}

//---------------------------------------------------------------------------------

void endPlugin(HINSTANCE h_instance)
{
	::CoUninitialize();
	DestroyWindow(hPluginWnd);
	SendMessage(GetBBWnd(), BB_UNREGISTERMESSAGE, (WPARAM)hPluginWnd, (LPARAM)bb_messages);
	UnregisterClass(szAppName, h_instance);
}

//---------------------------------------------------------------------------------
LPCSTR pluginInfo(int x)
{
	switch (x)
        {
		case 1: return szAppName;
		case 2: return "0.15";
		case 3: return "kazmix - additions by unkamunka";
		case 4: return "2008-12-25";
		case 5: return "http://bb4win.sourceforge.net/";
		case 6: return "irc://irc.freenode.net/bb4win";
		case 7: return
				"@bbBroamTunes UpdateIPod"  
				"@bbBroamTunes VolumeUp"  
				"@bbBroamTunes VolumeDown"  
				"@bbBroamTunes ToggleMute" 
				"@bbBroamTunes ToggleFullScreen"  
				"@bbBroamTunes ToggleVisuals" 
				"@bbBroamTunes Rewind"  
				"@bbBroamTunes FastForward"  
				"@bbBroamTunes ToggleTray"  
				"@bbBroamTunes ToggleSnap"  
				"@bbBroamTunes ToggleMini"  
				"@bbBroamTunes ToggleShuffle"  
				"@bbBroamTunes Quit"  
				"@bbBroamTunes Stop"  
				"@bbBroamTunes TogglePlayPause"  
				"@bbBroamTunes Prev"  
				"@bbBroamTunes Next"  
				"@bbBroamTunes Play";  

		default: return "bbBroamTunes 0.15";
     
	}
}
